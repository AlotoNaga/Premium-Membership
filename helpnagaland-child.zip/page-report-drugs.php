<?php
/**
 * Template — Report Drug Activity
 *
 * Thin shell. The admin places the [hnc_drug_form] shortcode (and any
 * surrounding copy) in the WordPress page editor. The safety pre-screen
 * card below is rendered by the theme and is not editable from the
 * admin UI because it encodes non-negotiable platform rules
 * (R01 drug-reports-never-public, R02 no-names, emergency routing)
 * that must reach every reporter.
 *
 * Functions.php forces noindex on this slug.
 *
 * @package HelpNagalandChild
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-page hnc-page-report-drug">

	<div class="hnc-wide">
		<aside class="hnc-safety-card" aria-labelledby="hnc-safety-title">
			<h2 id="hnc-safety-title"><?php esc_html_e( 'Before you submit: please read', 'helpnagaland-child' ); ?></h2>
			<ul>
				<li><?php esc_html_e( 'Drug reports are NEVER shown publicly. They are reviewed privately by the Clean Nagaland moderation team.', 'helpnagaland-child' ); ?></li>
				<li><?php esc_html_e( 'Do not name any individual. Do not guess anyone\'s identity. Describe patterns, places, times.', 'helpnagaland-child' ); ?></li>
				<li><?php esc_html_e( 'If you are in immediate danger, stop. Dial 112. This platform is not an emergency service.', 'helpnagaland-child' ); ?></li>
				<li><?php esc_html_e( 'A tracking code is issued so you can check the status later without logging in.', 'helpnagaland-child' ); ?></li>
			</ul>
		</aside>
	</div>

	<div class="hnc-wide">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				the_content();
			}
		}
		?>
	</div>

</main>

<?php
get_footer();
