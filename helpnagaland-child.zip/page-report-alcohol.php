<?php
/**
 * Template — Report Illegal Alcohol
 *
 * Thin shell. The admin places the [hnc_alcohol_form] shortcode (and
 * any surrounding copy) in the WordPress page editor. The safety
 * warning above is rendered by the theme and is not editable from the
 * admin UI because it encodes platform rules (R02 no-names, R04
 * live-only) and must be visible to every reporter.
 *
 * Functions.php forces noindex on this slug.
 *
 * @package HelpNagalandChild
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-page hnc-page-report-alcohol">

	<div class="hnc-wide">
		<div class="hnc-notice hnc-notice-warning" role="note">
			<span class="hnc-notice-icon" aria-hidden="true">!</span>
			<div class="hnc-notice-body">
				<p><?php esc_html_e( 'Do not put yourself at risk. Only submit from a safe public location. Do not photograph people. Do not capture vehicle number plates clearly. Do not include anyone\'s name.', 'helpnagaland-child' ); ?></p>
			</div>
		</div>
	</div>

	<div class="hnc-wide">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				the_content();
			}
		}
		?>
	</div>

</main>

<?php
get_footer();
