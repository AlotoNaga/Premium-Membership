<?php
/**
 * Default page template.
 *
 * This is the fallback WordPress uses for any page that does not
 * have its own `page-{slug}.php` template in the child theme. It
 * wraps the admin-typed content in the theme's reading container
 * (.hnc-prose) so typography, line length, headings, lists, tables
 * and code all pick up the brand styling.
 *
 * The 14 pages that have slug-specific templates (report-alcohol,
 * report-drugs, map, check-status, transparency, about, contact,
 * terms, privacy, disclaimer, source-protection, takedown,
 * editorial-policy, cookies) continue to use those files. Every
 * other page — FAQ, How It Works, Data and Privacy, Partners,
 * Media Kit, Safety and Self Help, Volunteer, and anything the
 * admin creates in the future — renders through this template.
 *
 * @package HelpNagalandChild
 * @since   1.1.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-page hnc-page-generic">

	<article class="hnc-prose">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				the_content();
			}
		}
		?>
	</article>

</main>

<?php
get_footer();
