<?php
/**
 * 404 Template — helpnagaland.com
 *
 * Friendly "not found" page that points visitors toward the three main
 * actions (report, map, status check) instead of dead-ending them.
 *
 * @package HelpNagalandChild
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-404" aria-labelledby="hnc-404-title">
	<div class="hnc-404-inner">
		<div class="hnc-404-code" aria-hidden="true">404</div>

		<h1 id="hnc-404-title" class="hnc-404-title">
			<?php esc_html_e( 'This page does not exist.', 'helpnagaland-child' ); ?>
		</h1>

		<p class="hnc-404-body">
			<?php esc_html_e( 'The link you followed may be broken, or the page may have been moved. Here are a few places that can help you find what you were looking for.', 'helpnagaland-child' ); ?>
		</p>

		<div class="hnc-404-links">
			<a class="hnc-btn hnc-btn-primary" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<?php esc_html_e( 'Go home', 'helpnagaland-child' ); ?>
			</a>
			<a class="hnc-btn hnc-btn-secondary" href="<?php echo esc_url( home_url( '/report-alcohol/' ) ); ?>">
				<?php esc_html_e( 'Report alcohol', 'helpnagaland-child' ); ?>
			</a>
			<a class="hnc-btn hnc-btn-secondary" href="<?php echo esc_url( home_url( '/map/' ) ); ?>">
				<?php esc_html_e( 'Open the map', 'helpnagaland-child' ); ?>
			</a>
			<a class="hnc-btn hnc-btn-secondary" href="<?php echo esc_url( home_url( '/check-status/' ) ); ?>">
				<?php esc_html_e( 'Check status', 'helpnagaland-child' ); ?>
			</a>
		</div>
	</div>
</main>

<?php
get_footer();
