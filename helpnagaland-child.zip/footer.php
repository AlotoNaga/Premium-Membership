<?php
/**
 * Footer Template — helpnagaland.com
 *
 * Layout:
 *   1. Brand intro strip — full width, site name + short description.
 *   2. Link grid — five categorized columns (Report / Public / About /
 *      Legal / Nagaland Me) on desktop. Drops to 2 columns on phone
 *      and 1 on very narrow screens via CSS auto-fit.
 *   3. Permanent disclaimer strip (pre-launch checklist requirement).
 *   4. Copyright line.
 *   5. Closing #page wrapper opened in header.php.
 *
 * Each link group is rendered from a sorted list (shortest labels
 * first, longest at the end) per the operator's preference. Adding a
 * new page is a one-line array entry — no CSS needed.
 *
 * @package HelpNagalandChild
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/*
 * Categorized footer link map. Order within each category is
 * shortest-label → longest-label so columns align visually. Slugs
 * match what WordPress assigns when each page is created from the
 * admin notice's "Create missing pages" action; if you renamed a
 * page in WP, only the slug here needs to update.
 */
$hnc_footer_groups = array(

	'report' => array(
		'label' => __( 'Report', 'helpnagaland-child' ),
		'links' => array(
			array( 'href' => home_url( '/check-status/' ),    'label' => __( 'Check status',    'helpnagaland-child' ) ),
			array( 'href' => home_url( '/report-drugs/' ),    'label' => __( 'Drug activity',   'helpnagaland-child' ) ),
			array( 'href' => home_url( '/report-alcohol/' ),  'label' => __( 'Illegal alcohol', 'helpnagaland-child' ) ),
		),
	),

	'public' => array(
		'label' => __( 'Public', 'helpnagaland-child' ),
		'links' => array(
			array( 'href' => home_url( '/map/' ),                  'label' => __( 'Map',                'helpnagaland-child' ) ),
			array( 'href' => home_url( '/faq/' ),                  'label' => __( 'FAQ',                'helpnagaland-child' ) ),
			array( 'href' => home_url( '/transparency/' ),         'label' => __( 'Transparency',       'helpnagaland-child' ) ),
			array( 'href' => home_url( '/how-it-works/' ),         'label' => __( 'How it works',       'helpnagaland-child' ) ),
			array( 'href' => home_url( '/safety-and-self-help/' ), 'label' => __( 'Safety & self-help', 'helpnagaland-child' ) ),
		),
	),

	'about' => array(
		'label' => __( 'About', 'helpnagaland-child' ),
		'links' => array(
			array( 'href' => home_url( '/about/' ),     'label' => __( 'About',     'helpnagaland-child' ) ),
			array( 'href' => home_url( '/contact/' ),   'label' => __( 'Contact',   'helpnagaland-child' ) ),
			array( 'href' => home_url( '/partners/' ),  'label' => __( 'Partners',  'helpnagaland-child' ) ),
			array( 'href' => home_url( '/media-kit/' ), 'label' => __( 'Media kit', 'helpnagaland-child' ) ),
			array( 'href' => home_url( '/volunteer/' ), 'label' => __( 'Volunteer', 'helpnagaland-child' ) ),
		),
	),

	'legal' => array(
		'label' => __( 'Legal', 'helpnagaland-child' ),
		'links' => array(
			array( 'href' => home_url( '/terms/' ),                 'label' => __( 'Terms',                'helpnagaland-child' ) ),
			array( 'href' => home_url( '/privacy/' ),               'label' => __( 'Privacy',              'helpnagaland-child' ) ),
			array( 'href' => home_url( '/cookies/' ),               'label' => __( 'Cookies',              'helpnagaland-child' ) ),
			array( 'href' => home_url( '/takedown/' ),              'label' => __( 'Takedown',             'helpnagaland-child' ) ),
			array( 'href' => home_url( '/editorial-policy/' ),      'label' => __( 'Editorial',            'helpnagaland-child' ) ),
			array( 'href' => home_url( '/disclaimer/' ),            'label' => __( 'Disclaimer',           'helpnagaland-child' ) ),
			array( 'href' => home_url( '/data-and-privacy/' ),      'label' => __( 'Data & privacy',       'helpnagaland-child' ) ),
			array( 'href' => home_url( '/source-protection/' ),     'label' => __( 'Source protection',    'helpnagaland-child' ) ),
			array( 'href' => home_url( '/community-guidelines/' ),  'label' => __( 'Community guidelines', 'helpnagaland-child' ) ),
		),
	),

	'family' => array(
		'label' => __( 'Nagaland Me', 'helpnagaland-child' ),
		'links' => array(
			array( 'href' => 'https://nagaland.me/',          'label' => __( 'Parent brand',        'helpnagaland-child' ), 'external' => true ),
			array( 'href' => 'https://nagalandai.com/',       'label' => __( 'Nagaland AI',         'helpnagaland-child' ), 'external' => true ),
			array( 'href' => 'https://nagalandnewstoday.com/', 'label' => __( 'Nagaland News Today', 'helpnagaland-child' ), 'external' => true ),
		),
	),
);

/**
 * Filter the categorized footer link map so a child theme or
 * mu-plugin can add, remove, reorder, or relabel groups and links
 * without editing this file.
 *
 * @param array $hnc_footer_groups The default groups defined above.
 */
$hnc_footer_groups = apply_filters( 'helpnagaland_child_footer_groups', $hnc_footer_groups );
?>

	<footer id="colophon" class="site-footer hnc-site-footer" role="contentinfo">

		<div class="hnc-footer-brand">
			<h3 class="hnc-footer-brand-title"><?php bloginfo( 'name' ); ?></h3>
			<p class="hnc-footer-brand-desc">
				<?php esc_html_e( 'A civic reporting platform by Nagaland Me. Anonymous submissions, transparent outcomes, no personal data collection beyond what you explicitly consent to.', 'helpnagaland-child' ); ?>
			</p>
			<p class="hnc-footer-brand-meta">
				<?php
				printf(
					/* translators: %s is a link to the parent brand website. */
					esc_html__( 'Operated by %s.', 'helpnagaland-child' ),
					'<a href="https://nagaland.me/" rel="noopener external">Nagaland Me</a>'
				);
				?>
			</p>
		</div>

		<div class="hnc-footer">
			<?php foreach ( $hnc_footer_groups as $group_key => $group ) : ?>
				<?php if ( empty( $group['links'] ) || ! is_array( $group['links'] ) ) { continue; } ?>
				<div class="hnc-footer-col" data-hnc-group="<?php echo esc_attr( $group_key ); ?>">
					<h4 class="hnc-footer-col-heading">
						<?php echo esc_html( isset( $group['label'] ) ? (string) $group['label'] : '' ); ?>
					</h4>
					<ul>
						<?php foreach ( $group['links'] as $link ) : ?>
							<?php
							$href     = isset( $link['href'] ) ? (string) $link['href'] : '';
							$label    = isset( $link['label'] ) ? (string) $link['label'] : '';
							$external = ! empty( $link['external'] );
							if ( '' === $href || '' === $label ) {
								continue;
							}
							?>
							<li>
								<a
									href="<?php echo esc_url( $href ); ?>"
									<?php if ( $external ) : ?>rel="noopener external"<?php endif; ?>
								>
									<?php echo esc_html( $label ); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endforeach; ?>
		</div>

		<?php
		// Optional supplementary nav menu. Falls back to nothing if the
		// site owner has not assigned the 'hnc-footer-links' location.
		if ( has_nav_menu( 'hnc-footer-links' ) ) :
			?>
			<div class="hnc-footer-extra">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'hnc-footer-links',
						'menu_id'        => 'hnc-footer-links-menu',
						'menu_class'     => 'hnc-footer-links-menu',
						'container'      => false,
						'depth'          => 1,
					)
				);
				?>
			</div>
			<?php
		endif;
		?>

		<div class="hnc-footer-disclaimer" role="note">
			<p>
				<strong><?php esc_html_e( 'Disclaimer.', 'helpnagaland-child' ); ?></strong>
				<?php esc_html_e( 'Clean Nagaland publishes citizen-submitted reports for civic awareness. Publication is not a finding of guilt, is not a court judgment, and does not name or identify any individual. The platform has no law-enforcement powers. For emergencies, dial 112. See our Content Disclaimer, Editorial Policy and Takedown policy.', 'helpnagaland-child' ); ?>
			</p>
		</div>

		<div class="hnc-footer-bottom">

			<div class="hnc-footer-copy">
				<?php
				$copyright = apply_filters(
					'astra_copyright',
					sprintf(
						/* translators: 1: year, 2: site name, 3: tagline */
						'&copy; %1$s %2$s &mdash; %3$s',
						esc_html( gmdate( 'Y' ) ),
						esc_html( get_bloginfo( 'name' ) ),
						esc_html__( 'A Nagaland Me civic platform', 'helpnagaland-child' )
					)
				);
				echo wp_kses(
					$copyright,
					array(
						'span' => array( 'class' => array() ),
						'a'    => array(
							'href' => array(),
							'rel'  => array(),
						),
					)
				);
				?>
			</div>

		</div>

	</footer>

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>
