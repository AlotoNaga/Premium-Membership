# Changelog

All notable changes to Help Nagaland Child are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.8] — SEO patch: two fixes from Codex review

### Fixed

- **og:site_name filter was a silent no-op.** v1.1.7 registered
  the callback on `rank_math/opengraph/site_name`, which Rank Math
  never fires. Rank Math's Open Graph filters are network/property
  specific — the correct Facebook hook is
  `rank_math/opengraph/facebook/og_site_name`. With the wrong hook,
  a page using Rank Math continued emitting WordPress's default
  site title as `og:site_name` instead of the intended "Clean
  Nagaland" brand string. Now registered against the correct hook.
- **og:url duplicated the site subdirectory on non-singular pages.**
  The fallback path used `home_url( add_query_arg( null, null ) )`,
  which first takes the whole current request URI (including any
  `/blog/` subdirectory prefix) and then hands it to `home_url()`,
  which concatenates the home path again. On a subdirectory
  install the result was malformed (`.../blog/blog/page/`), which
  breaks sharing previews and confuses Google's URL consolidation.
  Replaced with a new `current_canonical_url()` helper that uses
  `get_permalink()` for singular pages, `home_url('/')` for the
  front page, and scheme + host + `REQUEST_URI` for everything
  else — none of which can double-prefix.

Both fixes affect only the standalone-emit path (when Rank Math is
not active) or the filtered-value path (the og:site_name hook).
Pages where Rank Math is fully handling OG tags were unaffected
by the bugs and remain unaffected by the fixes.

## [1.1.7] — Production-grade SEO

SEO-related PHP is now encapsulated in `inc/seo/class-helpnagaland-seo.php`.
Works with or without Rank Math Pro; when Rank Math is active the
class enriches Rank Math's own graph instead of emitting duplicates
that would fail the Rich Results test.

### Added

- **WebSite schema with SearchAction** on the homepage. Google
  uses this to render the sitelinks search box under the brand
  result in SERP. Not emitted by Rank Math by default.
- **Enhanced Organization schema**. Added `address` (PostalAddress
  with addressRegion=Nagaland, addressCountry=IN), `founder`,
  `foundingDate`, `knowsAbout`, `image`, and an `alternateName`
  array instead of a single string. `@graph` envelope bundles
  Organization + WebSite + page entity in one script tag (Google's
  preferred pattern).
- **Page-type schema promotion.** Rank Math's generic `WebPage` is
  upgraded to the specific type on pages where it applies:
  `AboutPage` for `/about/` and `/about-us/` and `/media-kit/`;
  `ContactPage` for `/contact/`; `FAQPage` for `/faq/`;
  `CollectionPage` for `/transparency/` and `/partners/`. All
  other pages stay as `WebPage`. No duplication — we transform
  the `@type` in place.
- **Favicon + apple-touch-icon fallback**. When the admin hasn't
  uploaded a Site Icon via the Customiser, the theme now emits
  `<link rel="icon">` and `<link rel="apple-touch-icon">` pointing
  at the theme logo SVG and the 1200×900 screenshot.
- **Open Graph and Twitter Card defaults.** When Rank Math is not
  active, the theme emits `og:title`, `og:description`, `og:url`,
  `og:site_name`, `og:type`, `og:image`, `og:locale`,
  `twitter:card`, `twitter:title`, `twitter:description`,
  `twitter:image`. When Rank Math IS active, the theme filters in
  a fallback og:image (screenshot.png) and forces
  og:site_name = "Clean Nagaland".
- **Meta description fallback** for pages where the admin hasn't
  entered a description. Uses the page excerpt, or a trimmed
  28-word version of page content, or a brand sentence as last
  resort.
- **`<meta name="application-name" content="Clean Nagaland" />`**
  — an additional site-name signal for Google's brand inference.
- **`SEO-SETUP.md`** — comprehensive operator checklist covering
  WordPress settings, Rank Math Pro configuration, Search Console,
  Bing Webmaster Tools, Rich Results validation, Core Web Vitals,
  and content homework.

### Changed

- `functions.php` no longer carries the schema-emission functions
  directly; it requires `inc/seo/class-helpnagaland-seo.php` and
  hooks the class's `init()` on `after_setup_theme`.

### Filters added for site-owner customisation

- `helpnagaland_child_organization_schema` — adjust any
  Organization field.
- `helpnagaland_child_website_schema` — adjust WebSite fields.
- `helpnagaland_child_page_type_map` — override the slug →
  schema-type mapping.
- `helpnagaland_child_default_og_image` — change the fallback
  social image.
- `helpnagaland_child_og_site_name` — change the site name string
  used in OG tags.

## [1.1.6] — Footer rebuilt for 24+ pages

### Changed

- **Footer link map is now data-driven.** `footer.php` builds the
  link grid from a `$hnc_footer_groups` array instead of hand-coded
  `<div>` blocks. Adding, removing, renaming, or reordering a
  category/link is a one-line edit. The array is also exposed via a
  new `helpnagaland_child_footer_groups` filter so a child theme or
  mu-plugin can customise it without touching theme files.
- **Five categorized columns** on desktop:
  - **Report** — Check status, Drug activity, Illegal alcohol.
  - **Public** — Map, FAQ, Transparency, How it works, Safety &
    self-help.
  - **About** — About, Contact, Partners, Media kit, Volunteer.
  - **Legal** — Terms, Privacy, Cookies, Takedown, Editorial,
    Disclaimer, Data & privacy, Source protection, Community
    guidelines.
  - **Nagaland Me** — Parent brand, Nagaland AI, Nagaland News
    Today (external).
  - Order within each column is shortest label first, longest at the
    end (operator preference).
- **Brand intro strip** moved above the link grid as a full-width
  block. This frees the grid for link columns only and matches the
  pattern used by Stripe / GOV.UK / Wikipedia.
- **Grid layout** is now `repeat(auto-fit, minmax(170px, 1fr))` so
  the column count adapts automatically to the available width and
  to however many categories are defined. Future categories slot
  in without any CSS edits.

### Mobile

- **Two-column layout under 700px** (operator preference). The five
  link categories flow into a 3-row × 2-column arrangement instead
  of stacking into one tall column.
- **Single column under 380px** (very narrow phones / split-screen
  tablets) where two columns become unreadable.
- **Slightly smaller link font on phone** (0.875rem) so longer
  labels like "Source protection" fit one column without wrapping
  awkwardly.
- **`text-wrap: balance`** on link labels so any label that does
  wrap distributes lines evenly instead of orphaning a single word.
- **Each link is a 24px-min tall block** so taps land cleanly on
  touch devices.

### Removed

- The legacy `<ul class="hnc-footer-legal-menu">` row at the bottom
  of the footer is no longer rendered. Those legal pages are now
  surfaced in the dedicated **Legal** category column above. The
  copyright line stays exactly as it was.

## [1.1.5] — Reliable kill-switch banner on the front end

### Fixed

- **Kill-switch banner silently didn't appear.** `header.php` checked
  the `hnc_killswitch_active` option with a strict string equality
  (`=== '1'`), but WordPress returns that option as an integer `1`
  or a string `'1'` depending on object-cache state. On hosts
  where it came back as the integer, the public banner stayed
  hidden even when the plugin was correctly blocking submissions —
  so visitors arriving at the home page got no warning and only
  discovered the pause when a submission form returned the 503
  message.

  The check now prefers `HNC_Killswitch::is_active()` when the
  plugin class is loaded, and falls back to `(int) get_option(...)
  === 1` otherwise. Either way, integer and string storage both
  register as active.
- **Banner text respects the operator-supplied public message.**
  If the operator typed a public message when activating the kill
  switch (e.g. "We are paused for legal review — back shortly"),
  the banner now shows that message. Previously the banner always
  used the generic fallback regardless of what was configured.

## [1.1.4] — Generic page template for non-templated pages

### Added

- **`page.php`** — default child-theme page template. Any page that
  does not have a slug-specific `page-{slug}.php` template now
  renders through this file instead of falling back to Astra's
  default page template. The content is wrapped in `.hnc-prose` so
  width, typography, headings, lists, tables and code match the
  look of the 9 legal/info pages.

### Why

The 14 pages with slug-specific templates (report-alcohol,
report-drugs, map, check-status, transparency + the 9 legal pages)
rendered correctly, but any other page — FAQ, How It Works, Data
and Privacy, Partners, Media Kit, Privacy Policy, Safety and Self
Help, Volunteer, or anything else the admin creates — was falling
back to Astra's default and rendering edge-to-edge without the
brand's reading container. This template closes that gap with a
single file.

## [1.1.3] — Stop double-rendering shortcodes

### Changed

- **Removed hardcoded `do_shortcode()` calls** from the 5 action-page
  templates. The admin now places the shortcode (e.g.
  `[hnc_alcohol_form]`, `[hnc_drug_form]`, `[hnc_alcohol_map]`,
  `[hnc_status_check]`, `[hnc_transparency_page]`) directly in the
  WordPress page editor. `the_content()` expands it once. The previous
  version also called the shortcode from the template, causing the
  form / map / snapshot list to render a second time on top of the
  admin-placed copy.
- **Removed the "plugin not active" fallback** that used to sit next
  to each hardcoded `do_shortcode()` call. It was only meaningful as
  a guard around that call; with the call gone, the fallback has no
  purpose. If the plugin is deactivated, the raw shortcode text in
  the page body is left visible by WordPress, which is a clearer
  signal to operators than a custom error banner.

### Kept

- Safety warning on `page-report-alcohol.php` ("Do not put yourself
  at risk…").
- Safety pre-screen card on `page-report-drugs.php` ("Before you
  submit: please read").
- `noindex` enforcement on submission and status-check pages.

## [1.1.2] — Remove duplicate page headers on action pages

### Changed

- **Removed the theme-rendered title/eyebrow block** from these 5
  page templates so they no longer render a second copy of a title
  the admin has already written in the WordPress editor:
  - `page-check-status.php`
  - `page-transparency.php`
  - `page-map.php`
  - `page-report-alcohol.php`
  - `page-report-drugs.php`

### Kept

- The safety pre-screen card on `page-report-drugs.php` ("Before you
  submit: please read") — non-negotiable platform rules that must
  reach every reporter (R01, R02, emergency routing).
- The safety notice on `page-report-alcohol.php` ("Do not put yourself
  at risk…") — encodes R02 / R04.
- The "Help Nagaland Core plugin is not active" error fallback on all
  5 pages.
- The theme-rendered title block on the 9 legal/info page templates
  (about, contact, terms, privacy, disclaimer, source-protection,
  takedown, editorial-policy, cookies). Those remain controlled from
  the template so layout stays consistent across legal pages.

## [1.1.1] — Editable page content

### Changed

- **Stripped the canonical fallback prose** from all 9 legal/info page templates (about, contact, terms, privacy, disclaimer, source-protection, takedown, editorial-policy, cookies). Pages now render only the content typed by the admin in the WordPress editor. The templates stay as thin shells so the theme's layout, header, footer and disclaimer strip are still consistent across the site.
- **Page titles now come from the WordPress page title** (`the_title()`) instead of being hardcoded. Renaming a page in WP immediately updates the rendered `<h1>`.
- **Removed the hardcoded page-lede paragraphs** from the legal, report and shortcode page templates. If the admin wants introductory copy, they type it as the first paragraph of the page body in WP.
- **Removed hardcoded contact emails** from the Contact and Takedown templates. The admin types their real addresses directly into the WP page editor.

### Kept (deliberately)

- The small category eyebrow label above the title on each page (design chrome, not content).
- The "lawyer must review" notice on Terms and Privacy templates — now phrased as "this page is empty, please write it before launch" and auto-hides as soon as the admin writes any content.
- The safety warning on the Report Alcohol page and the safety pre-screen card on the Report Drug page. These encode non-negotiable platform rules (R01 drug-reports-never-public, R02 no-names, R04 live-only) that must be visible to every reporter and are not appropriate to edit away.
- The "Help Nagaland Core plugin is not active" error fallback on the 5 shortcode-driven pages. Operational safety net if the plugin is ever deactivated.

## [1.1.0] — Production-ready child theme

### Added
- `header.php`: custom header with skip-link, sticky brand bar, accessible mobile nav toggle, and an always-visible kill-switch banner driven by the plugin's `hnc_killswitch_active` option.
- Fourteen page templates covering the full information architecture described in Section 14 of the specification:
  - Submission flows: `page-report-alcohol.php`, `page-report-drugs.php`, `page-map.php`, `page-check-status.php`, `page-transparency.php`.
  - Nine legal / information pages: `page-about.php`, `page-contact.php`, `page-terms.php`, `page-privacy.php`, `page-disclaimer.php`, `page-source-protection.php`, `page-takedown.php`, `page-editorial-policy.php`, `page-cookies.php`. Each ships with canonical content that is overridden by admin-edited content when present.
- Supplemental CSS modules under `/assets/css/`:
  - `variables.css` — spacing scale, motion, z-index tiers, semantic aliases.
  - `typography.css` — tables, figures, kbd, details, abbr, mark, tabular numerals.
  - `layout.css` — containers, stacks, clusters, auto-fit grid utilities.
  - `components.css` — tags/chips, status dots, badges, KPI blocks, link lists.
  - `fonts.css` — self-hosted Inter declarations (enqueued automatically when `assets/fonts/` exists).
- `assets/js/theme.js`: small, untracked front-end script handling the mobile nav toggle, Escape-to-close, click-outside, and viewport-resize cleanup.
- `assets/img/logo.svg` and `assets/img/nagaland-me-mark.svg`: brand marks used by the header and attribution strip.
- `screenshot.png`: 1200×900 theme preview used by the Appearance → Themes screen.
- `languages/helpnagaland-child.pot`: translation template.
- `readme.txt` and `CHANGELOG.md`: theme-directory metadata.
- Response-header defaults: `X-Content-Type-Options: nosniff`, `Referrer-Policy: strict-origin-when-cross-origin`, `X-Frame-Options: SAMEORIGIN`, `Permissions-Policy: geolocation=(self), camera=(self), microphone=(), interest-cohort=()`, `Cross-Origin-Opener-Policy: same-origin`. Skipped on admin, AJAX, cron, and REST requests.
- `noindex, nofollow, noarchive` enforcement on submission and status-check pages via the `wp_robots` filter. Slug list is overridable through the `helpnagaland_child_noindex_slugs` filter.
- Admin dashboard notice plus an `admin-post` action that creates any missing required pages (matching the `page-{slug}.php` template filenames) with a single click.
- `hnc-noindex`, `hnc-plugin-active`, `hnc-killswitch-active`, and `hnc-slug-{slug}` body classes to support conditional styling and targeted CSS.

### Changed
- Font loading. Google Fonts are now opt-in (default off) to honour rule R07 ("no third-party tracking ever") and the DPDP Act 2023 minimisation principle. Opt-in filter: `helpnagaland_child_use_google_fonts`. Self-hosted Inter is picked up automatically when `assets/fonts/Inter-*.woff2` is present.
- Organization JSON-LD `logo` URL now points to `/assets/img/logo.svg` instead of `screenshot.png`.
- `footer.php` now includes a permanent disclaimer strip (pre-launch checklist requirement), richer legal link defaults, and correctly closes the `#page` wrapper opened in the new `header.php`.
- `style.css` extended with rules for the skip-link, custom header, page header pattern, legal-page typography (`.hnc-prose`), notice/callout component (info/warning/danger/success variants), safety pre-screen card, footer disclaimer, definition list, live counter, and print styles. The existing front-page, feature grid, CTA, 404 and footer styling is unchanged.

### Fixed
- `footer.php` was missing a closing `</div>` for the `#page` wrapper. This only manifested once a custom `header.php` was introduced; the old version implicitly relied on Astra's header markup. The new pair is self-consistent.

### Security
- All user-facing template strings are routed through `esc_html_e`, `esc_attr_e`, `esc_url`, `wp_kses` (for the filterable copyright line), or the equivalent sanitising counterparts.
- Admin-post handler for the page-bootstrap action is guarded by `current_user_can( 'manage_options' )` and `check_admin_referer`.
- `wp_safe_redirect` is used for the post-action redirect.

## [1.0.0] — Initial release
- `style.css`, `functions.php`, `front-page.php`, `footer.php`, `404.php`.
