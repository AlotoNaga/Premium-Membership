<?php
/**
 * Help Nagaland Child — functions.php
 *
 * Responsibilities, in order of how they affect page rendering:
 *
 *   1. Enqueue parent Astra stylesheet BEFORE the child's so our tokens
 *      cascade correctly. Enqueue the minimal theme.js (mobile nav,
 *      skip-link). No analytics, ever.
 *   2. Font loading. Default: system-only, honouring R07 ("no third
 *      party trackers"). Site owners who want Inter can opt in by
 *      filter or self-host.
 *   3. Security + privacy response headers for all public requests.
 *   4. `noindex` enforcement on submission and status-check pages per
 *      the pre-launch checklist.
 *   5. Organization JSON-LD, with Rank Math compatibility.
 *   6. Nav menus, body classes, theme supports, small tweaks.
 *   7. One-click "create required pages" helper on the Dashboard for
 *      site owners who haven't built the information architecture yet.
 *
 * @package HelpNagalandChild
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


if ( ! defined( 'HELPNAGALAND_CHILD_VERSION' ) ) {
	define( 'HELPNAGALAND_CHILD_VERSION', '1.1.8' );
}


/* ============================================================================
 * STYLES AND SCRIPTS
 * ============================================================================ */

/**
 * Enqueue parent Astra stylesheet + the child's style.css + theme.js.
 *
 * @return void
 */
function helpnagaland_child_enqueue_styles() {
	$parent_handle = 'astra-theme-css';
	$parent_style  = get_template_directory_uri() . '/style.css';

	if ( ! wp_style_is( $parent_handle, 'registered' ) ) {
		wp_register_style(
			$parent_handle,
			$parent_style,
			array(),
			wp_get_theme( get_template() )->get( 'Version' )
		);
	}
	wp_enqueue_style( $parent_handle );

	wp_enqueue_style(
		'helpnagaland-child',
		get_stylesheet_uri(),
		array( $parent_handle ),
		HELPNAGALAND_CHILD_VERSION
	);

	/*
	 * Supplemental modules. Loaded after style.css so rules here extend
	 * the main sheet. Each file is skipped gracefully if missing.
	 */
	$supplemental = array(
		'helpnagaland-variables'  => '/assets/css/variables.css',
		'helpnagaland-typography' => '/assets/css/typography.css',
		'helpnagaland-layout'     => '/assets/css/layout.css',
		'helpnagaland-components' => '/assets/css/components.css',
	);
	$prev_handle = 'helpnagaland-child';
	foreach ( $supplemental as $handle => $rel_path ) {
		if ( file_exists( get_stylesheet_directory() . $rel_path ) ) {
			wp_enqueue_style(
				$handle,
				get_stylesheet_directory_uri() . $rel_path,
				array( $prev_handle ),
				HELPNAGALAND_CHILD_VERSION
			);
			$prev_handle = $handle;
		}
	}

	wp_enqueue_script(
		'helpnagaland-child-theme',
		get_stylesheet_directory_uri() . '/assets/js/theme.js',
		array(),
		HELPNAGALAND_CHILD_VERSION,
		true
	);
}
add_action( 'wp_enqueue_scripts', 'helpnagaland_child_enqueue_styles', 15 );


/**
 * Font loading policy.
 *
 * Defaults to system fonts only (no network call) to respect R07 and
 * DPDP Act 2023 minimisation. Two opt-in paths:
 *
 *   A. Self-host Inter. Drop Inter-{400,500,600,700}.woff2 into
 *      assets/fonts/. assets/css/fonts.css is enqueued automatically
 *      when that file exists.
 *   B. Google Fonts. Add
 *          add_filter( 'helpnagaland_child_use_google_fonts', '__return_true' );
 *      in a mu-plugin. Site owners using this must disclose it in
 *      their cookie/privacy policy.
 *
 * @return void
 */
function helpnagaland_child_enqueue_fonts() {
	$fonts_css_path = get_stylesheet_directory() . '/assets/css/fonts.css';
	$fonts_css_url  = get_stylesheet_directory_uri() . '/assets/css/fonts.css';
	$fonts_dir      = get_stylesheet_directory() . '/assets/fonts/';

	if ( file_exists( $fonts_css_path ) && is_dir( $fonts_dir ) ) {
		wp_enqueue_style(
			'helpnagaland-fonts-local',
			$fonts_css_url,
			array(),
			HELPNAGALAND_CHILD_VERSION
		);
	}

	$use_google = apply_filters( 'helpnagaland_child_use_google_fonts', false );
	if ( $use_google ) {
		wp_enqueue_style(
			'helpnagaland-fonts-google',
			'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap',
			array(),
			null
		);
	}
}
add_action( 'wp_enqueue_scripts', 'helpnagaland_child_enqueue_fonts', 12 );


/**
 * Preconnect hint for Google Fonts — only when opt-in is active.
 *
 * @param array  $urls          URLs already planned for that relation.
 * @param string $relation_type Relation (preconnect, dns-prefetch, etc).
 * @return array
 */
function helpnagaland_child_resource_hints( $urls, $relation_type ) {
	$use_google = apply_filters( 'helpnagaland_child_use_google_fonts', false );
	if ( $use_google && 'preconnect' === $relation_type ) {
		$urls[] = array(
			'href'        => 'https://fonts.gstatic.com',
			'crossorigin' => 'anonymous',
		);
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'helpnagaland_child_resource_hints', 10, 2 );


/* ============================================================================
 * SECURITY HEADERS
 * ============================================================================ */

/**
 * Emit privacy- and security-friendly headers on public front-end pages.
 *
 * @return void
 */
function helpnagaland_child_send_security_headers() {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		return;
	}
	if ( headers_sent() ) {
		return;
	}

	header( 'X-Content-Type-Options: nosniff' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Permissions-Policy: geolocation=(self), camera=(self), microphone=(), interest-cohort=()' );
	header( 'Cross-Origin-Opener-Policy: same-origin' );
}
add_action( 'send_headers', 'helpnagaland_child_send_security_headers' );


/* ============================================================================
 * ROBOTS / NOINDEX
 * ============================================================================ */

/**
 * Slugs that must be noindexed on the public site.
 *
 * @return array
 */
function helpnagaland_child_noindex_slugs() {
	return apply_filters(
		'helpnagaland_child_noindex_slugs',
		array(
			'report-alcohol',
			'report-drugs',
			'report-drug',
			'check-status',
			'status',
		)
	);
}


/**
 * Add noindex to the listed pages via core's wp_robots filter.
 *
 * @param array $robots Existing robots directives.
 * @return array
 */
function helpnagaland_child_filter_wp_robots( $robots ) {
	if ( ! is_page() ) {
		return $robots;
	}
	$post = get_queried_object();
	if ( ! $post || empty( $post->post_name ) ) {
		return $robots;
	}
	if ( in_array( $post->post_name, helpnagaland_child_noindex_slugs(), true ) ) {
		$robots['noindex']   = true;
		$robots['nofollow']  = true;
		$robots['noarchive'] = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'helpnagaland_child_filter_wp_robots' );


/* ============================================================================
 * NAV MENUS / THEME SUPPORTS
 * ============================================================================ */

/**
 * Register additional nav menu locations.
 *
 * @return void
 */
function helpnagaland_child_register_menus() {
	register_nav_menus(
		array(
			'hnc-footer-links' => esc_html__( 'Help Nagaland: Footer Links', 'helpnagaland-child' ),
			'hnc-footer-legal' => esc_html__( 'Help Nagaland: Footer Legal', 'helpnagaland-child' ),
		)
	);
}
add_action( 'after_setup_theme', 'helpnagaland_child_register_menus' );


/**
 * Declare theme supports and load text domain.
 *
 * @return void
 */
function helpnagaland_child_theme_support() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );

	load_child_theme_textdomain(
		'helpnagaland-child',
		get_stylesheet_directory() . '/languages'
	);
}
add_action( 'after_setup_theme', 'helpnagaland_child_theme_support' );


/* ============================================================================
 * SEO (schema, Open Graph, icons, meta description fallback).
 *
 * Delegated to HelpNagalandChild_SEO to keep this file focused on
 * theme bootstrap. Works with or without Rank Math Pro; when Rank
 * Math is active it enriches Rank Math's own graph instead of
 * emitting duplicates.
 * ============================================================================ */

require_once get_stylesheet_directory() . '/inc/seo/class-helpnagaland-seo.php';
add_action( 'after_setup_theme', array( 'HelpNagalandChild_SEO', 'init' ) );


/* ============================================================================
 * SMALL TWEAKS
 * ============================================================================ */

/**
 * Shorten the automatic excerpt for archive pages.
 *
 * @param int $length Default excerpt length.
 * @return int
 */
function helpnagaland_child_excerpt_length( $length ) {
	return 28;
}
add_filter( 'excerpt_length', 'helpnagaland_child_excerpt_length', 20 );


/**
 * Custom excerpt "more" marker.
 *
 * @param string $more Default more string.
 * @return string
 */
function helpnagaland_child_excerpt_more( $more ) {
	return '&hellip;';
}
add_filter( 'excerpt_more', 'helpnagaland_child_excerpt_more', 20 );


/**
 * Add body classes reflecting plugin and page context.
 *
 * @param array $classes Body classes.
 * @return array
 */
function helpnagaland_child_body_class( $classes ) {
	if ( class_exists( 'HNC_Public_Shortcodes' ) ) {
		$classes[] = 'hnc-plugin-active';
	}
	if ( is_page() ) {
		$post = get_queried_object();
		if ( $post && ! empty( $post->post_name ) ) {
			$classes[] = 'hnc-slug-' . sanitize_html_class( $post->post_name );
			if ( in_array( $post->post_name, helpnagaland_child_noindex_slugs(), true ) ) {
				$classes[] = 'hnc-noindex';
			}
		}
	}
	if ( get_option( 'hnc_killswitch_active' ) === '1' ) {
		$classes[] = 'hnc-killswitch-active';
	}
	return $classes;
}
add_filter( 'body_class', 'helpnagaland_child_body_class' );


/**
 * Replace Astra's default footer copyright string.
 *
 * @param string $html Astra's default copyright HTML.
 * @return string
 */
function helpnagaland_child_astra_copyright( $html ) {
	$year = gmdate( 'Y' );
	return sprintf(
		'<span class="hnc-footer-copyright">&copy; %1$s %2$s &mdash; %3$s</span>',
		esc_html( $year ),
		esc_html( get_bloginfo( 'name' ) ),
		esc_html__( 'A Nagaland Me civic platform', 'helpnagaland-child' )
	);
}
add_filter( 'astra_copyright', 'helpnagaland_child_astra_copyright' );


/* ============================================================================
 * PAGE BOOTSTRAP HELPER
 *
 * Site owners installing this theme fresh have 14 pages to create. The
 * helper below registers an admin notice with a one-click action that
 * creates any missing pages with the correct slugs. Each page-{slug}.php
 * template also contains full canonical content, so even if the admin
 * leaves the page body empty, the page still renders something usable.
 * ============================================================================ */

/**
 * Authoritative slug → title map for the 14 pages the blueprint expects.
 * Slugs MUST match `page-{slug}.php` template filenames.
 *
 * @return array<string,string>
 */
function helpnagaland_child_required_pages() {
	return array(
		'report-alcohol'    => __( 'Report illegal alcohol', 'helpnagaland-child' ),
		'report-drugs'      => __( 'Report drug activity', 'helpnagaland-child' ),
		'map'               => __( 'Public map', 'helpnagaland-child' ),
		'check-status'      => __( 'Check report status', 'helpnagaland-child' ),
		'transparency'      => __( 'Monthly transparency', 'helpnagaland-child' ),
		'about'             => __( 'About', 'helpnagaland-child' ),
		'contact'           => __( 'Contact', 'helpnagaland-child' ),
		'terms'             => __( 'Terms of Use', 'helpnagaland-child' ),
		'privacy'           => __( 'Privacy Policy', 'helpnagaland-child' ),
		'disclaimer'        => __( 'Content Disclaimer', 'helpnagaland-child' ),
		'source-protection' => __( 'Source Protection Policy', 'helpnagaland-child' ),
		'takedown'          => __( 'Takedown and Appeal', 'helpnagaland-child' ),
		'editorial-policy'  => __( 'Editorial Policy', 'helpnagaland-child' ),
		'cookies'           => __( 'Cookie Policy', 'helpnagaland-child' ),
	);
}


/**
 * Dashboard notice prompting site owners to create any missing pages.
 *
 * @return void
 */
function helpnagaland_child_missing_pages_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && 'dashboard' !== $screen->id && 'themes' !== $screen->id ) {
		return;
	}

	$missing = array();
	foreach ( helpnagaland_child_required_pages() as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			$missing[] = $slug;
		}
	}
	if ( empty( $missing ) ) {
		return;
	}

	$action_url = wp_nonce_url(
		admin_url( 'admin-post.php?action=helpnagaland_child_create_pages' ),
		'helpnagaland_child_create_pages'
	);
	?>
	<div class="notice notice-warning">
		<p>
			<strong><?php esc_html_e( 'Help Nagaland Child:', 'helpnagaland-child' ); ?></strong>
			<?php
			printf(
				/* translators: %d is the number of missing pages. */
				esc_html( _n(
					'%d required page is missing. Create it so the site navigation and templates wire up correctly.',
					'%d required pages are missing. Create them so the site navigation and templates wire up correctly.',
					count( $missing ),
					'helpnagaland-child'
				) ),
				(int) count( $missing )
			);
			?>
		</p>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( $action_url ); ?>">
				<?php esc_html_e( 'Create missing pages', 'helpnagaland-child' ); ?>
			</a>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'helpnagaland_child_missing_pages_notice' );


/**
 * admin-post handler that creates the missing pages. Each page is
 * created as a published WP Page with its canonical slug. No body
 * content is inserted; the `page-{slug}.php` template supplies it.
 *
 * @return void
 */
function helpnagaland_child_handle_create_pages() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Insufficient permissions.', 'helpnagaland-child' ) );
	}
	check_admin_referer( 'helpnagaland_child_create_pages' );

	$created = 0;
	foreach ( helpnagaland_child_required_pages() as $slug => $title ) {
		if ( get_page_by_path( $slug ) ) {
			continue;
		}
		$post_id = wp_insert_post(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'post_title'     => wp_strip_all_tags( $title ),
				'post_name'      => $slug,
				'post_content'   => '',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
			),
			true
		);
		if ( ! is_wp_error( $post_id ) && $post_id ) {
			$created++;
		}
	}

	$redirect = add_query_arg(
		array(
			'helpnagaland_child_created' => (int) $created,
		),
		admin_url( 'index.php' )
	);
	wp_safe_redirect( $redirect );
	exit;
}
add_action( 'admin_post_helpnagaland_child_create_pages', 'helpnagaland_child_handle_create_pages' );


/**
 * Confirmation notice after the admin creates pages.
 *
 * @return void
 */
function helpnagaland_child_created_pages_notice() {
	if ( ! isset( $_GET['helpnagaland_child_created'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}
	$count = (int) $_GET['helpnagaland_child_created']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	?>
	<div class="notice notice-success is-dismissible">
		<p>
			<?php
			printf(
				/* translators: %d is the count of pages created. */
				esc_html( _n( '%d page created.', '%d pages created.', $count, 'helpnagaland-child' ) ),
				$count
			);
			?>
		</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'helpnagaland_child_created_pages_notice' );
