# SEO setup checklist for Clean Nagaland

This theme ships production-grade SEO infrastructure, but four
things still need configuration by a human: WordPress itself, Rank
Math Pro, Search Console / Bing Webmaster, and your page-level
content. Work through each section in order.

Nothing below requires touching code.

---

## 0. What the theme already does for you

No action on these — they run automatically as long as the theme is
active and the helpnagaland-core plugin is installed.

- **Organization schema** (rich Knowledge Graph entry with name
  "Clean Nagaland", alternateName "Help Nagaland", parent
  organization "Nagaland Me", area served "Nagaland, India", logo,
  same-as links to your sibling sites).
- **WebSite schema with SearchAction** on the homepage so Google
  can render the sitelinks search box under your brand result.
- **Page-type schema upgrade** — on pages where it applies, Rank
  Math's generic `WebPage` gets promoted to the more specific
  `AboutPage`, `ContactPage`, `FAQPage`, or `CollectionPage`.
- **`noindex`** forced on `/report-alcohol/`, `/report-drugs/`,
  `/check-status/` — these pages are per-reporter and must not be
  Google-indexed.
- **Favicon and apple-touch-icon** fallbacks pointing at the theme
  logo (until you upload a Site Icon in the Customiser, at which
  point WordPress takes over).
- **Open Graph and Twitter Card defaults** — og:site_name, og:type,
  fallback og:image (1200x900 screenshot.png), locale.
- **Meta description fallback** when a page has no admin-entered
  description.
- **Self-hosted Leaflet** (map) and self-hosted optional Inter fonts
  so no third-party network call is made for anything that affects
  Core Web Vitals.
- **Security + privacy headers** (`X-Content-Type-Options`,
  `Referrer-Policy`, `X-Frame-Options`, `Permissions-Policy`,
  `Cross-Origin-Opener-Policy`) that SSL Labs and Mozilla
  Observatory grade toward A+.

---

## 1. WordPress settings (5 minutes)

### 1.1  Settings → General
- **Site Title:** exactly `Clean Nagaland`
- **Tagline:** something that reads as a sentence, e.g. `Anonymous
  civic reporting by Nagaland Me.` This gets used by Rank Math as
  the homepage meta description fallback.
- **WordPress Address** and **Site Address** both `https://helpnagaland.com`
  — notice the https. No trailing slash.
- **Timezone:** `Asia/Kolkata` (IST).

### 1.2  Settings → Reading
- **Your homepage displays:** A static page → **Home** (front-page
  template you already have).
- **Search engine visibility:** unchecked (crawlers are allowed).

### 1.3  Settings → Permalinks
- **Post name** structure. URLs must look like
  `/report-alcohol/`, `/faq/`, `/about/` — not `/?p=42`.

### 1.4  Customiser → Site Identity
- **Site Icon:** upload a 512×512 PNG of the Clean Nagaland
  shield/check logo. This becomes your favicon and apple-touch-icon
  in every modern browser. Until you do, the theme falls back to
  the SVG logo in `assets/img/logo.svg`.

---

## 2. Rank Math Pro configuration (15 minutes)

### 2.1  Rank Math → General Settings
- **Links:** on. (Opens external links in new tab, adds noopener.)
- **Images:** turn **Add Missing Alt Attributes** on. Rank Math Pro
  will auto-fill `alt=""` on any reporter-submitted or legacy
  images that lack one.
- **Breadcrumbs:** leave on. The theme does not emit a visible
  breadcrumb bar today, but Rank Math still publishes
  `BreadcrumbList` schema which Google uses for the path shown in
  search results.

### 2.2  Rank Math → Titles & Meta
- **Global Meta → Robots Meta:** the boxes already set by the
  theme (noindex on submission pages) should be reflected here.
  If not, tick `Apply noindex to:` then add the slugs
  `report-alcohol, report-drugs, check-status`.
- **Separator:** use `—` (em-dash). Matches the footer copyright
  line.
- **Homepage → Title:** `%sitename% — Anonymous reporting in Nagaland`
- **Homepage → Description:** same sentence you wrote in the
  WordPress Tagline (one source of truth is better than two).
- **Local SEO (Pro):**
  - **Person or Company:** Company
  - **Name:** `Clean Nagaland`
  - **Alternative Name:** `Help Nagaland`
  - **About Page:** pick `/about/`.
  - **Contact Page:** pick `/contact/`.
  - **Logo:** upload the logo PNG (not SVG — Google's local-SEO
    parsing prefers raster).
  - **Email / Phone:** your operational address.
  - **Address:** state `Nagaland`, country `IN`. Street is
    optional — leave blank if you'd rather not publish it.

### 2.3  Rank Math → Sitemap Settings
- **General → Include Images:** on.
- **Post Type → Pages:** included.
- **Post Type → Posts:** included (if you blog).
- **Taxonomy:** exclude uncategorised tag archives unless you use
  them.
- **Exclude:** any slug that should not appear in the sitemap.
  At minimum put `report-alcohol, report-drugs, check-status`
  here — they are noindexed anyway but keeping them out of the
  sitemap prevents "submitted but noindexed" warnings in Search
  Console.

### 2.4  Rank Math → Instant Indexing (Pro)
- **IndexNow:** turn it on. Instant push to Bing and Yandex.
- **Google Instant Indexing:** follow Rank Math's auth flow. Turn
  on for Pages. (Google currently restricts this to jobs and
  live-stream types; Bing via IndexNow is where you actually win.)

### 2.5  Rank Math → Schema (the page-level work)
For each of these pages, open it in WordPress, scroll to the Rank
Math box, click Schema, and pick the type:

| Page slug | Schema type |
|---|---|
| `/faq/` | FAQPage (add each Q&A via Rank Math's block) |
| `/how-it-works/` | HowTo (add each step via Rank Math's block) |
| `/transparency/` | Dataset (name: "Clean Nagaland monthly transparency") |
| `/media-kit/` | AboutPage (inherits from theme hint) |
| `/partners/` | CollectionPage (inherits from theme hint) |
| `/community-guidelines/` | WebPage (default) |

For every other page, let Rank Math auto-pick — the theme already
tells it the right type via the `rank_math/json_ld` filter.

### 2.6  Rank Math → Analytics
- Connect Search Console here. Rank Math will pull query + CTR
  data into your WordPress dashboard.

---

## 3. Google Search Console (10 minutes)

1. Go to `https://search.google.com/search-console/` and sign in.
2. **Add property** → Domain property → `helpnagaland.com` (not URL
   prefix — Domain covers www and https and subdomains).
3. Verify ownership by adding the DNS TXT record your registrar
   shows (Hostinger has a one-click button for this).
4. Once verified, go to **Sitemaps** → paste
   `https://helpnagaland.com/sitemap_index.xml` → Submit.
5. **Settings → Preferred name** → type `Clean Nagaland`. (This is
   separate from the schema signal; Google uses it as one of
   several inputs when deciding which name to show on the SERP.)
6. **URL Inspection** → run the homepage, confirm "Live test" shows
   your Organization and WebSite schema. No red errors.

Wait 2–7 days. Traffic data then starts showing in Performance.

---

## 4. Bing Webmaster Tools (3 minutes)

1. `https://www.bing.com/webmasters`. Sign in.
2. **Import from Google Search Console** — one click. Bing copies
   your verified property and sitemap across.
3. If you want to be thorough, also run the **Site Scan** there
   once. It catches things Google is quieter about (missing alt
   text, low content count, weird redirects).

---

## 5. Verify the schema shipped correctly

Open any of these in a browser, one by one:

- `https://search.google.com/test/rich-results` — paste your
  homepage URL. Expect zero errors. Expect a "Detected" list
  including Organization, WebSite, Sitelinks search box.
- `https://validator.schema.org/` — paste the same URL. Confirm
  no "Error" rows.
- `https://metatags.io/` — preview your homepage's Twitter card
  and Facebook preview at Open Graph level.

If Rich Results shows "Warning: logo field missing" for
Organization: you haven't uploaded a PNG yet via Customiser Site
Icon. Do that, re-test.

---

## 6. Speed / Core Web Vitals (affects ranking)

The theme already:
- Self-hosts everything (no Google Fonts network call by default).
- Ships Leaflet and marker-cluster under `/lib/`.
- Uses `loading="lazy"` on below-the-fold images.
- Uses `decoding="async"` on images.

Things you should still do on the server:
1. **Turn on HTTP/2 or HTTP/3** in Hostinger's panel.
2. **Enable Brotli** compression if it's not already on.
3. **Enable the page cache** plugin of your choice (LiteSpeed Cache
   if you're on LiteSpeed, else WP Super Cache or Cloudflare APO).
4. **Test at pagespeed.web.dev** for the homepage. You should see
   LCP < 2.5s and CLS < 0.1 on the mobile profile. If LCP is high,
   the culprit is usually a slow first-byte from the host — not
   the theme.

---

## 7. Operator content homework

These aren't SEO switches — they're content quality signals that
Google uses heavily.

- **Write a meaningful page excerpt** (the WordPress "Excerpt"
  field) on every non-noindexed page. The theme's description
  fallback uses it.
- **Pick a featured image** (1200×630 min) on every page that has
  interesting visual content. It becomes the og:image for social
  shares and gets picked up by Rank Math for Twitter cards.
- **Link related pages from each other.** The footer helps, but
  inline links inside the page body (e.g. "See our
  [Takedown policy](/takedown/)") are worth far more to Google than
  footer links alone.
- **Keep page titles under 60 characters** so they don't truncate
  in search results.
- **Never mass-delete pages.** If you remove a page, use Rank Math
  → Redirections to 301 the old URL to the closest surviving page.
  A 404 pattern hurts the whole domain.

---

## 8. Brand-name signal (bridging Help Nagaland ↔ Clean Nagaland)

Because your domain string is `helpnagaland.com` but your brand is
Clean Nagaland, Google relies on several signals to connect the
two. The theme already emits all of them:

- `<meta name="application-name" content="Clean Nagaland" />`
- Organization `name: Clean Nagaland`
- Organization `alternateName: [Help Nagaland, CleanNagaland]`
- WebSite `name: Clean Nagaland`, `alternateName: Help Nagaland`
- og:site_name = Clean Nagaland

That's the correct pattern. Google will show "Clean Nagaland" as
the site name in the SERP typically within 2–4 weeks of indexing.

**Optional insurance:** register `cleannagaland.com` at your
registrar for INR ~1,000/year and 301-redirect it here. It
captures anyone who types the brand name directly into the
address bar.

---

## 9. What to check a month after launch

- Search Console → Performance → Queries. You want at least a few
  brand queries (Clean Nagaland, Help Nagaland, "report alcohol
  Nagaland") appearing with non-zero impressions.
- Search Console → Coverage. Zero errors. Warnings for the noindex
  pages are expected and can be ignored.
- Rich Results Test on the homepage still passes.
- `site:helpnagaland.com` on Google shows your pages indexed (not
  cached error pages, not a soft-404, not duplicate title
  warnings).

If anything in that list is off at the 1-month mark, send the
screenshots and we debug.
