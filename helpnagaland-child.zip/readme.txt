=== Help Nagaland Child ===
Contributors:      nagalandme
Requires at least: 6.0
Tested up to:      6.7
Requires PHP:      7.4
Stable tag:        1.1.8
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html
Theme URI:         https://helpnagaland.com/
Template:          astra
Tags:              astra, child-theme, dark, civic-tech, nagaland, accessibility-ready

Custom Astra child theme for helpnagaland.com, the Clean Nagaland civic
reporting platform by Nagaland Me.

== Description ==

Help Nagaland Child is the presentation layer for the Clean Nagaland
platform. It pairs with the `helpnagaland-core` plugin to deliver:

* A branded homepage with hero, feature grid, promise strip and CTA.
* Fourteen page templates covering submission flows (alcohol, drugs,
  map, status check, transparency) and nine legal/information pages.
* A custom header with skip-link, sticky brand bar and accessible
  mobile nav.
* A branded footer with a permanent disclaimer strip, legal links and
  Nagaland Me attribution.
* A dark-theme design system built on CSS custom properties.

== Privacy and compliance defaults ==

The theme is tuned to match the non-negotiable rules of the Clean
Nagaland specification:

* No third-party analytics, pixels, cookies, or trackers.
* System fonts by default. Inter can be self-hosted (drop the woff2
  files into `assets/fonts/`) or enabled via Google Fonts through an
  explicit opt-in filter.
* Baseline security headers on every public request.
* `noindex, nofollow, noarchive` on submission and status-check pages.
* A permanent disclaimer strip in the footer, visible on every page.

== Installation ==

1. Install and activate the Astra parent theme.
2. Upload `helpnagaland-child` to `/wp-content/themes/` and activate.
3. Install and activate the `helpnagaland-core` plugin.
4. When the theme is activated, a dashboard notice offers to create
   the 14 required pages (slugs match `page-{slug}.php` template
   filenames). Click "Create missing pages".
5. Under Appearance → Menus, assign menus to the Primary, "Help
   Nagaland: Footer Links" and "Help Nagaland: Footer Legal"
   locations.

== Opt-in filters ==

* `helpnagaland_child_use_google_fonts` — set to true to load Inter
  from Google Fonts. Default false. Site owners who enable this must
  update the Cookie/Privacy policy.
* `helpnagaland_child_noindex_slugs` — customize the list of page
  slugs that get noindexed.
* `helpnagaland_child_contact_email`, `_press_email`, `_takedown_email`
  — customize the contact addresses shown on the Contact and
  Takedown pages.

== Changelog ==

= 1.1.0 =
* Added: custom header.php with skip-link, sticky brand bar and
  accessible mobile nav toggle.
* Added: fourteen page templates (5 submission flows + 9 legal).
* Added: supplemental CSS modules (variables, typography, layout,
  components, fonts).
* Added: minimal untracked theme.js for the mobile nav.
* Added: SVG logo and attribution mark.
* Added: baseline security response headers.
* Added: noindex enforcement on submission and status-check pages.
* Added: admin notice + one-click "create required pages" action.
* Added: translation template.
* Changed: Google Fonts are now opt-in. Default is system font stack.
* Changed: logo URL in Organization JSON-LD now points to the SVG logo
  rather than screenshot.png.
* Fixed: footer.php now correctly closes the #page wrapper opened by
  header.php.

= 1.0.0 =
* Initial release: style.css, functions.php, front-page.php, footer.php
  and 404.php.
