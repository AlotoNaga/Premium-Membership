<?php
/**
 * Template — Content Disclaimer
 *
 * Thin shell. Whatever the admin types in the WordPress editor is what
 * appears on the page.
 *
 * @package HelpNagalandChild
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-page hnc-page-disclaimer">

	<header class="hnc-page-header">
		<span class="hnc-page-eyebrow"><?php esc_html_e( 'Legal', 'helpnagaland-child' ); ?></span>
		<h1 class="hnc-page-title"><?php the_title(); ?></h1>
	</header>

	<article class="hnc-prose">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				the_content();
			}
		}
		?>
	</article>

</main>

<?php
get_footer();
