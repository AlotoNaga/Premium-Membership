<?php
/**
 * Clean Nagaland SEO additions.
 *
 * Coexistence contract with Rank Math Pro:
 *
 *   Rank Math handles: canonical URLs, title templates, meta
 *   descriptions (when the admin wrote one), sitemap, robots.txt,
 *   breadcrumbs, Open Graph basics, Twitter cards, BreadcrumbList
 *   and WebPage schema, 404 redirects, Search Console integration,
 *   image SEO, local SEO, sitelinks preferences, and structured-data
 *   previews.
 *
 *   This class adds what Rank Math does NOT emit by default for a
 *   civic-reporting platform:
 *
 *     - Rich Organization schema (PostalAddress, areaServed,
 *       parentOrganization, alternateName, sameAs, founder).
 *     - WebSite schema with SearchAction so Google can render the
 *       sitelinks search box under the brand result.
 *     - Page-type hints — AboutPage / ContactPage / FAQPage on the
 *       pages that qualify — pushed into Rank Math's JSON-LD graph.
 *     - Default Open Graph image fallback.
 *     - Favicon and apple-touch-icon link tags from the theme logo,
 *       used when the admin has not uploaded a site icon.
 *     - Meta description fallback when a page has no admin-entered
 *       description and Rank Math can't synthesise one.
 *     - Helpful hreflang-style `x-default` canonical for the root.
 *
 * Everything is safely idempotent — if Rank Math's graph already
 * carries an entity, we merge our fields in rather than duplicating
 * the @type, which Google's Rich Results test would flag.
 *
 * @package HelpNagalandChild
 * @since   1.1.7
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HelpNagalandChild_SEO
 */
final class HelpNagalandChild_SEO {

	/**
	 * Wire all hooks.
	 *
	 * @return void
	 */
	public static function init() {
		// Schema graph emission.
		add_action( 'wp_head', array( __CLASS__, 'emit_standalone_schema' ), 5 );
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'extend_rank_math_schema' ), 20, 2 );

		// Icons (favicon / apple-touch-icon).
		add_action( 'wp_head', array( __CLASS__, 'emit_icons' ), 4 );

		// Open Graph / Twitter Card defaults.
		add_filter( 'rank_math/opengraph/facebook/og_image', array( __CLASS__, 'fallback_og_image' ), 99 );
		add_filter( 'rank_math/opengraph/twitter/twitter_image', array( __CLASS__, 'fallback_og_image' ), 99 );
		// Rank Math's OG filters are namespaced by network/property.
		// For og:site_name the correct hook is the Facebook one —
		// `rank_math/opengraph/site_name` (no network) is never fired
		// in Rank Math's codebase so our earlier registration was a
		// silent no-op. Register against the real hook here.
		add_filter( 'rank_math/opengraph/facebook/og_site_name', array( __CLASS__, 'og_site_name' ), 99 );

		// Standalone OG fallback for when Rank Math is inactive.
		add_action( 'wp_head', array( __CLASS__, 'emit_og_fallback' ), 6 );

		// Meta description fallback for both Rank Math and bare WP.
		add_filter( 'rank_math/frontend/description', array( __CLASS__, 'description_fallback' ) );
		add_action( 'wp_head', array( __CLASS__, 'emit_meta_description_fallback' ), 3 );

		// Add `name` meta for Google's expected site-name signal.
		add_action( 'wp_head', array( __CLASS__, 'emit_site_name_meta' ), 3 );
	}


	/* ==================================================================
	 * ORGANIZATION METADATA — the single source of truth.
	 *
	 * These values feed both the standalone emit path (when Rank Math
	 * is not handling schema) and the merge path (when it is).
	 * ================================================================== */

	/**
	 * Return the canonical Organization schema as an associative array.
	 * Filterable via `helpnagaland_child_organization_schema` so a
	 * site owner can refine contact details, physical address, or
	 * social profiles without editing this file.
	 *
	 * @return array
	 */
	public static function organization_schema() {
		$logo_url = get_stylesheet_directory_uri() . '/assets/img/logo.svg';
		$og_image = self::default_image_url();

		$schema = array(
			'@context'           => 'https://schema.org',
			'@type'              => 'Organization',
			'@id'                => home_url( '/#organization' ),
			'name'               => 'Clean Nagaland',
			'alternateName'      => array( 'Help Nagaland', 'CleanNagaland' ),
			'url'                => home_url( '/' ),
			'logo'               => array(
				'@type'    => 'ImageObject',
				'url'      => $logo_url,
				'width'    => 512,
				'height'   => 512,
				'caption'  => 'Clean Nagaland',
			),
			'image'              => array(
				'@type'  => 'ImageObject',
				'url'    => $og_image,
				'width'  => 1200,
				'height' => 900,
			),
			'description'        => 'Clean Nagaland is a civic reporting platform by Nagaland Me that lets residents report illegal liquor and drug activity anonymously and see transparent monthly outcomes.',
			'areaServed'         => array(
				'@type' => 'AdministrativeArea',
				'name'  => 'Nagaland, India',
			),
			'address'            => array(
				'@type'           => 'PostalAddress',
				'addressRegion'   => 'Nagaland',
				'addressCountry'  => 'IN',
			),
			'parentOrganization' => array(
				'@type' => 'Organization',
				'name'  => 'Nagaland Me',
				'url'   => 'https://nagaland.me/',
			),
			'founder'            => array(
				'@type' => 'Organization',
				'name'  => 'Nagaland Me',
				'url'   => 'https://nagaland.me/',
			),
			'foundingDate'       => '2026',
			'sameAs'             => array(
				'https://nagaland.me/',
				'https://nagalandai.com/',
				'https://nagalandnewstoday.com/',
			),
			'knowsAbout'         => array(
				'civic technology',
				'harm reduction',
				'public safety',
				'anonymous reporting',
			),
		);

		return apply_filters( 'helpnagaland_child_organization_schema', $schema );
	}

	/**
	 * Return the canonical WebSite schema including the SearchAction
	 * that powers Google's sitelinks search box.
	 *
	 * @return array
	 */
	public static function website_schema() {
		$schema = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'WebSite',
			'@id'             => home_url( '/#website' ),
			'url'             => home_url( '/' ),
			'name'            => 'Clean Nagaland',
			'alternateName'   => 'Help Nagaland',
			'description'     => get_bloginfo( 'description', 'display' ),
			'inLanguage'      => get_bloginfo( 'language' ),
			'publisher'       => array( '@id' => home_url( '/#organization' ) ),
			'potentialAction' => array(
				array(
					'@type'       => 'SearchAction',
					'target'      => array(
						'@type'       => 'EntryPoint',
						'urlTemplate' => home_url( '/?s={search_term_string}' ),
					),
					'query-input' => 'required name=search_term_string',
				),
			),
		);
		return apply_filters( 'helpnagaland_child_website_schema', $schema );
	}


	/* ==================================================================
	 * PATH 1 — STANDALONE EMIT
	 *
	 * When Rank Math is inactive, we emit our own Organization and
	 * WebSite schema plus any page-type schema directly to wp_head.
	 * ================================================================== */

	/**
	 * Emit Organization + WebSite + current page schema when Rank
	 * Math is NOT handling schema output.
	 *
	 * @return void
	 */
	public static function emit_standalone_schema() {
		if ( self::rank_math_schema_active() ) {
			return;
		}

		$graph = array();
		$graph[] = self::organization_schema();
		$graph[] = self::website_schema();

		$page = self::current_page_schema();
		if ( ! empty( $page ) ) {
			$graph[] = $page;
		}

		// One combined @graph envelope is what Google prefers when we
		// emit multiple entities from one page.
		$envelope = array(
			'@context' => 'https://schema.org',
			'@graph'   => array_map(
				static function ( $entity ) {
					unset( $entity['@context'] );
					return $entity;
				},
				$graph
			),
		);

		echo "\n<script type=\"application/ld+json\">";
		echo wp_json_encode( $envelope, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		echo "</script>\n";
	}

	/**
	 * Build page-type schema (AboutPage / ContactPage / FAQPage /
	 * CollectionPage) based on the current slug. Returns an empty
	 * array for slugs with no special mapping.
	 *
	 * @return array
	 */
	protected static function current_page_schema() {
		if ( ! is_page() ) {
			return array();
		}
		$post = get_queried_object();
		if ( ! $post || empty( $post->post_name ) ) {
			return array();
		}
		$slug = (string) $post->post_name;
		$type = self::page_type_for_slug( $slug );
		if ( '' === $type ) {
			return array();
		}
		$permalink = get_permalink( $post );
		$schema = array(
			'@context'    => 'https://schema.org',
			'@type'       => $type,
			'@id'         => $permalink . '#webpage',
			'url'         => $permalink,
			'name'        => get_the_title( $post ),
			'isPartOf'    => array( '@id' => home_url( '/#website' ) ),
			'about'       => array( '@id' => home_url( '/#organization' ) ),
			'publisher'   => array( '@id' => home_url( '/#organization' ) ),
			'inLanguage'  => get_bloginfo( 'language' ),
		);
		if ( ! empty( $post->post_modified_gmt ) ) {
			$schema['dateModified'] = gmdate( 'c', strtotime( (string) $post->post_modified_gmt . ' UTC' ) );
		}
		if ( ! empty( $post->post_date_gmt ) ) {
			$schema['datePublished'] = gmdate( 'c', strtotime( (string) $post->post_date_gmt . ' UTC' ) );
		}
		return $schema;
	}

	/**
	 * Map a page slug to the most specific schema.org page type.
	 *
	 * @param string $slug Page slug.
	 * @return string schema.org type name, or '' if none applies.
	 */
	protected static function page_type_for_slug( $slug ) {
		$map = array(
			'about'                => 'AboutPage',
			'about-us'             => 'AboutPage',
			'contact'              => 'ContactPage',
			'faq'                  => 'FAQPage',
			'privacy'              => 'WebPage',
			'privacy-policy'       => 'WebPage',
			'terms'                => 'WebPage',
			'terms-of-use'         => 'WebPage',
			'cookies'              => 'WebPage',
			'cookie-policy'        => 'WebPage',
			'disclaimer'           => 'WebPage',
			'content-disclaimer'   => 'WebPage',
			'source-protection'    => 'WebPage',
			'takedown'             => 'WebPage',
			'editorial-policy'     => 'WebPage',
			'data-and-privacy'     => 'WebPage',
			'community-guidelines' => 'WebPage',
			'how-it-works'         => 'WebPage',
			'safety-and-self-help' => 'WebPage',
			'transparency'         => 'CollectionPage',
			'map'                  => 'WebPage',
			'partners'             => 'CollectionPage',
			'media-kit'            => 'AboutPage',
			'volunteer'            => 'WebPage',
		);
		$map = apply_filters( 'helpnagaland_child_page_type_map', $map );
		return isset( $map[ $slug ] ) ? (string) $map[ $slug ] : '';
	}


	/* ==================================================================
	 * PATH 2 — MERGE WITH RANK MATH
	 *
	 * When Rank Math is active, we don't emit our own graph; we
	 * enrich theirs.
	 * ================================================================== */

	/**
	 * Extend Rank Math's JSON-LD graph with:
	 *
	 *   - Missing Organization fields (address, parentOrganization,
	 *     alternateName, extra sameAs entries).
	 *   - A WebSite entry with SearchAction, if theirs is missing one.
	 *   - A page-type refinement — if Rank Math used a generic
	 *     WebPage, upgrade it to AboutPage/ContactPage/FAQPage where
	 *     appropriate.
	 *
	 * @param array $data Rank Math's in-progress JSON-LD array.
	 * @return array
	 */
	public static function extend_rank_math_schema( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}

		$our_org = self::organization_schema();

		$found_org = false;
		$found_website = false;
		foreach ( $data as $key => $entity ) {
			if ( ! is_array( $entity ) ) {
				continue;
			}
			$type = isset( $entity['@type'] ) ? $entity['@type'] : '';
			$types = is_array( $type ) ? $type : array( $type );

			if ( in_array( 'Organization', $types, true ) || in_array( 'NewsMediaOrganization', $types, true ) ) {
				$found_org = true;
				foreach ( array( 'address', 'parentOrganization', 'founder', 'foundingDate', 'knowsAbout', 'areaServed' ) as $field ) {
					if ( empty( $entity[ $field ] ) && isset( $our_org[ $field ] ) ) {
						$data[ $key ][ $field ] = $our_org[ $field ];
					}
				}
				if ( empty( $entity['alternateName'] ) ) {
					$data[ $key ]['alternateName'] = $our_org['alternateName'];
				}
				$existing = isset( $entity['sameAs'] ) && is_array( $entity['sameAs'] ) ? $entity['sameAs'] : array();
				$data[ $key ]['sameAs'] = array_values(
					array_unique( array_merge( $existing, $our_org['sameAs'] ) )
				);
			}

			if ( in_array( 'WebSite', $types, true ) ) {
				$found_website = true;
				if ( empty( $entity['potentialAction'] ) ) {
					$data[ $key ]['potentialAction'] = self::website_schema()['potentialAction'];
				}
				if ( empty( $entity['alternateName'] ) ) {
					$data[ $key ]['alternateName'] = 'Help Nagaland';
				}
			}

			// Upgrade a generic WebPage to a more specific type when
			// the slug qualifies. Rank Math typically emits WebPage;
			// we don't want to duplicate it, so we transform it in
			// place.
			if ( in_array( 'WebPage', $types, true ) && is_page() ) {
				$post = get_queried_object();
				if ( $post && ! empty( $post->post_name ) ) {
					$better_type = self::page_type_for_slug( (string) $post->post_name );
					if ( '' !== $better_type && 'WebPage' !== $better_type ) {
						$data[ $key ]['@type'] = $better_type;
					}
				}
			}
		}

		if ( ! $found_website && is_front_page() ) {
			$data['HelpNagalandWebSite'] = self::website_schema();
		}
		if ( ! $found_org ) {
			$data['HelpNagalandOrganization'] = self::organization_schema();
		}

		return $data;
	}


	/* ==================================================================
	 * FAVICON + ICONS
	 *
	 * WP's Customiser → Site Icon upload remains the supported path.
	 * When the admin has uploaded one, WP emits <link rel="icon">
	 * automatically and we stay out of the way. When they haven't,
	 * we emit fallbacks pointing at the theme logo so Google and
	 * social cards always have something to show.
	 * ================================================================== */

	/**
	 * Emit icon / apple-touch-icon fallback tags when the WP site
	 * icon is not set.
	 *
	 * @return void
	 */
	public static function emit_icons() {
		if ( function_exists( 'has_site_icon' ) && has_site_icon() ) {
			return;
		}
		$logo_url = get_stylesheet_directory_uri() . '/assets/img/logo.svg';
		$screenshot = self::default_image_url();
		printf(
			"<link rel=\"icon\" type=\"image/svg+xml\" href=\"%s\" />\n",
			esc_url( $logo_url )
		);
		printf(
			"<link rel=\"apple-touch-icon\" href=\"%s\" />\n",
			esc_url( $screenshot )
		);
	}


	/* ==================================================================
	 * OPEN GRAPH / TWITTER DEFAULTS
	 * ================================================================== */

	/**
	 * Fallback Open Graph / Twitter image used when a page has no
	 * featured image and Rank Math has nothing else.
	 *
	 * @param string $image Current image URL (possibly empty).
	 * @return string
	 */
	public static function fallback_og_image( $image ) {
		if ( is_string( $image ) && '' !== trim( $image ) ) {
			return $image;
		}
		return self::default_image_url();
	}

	/**
	 * Force the Open Graph site_name to "Clean Nagaland" regardless
	 * of what the WP Site Title is set to, because some site owners
	 * leave it as the default. Filterable for override.
	 *
	 * @param string $name Incoming site name.
	 * @return string
	 */
	public static function og_site_name( $name ) {
		return (string) apply_filters( 'helpnagaland_child_og_site_name', 'Clean Nagaland', $name );
	}

	/**
	 * Emit Open Graph and Twitter Card tags directly when Rank Math
	 * is not handling them. No-op when Rank Math is active so we
	 * don't duplicate tags.
	 *
	 * @return void
	 */
	public static function emit_og_fallback() {
		if ( self::rank_math_active() ) {
			return;
		}

		$title       = wp_get_document_title();
		$description = self::current_description();
		$url         = self::current_canonical_url();
		$image       = self::default_image_url();
		$site_name   = (string) apply_filters( 'helpnagaland_child_og_site_name', 'Clean Nagaland', 'Clean Nagaland' );
		$type        = is_front_page() ? 'website' : 'article';
		$locale      = str_replace( '-', '_', get_bloginfo( 'language' ) );

		$tags = array(
			'og:title'       => $title,
			'og:description' => $description,
			'og:url'         => $url,
			'og:site_name'   => $site_name,
			'og:type'        => $type,
			'og:image'       => $image,
			'og:locale'      => $locale,
			'twitter:card'        => 'summary_large_image',
			'twitter:title'       => $title,
			'twitter:description' => $description,
			'twitter:image'       => $image,
		);

		echo "\n";
		foreach ( $tags as $prop => $content ) {
			if ( '' === (string) $content ) {
				continue;
			}
			$attr = ( 0 === strpos( $prop, 'og:' ) ) ? 'property' : 'name';
			printf(
				"<meta %s=\"%s\" content=\"%s\" />\n",
				esc_attr( $attr ),
				esc_attr( $prop ),
				esc_attr( (string) $content )
			);
		}
	}


	/* ==================================================================
	 * META DESCRIPTION FALLBACK
	 * ================================================================== */

	/**
	 * Supply a description to Rank Math when the admin hasn't
	 * entered one on the page.
	 *
	 * @param string $description Incoming description.
	 * @return string
	 */
	public static function description_fallback( $description ) {
		$description = (string) $description;
		if ( '' !== trim( $description ) ) {
			return $description;
		}
		return self::current_description();
	}

	/**
	 * Emit a <meta name="description"> tag directly when Rank Math
	 * is not active and WordPress doesn't otherwise provide one.
	 *
	 * @return void
	 */
	public static function emit_meta_description_fallback() {
		if ( self::rank_math_active() ) {
			return;
		}
		$description = self::current_description();
		if ( '' === $description ) {
			return;
		}
		printf(
			"<meta name=\"description\" content=\"%s\" />\n",
			esc_attr( $description )
		);
	}

	/**
	 * Emit an `application-name` meta tag and `og:site_name`-style
	 * hint so Google picks up the brand name even on hosts where
	 * the WP Site Title was left as the default.
	 *
	 * @return void
	 */
	public static function emit_site_name_meta() {
		echo "<meta name=\"application-name\" content=\"Clean Nagaland\" />\n";
	}


	/* ==================================================================
	 * HELPERS
	 * ================================================================== */

	/**
	 * True when Rank Math's core plugin is active.
	 *
	 * @return bool
	 */
	public static function rank_math_active() {
		return class_exists( 'RankMath' ) || function_exists( 'rank_math' );
	}

	/**
	 * True when Rank Math is expected to emit schema on this request.
	 *
	 * @return bool
	 */
	public static function rank_math_schema_active() {
		return self::rank_math_active() || class_exists( 'RankMath\Schema\Plugin' );
	}

	/**
	 * URL of the default Open Graph / social image.
	 *
	 * @return string
	 */
	public static function default_image_url() {
		return (string) apply_filters(
			'helpnagaland_child_default_og_image',
			get_stylesheet_directory_uri() . '/screenshot.png'
		);
	}

	/**
	 * Return the canonical URL of the current request without
	 * double-prepending the site subdirectory.
	 *
	 * The earlier implementation used
	 * `home_url( add_query_arg( null, null ) )`, which fails on
	 * WordPress installs living in a subdirectory (e.g.
	 * `https://example.com/blog/`). `add_query_arg( null, null )`
	 * returns the full request URI including the `/blog/` prefix;
	 * `home_url()` then concatenates the site's home path again,
	 * producing URLs like `https://example.com/blog/blog/page/`.
	 * We therefore build the non-singular fallback URL from the
	 * scheme + host + raw request URI directly, and delegate
	 * singular pages to `get_permalink()` which handles subdirs
	 * correctly on its own.
	 *
	 * @return string Escaped absolute URL.
	 */
	protected static function current_canonical_url() {
		if ( is_singular() ) {
			$permalink = get_permalink();
			if ( is_string( $permalink ) && '' !== $permalink ) {
				return $permalink;
			}
		}
		if ( is_front_page() || is_home() ) {
			return home_url( '/' );
		}

		$scheme = is_ssl() ? 'https://' : 'http://';

		if ( isset( $_SERVER['HTTP_HOST'] ) ) {
			$host = (string) sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) );
		} else {
			$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		}

		if ( isset( $_SERVER['REQUEST_URI'] ) ) {
			$path = (string) wp_unslash( $_SERVER['REQUEST_URI'] );
		} else {
			$path = '/';
		}

		return esc_url_raw( $scheme . $host . $path );
	}

	/**
	 * Best description available for the current context.
	 *
	 * @return string
	 */
	protected static function current_description() {
		if ( is_singular() ) {
			$post = get_queried_object();
			if ( $post ) {
				if ( ! empty( $post->post_excerpt ) ) {
					return wp_strip_all_tags( (string) $post->post_excerpt );
				}
				$excerpt = wp_trim_words( wp_strip_all_tags( (string) $post->post_content ), 28, '…' );
				if ( '' !== $excerpt ) {
					return $excerpt;
				}
			}
		}
		// Sensible brand fallback.
		return 'Clean Nagaland is a civic reporting platform by Nagaland Me. Report illegal liquor and drug activity anonymously, track your report, and see transparent monthly outcomes.';
	}
}
