<?php
/**
 * Front Page Template — helpnagaland.com
 *
 * This template is used only for the site's front page (static home).
 * It sidesteps Astra's default post-list layout and renders a custom
 * landing composition tuned for the civic reporting use case:
 *
 *   1. Hero with the core promise and two primary CTAs.
 *   2. Three feature cards linking to the main actions.
 *   3. Promise strip (what we do, what we do not do, transparency).
 *   4. Secondary CTA band for the status-check flow.
 *
 * If a visitor lands on this page without the core plugin installed,
 * the CTAs still render as links to the (to be created) pages. The
 * plugin's shortcodes render the actual forms there.
 *
 * @package HelpNagalandChild
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-front-page">

	<!-- ============================== HERO ============================== -->
	<section class="hnc-hero" aria-labelledby="hnc-hero-title">
		<div class="hnc-hero-inner">
			<span class="hnc-hero-eyebrow"><?php esc_html_e( 'A Nagaland Me civic platform', 'helpnagaland-child' ); ?></span>

			<h1 id="hnc-hero-title" class="hnc-hero-title">
				<?php
				printf(
					/* translators: %s is the highlighted word in the hero title */
					esc_html__( 'Report illegal liquor and drugs. %s.', 'helpnagaland-child' ),
					'<em>' . esc_html__( 'Safely', 'helpnagaland-child' ) . '</em>'
				);
				?>
			</h1>

			<p class="hnc-hero-subtitle">
				<?php esc_html_e( 'Clean Nagaland is a civic reporting platform run by Nagaland Me. Report anonymously, track your report with a code, and see transparent monthly outcomes. No login. No data collection you did not consent to.', 'helpnagaland-child' ); ?>
			</p>

			<div class="hnc-hero-actions">
				<a class="hnc-btn hnc-btn-primary" href="<?php echo esc_url( home_url( '/report-alcohol/' ) ); ?>">
					<?php esc_html_e( 'Report illegal alcohol', 'helpnagaland-child' ); ?>
				</a>
				<a class="hnc-btn hnc-btn-secondary" href="<?php echo esc_url( home_url( '/report-drugs/' ) ); ?>">
					<?php esc_html_e( 'Report drugs', 'helpnagaland-child' ); ?>
				</a>
			</div>
		</div>
	</section>


	<!-- ============================== FEATURES ============================== -->
	<section class="hnc-features" aria-labelledby="hnc-features-title">
		<h2 id="hnc-features-title" class="hnc-features-title">
			<?php esc_html_e( 'How you can help', 'helpnagaland-child' ); ?>
		</h2>

		<div class="hnc-features-grid">

			<article class="hnc-feature-card">
				<div class="hnc-feature-icon" aria-hidden="true">1</div>
				<h3 class="hnc-feature-heading"><?php esc_html_e( 'Report illegal liquor', 'helpnagaland-child' ); ?></h3>
				<p class="hnc-feature-body">
					<?php esc_html_e( 'Submit a pin with live GPS and a live photo. No gallery uploads. Pin shows on a public map after moderator review. Your phone is never collected.', 'helpnagaland-child' ); ?>
				</p>
				<a class="hnc-feature-link" href="<?php echo esc_url( home_url( '/report-alcohol/' ) ); ?>">
					<?php esc_html_e( 'Submit an alcohol report', 'helpnagaland-child' ); ?>
				</a>
			</article>

			<article class="hnc-feature-card">
				<div class="hnc-feature-icon" aria-hidden="true">2</div>
				<h3 class="hnc-feature-heading"><?php esc_html_e( 'Report drug activity', 'helpnagaland-child' ); ?></h3>
				<p class="hnc-feature-body">
					<?php esc_html_e( 'Describe what you saw in free text. No GPS. Attach a photo if you safely can. Provide a phone only if you agree to be contacted for follow-up.', 'helpnagaland-child' ); ?>
				</p>
				<a class="hnc-feature-link" href="<?php echo esc_url( home_url( '/report-drugs/' ) ); ?>">
					<?php esc_html_e( 'Submit a drug report', 'helpnagaland-child' ); ?>
				</a>
			</article>

			<article class="hnc-feature-card">
				<div class="hnc-feature-icon" aria-hidden="true">3</div>
				<h3 class="hnc-feature-heading"><?php esc_html_e( 'See the public map', 'helpnagaland-child' ); ?></h3>
				<p class="hnc-feature-body">
					<?php esc_html_e( 'Every approved alcohol pin is visible on the public map. Operator-verified pins show a badge. Drug reports are never mapped publicly.', 'helpnagaland-child' ); ?>
				</p>
				<a class="hnc-feature-link" href="<?php echo esc_url( home_url( '/map/' ) ); ?>">
					<?php esc_html_e( 'Open the map', 'helpnagaland-child' ); ?>
				</a>
			</article>

		</div>
	</section>


	<!-- ============================== PROMISE STRIP ============================== -->
	<section class="hnc-promise" aria-labelledby="hnc-promise-title">
		<h2 id="hnc-promise-title" class="screen-reader-text"><?php esc_html_e( 'Our commitments', 'helpnagaland-child' ); ?></h2>

		<div class="hnc-promise-inner">
			<div class="hnc-promise-item">
				<span class="hnc-promise-stat"><?php esc_html_e( 'Anonymous', 'helpnagaland-child' ); ?></span>
				<span class="hnc-promise-label">
					<?php esc_html_e( 'No login. No account. No personal data required.', 'helpnagaland-child' ); ?>
				</span>
			</div>
			<div class="hnc-promise-item">
				<span class="hnc-promise-stat"><?php esc_html_e( 'Monthly', 'helpnagaland-child' ); ?></span>
				<span class="hnc-promise-label">
					<?php esc_html_e( 'Transparent outcomes published every month. Good news or bad.', 'helpnagaland-child' ); ?>
				</span>
			</div>
			<div class="hnc-promise-item">
				<span class="hnc-promise-stat"><?php esc_html_e( 'Encrypted', 'helpnagaland-child' ); ?></span>
				<span class="hnc-promise-label">
					<?php esc_html_e( 'Phone numbers, if provided, are encrypted at rest. No key on disk.', 'helpnagaland-child' ); ?>
				</span>
			</div>
			<div class="hnc-promise-item">
				<span class="hnc-promise-stat"><?php esc_html_e( 'Auto-purge', 'helpnagaland-child' ); ?></span>
				<span class="hnc-promise-label">
					<?php esc_html_e( 'Submitted photos and videos are deleted automatically within 90 days.', 'helpnagaland-child' ); ?>
				</span>
			</div>
		</div>
	</section>


	<!-- ============================== SECONDARY CTA ============================== -->
	<section class="hnc-cta-band" aria-labelledby="hnc-cta-title">
		<h2 id="hnc-cta-title">
			<?php esc_html_e( 'Already submitted a report? Check the status.', 'helpnagaland-child' ); ?>
		</h2>
		<p>
			<?php esc_html_e( 'Every submission gets a tracking code like ABCD-EFGH. Enter yours below to see whether it has been reviewed, approved, or acted on.', 'helpnagaland-child' ); ?>
		</p>
		<div class="hnc-hero-actions">
			<a class="hnc-btn hnc-btn-primary" href="<?php echo esc_url( home_url( '/check-status/' ) ); ?>">
				<?php esc_html_e( 'Check a report status', 'helpnagaland-child' ); ?>
			</a>
			<a class="hnc-btn hnc-btn-secondary" href="<?php echo esc_url( home_url( '/transparency/' ) ); ?>">
				<?php esc_html_e( 'Monthly transparency', 'helpnagaland-child' ); ?>
			</a>
		</div>
	</section>


	<?php
	/**
	 * Fires at the end of the Help Nagaland front page, after all static
	 * sections. Plugins and site owners can hook to inject additional
	 * content such as featured news cards or a partner logos strip.
	 */
	do_action( 'helpnagaland_front_page_after' );
	?>

</main>

<?php
get_footer();
