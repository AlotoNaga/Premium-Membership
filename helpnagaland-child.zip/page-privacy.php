<?php
/**
 * Template — Privacy Policy
 *
 * Thin shell. Admin writes the page body in WordPress. Until content
 * is present, a visible "lawyer must review this before launch" notice
 * reminds the operator that publishing without review would be unsafe
 * under DPDP Act 2023 obligations.
 *
 * @package HelpNagalandChild
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$has_admin_content = false;
if ( have_posts() ) {
	the_post();
	$has_admin_content = ! empty( trim( wp_strip_all_tags( get_the_content() ) ) );
}
?>

<main id="primary" class="site-main hnc-page hnc-page-privacy">

	<header class="hnc-page-header">
		<span class="hnc-page-eyebrow"><?php esc_html_e( 'Legal', 'helpnagaland-child' ); ?></span>
		<h1 class="hnc-page-title"><?php the_title(); ?></h1>
	</header>

	<article class="hnc-prose">
		<?php
		if ( $has_admin_content ) {
			the_content();
		} else {
			?>
			<div class="hnc-notice hnc-notice-warning" role="note">
				<span class="hnc-notice-icon" aria-hidden="true">!</span>
				<div class="hnc-notice-body">
					<p><?php esc_html_e( 'This page is empty. A Privacy Policy must be written, aligned with the DPDP Act 2023, and reviewed by a lawyer licensed in Nagaland or Northeast India before the site goes live.', 'helpnagaland-child' ); ?></p>
				</div>
			</div>
			<?php
		}
		?>
	</article>

</main>

<?php
get_footer();
