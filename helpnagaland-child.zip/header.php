<?php
/**
 * Header Template — helpnagaland.com
 *
 * Custom header for the Clean Nagaland child theme. We override Astra's
 * header.php so we can:
 *
 *   1. Emit a proper skip-link for keyboard/screen-reader users.
 *   2. Render the wordmark (SVG) with a text fallback.
 *   3. Render a minimal, brand-consistent primary nav.
 *   4. Hook `wp_body_open` right after <body> so security plugins and
 *      CSP nonces can inject where they expect.
 *   5. Guarantee the #page wrapper opens here and closes in footer.php
 *      instead of relying on Astra's wrapper being "close enough".
 *   6. Append a brand-styled "Premium Membership" pill button after the primary nav,
 *      whether the nav comes from the WP menu UI or the fallback list.
 *      Lives outside the menu so it never gets accidentally removed
 *      from wp-admin → Appearance → Menus.
 *
 * @package HelpNagalandChild
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
	<meta name="theme-color" content="#0B0F16" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php wp_head(); ?>
	<style>
		/* ----------------------------------------------------------------
		 * Premium Membership CTA (header) — inline because the brand pill looks
		 * the same on every page and we don't want a one-rule CSS file
		 * for it. Forest green / gold matches the Nagaland Me parent
		 * brand. !important guards against Astra's link styling.
		 * ---------------------------------------------------------------- */
		.hnc-header-cta {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			padding: 9px 18px;
			margin-left: 18px;
			background: #0A7558 !important;
			color: #ffffff !important;
			font-weight: 600 !important;
			font-size: 14px;
			letter-spacing: 0.01em;
			border-radius: 999px;
			text-decoration: none !important;
			border: 1.5px solid transparent;
			transition: background 0.15s ease, transform 0.15s ease, box-shadow 0.15s ease;
			box-shadow: 0 2px 8px rgba(10, 117, 88, 0.25);
			line-height: 1.2;
			white-space: nowrap;
		}
		.hnc-header-cta:hover,
		.hnc-header-cta:focus {
			background: #0F2419 !important;
			color: #ffffff !important;
			transform: translateY(-1px);
			box-shadow: 0 4px 14px rgba(10, 117, 88, 0.35);
			border-color: #D4A843;
		}
		.hnc-header-cta:active {
			transform: translateY(0);
		}
		.hnc-header-cta-heart {
			font-size: 14px;
			line-height: 1;
		}
		@media (max-width: 900px) {
			.hnc-header-cta {
				margin-left: 0;
				margin-top: 12px;
				width: auto;
				align-self: flex-start;
			}
		}
	</style>
</head>

<body <?php body_class(); ?>>
<?php
if ( function_exists( 'wp_body_open' ) ) {
	wp_body_open();
}
?>

<a class="hnc-skip-link" href="#primary">
	<?php esc_html_e( 'Skip to main content', 'helpnagaland-child' ); ?>
</a>

<div id="page" class="hfeed site hnc-site">

	<header id="masthead" class="hnc-header" role="banner">
		<div class="hnc-header-inner">

			<div class="hnc-header-brand">
				<?php
				$logo_url  = get_stylesheet_directory_uri() . '/assets/img/logo.svg';
				$home_url  = home_url( '/' );
				$site_name = get_bloginfo( 'name', 'display' );
				?>
				<a href="<?php echo esc_url( $home_url ); ?>" class="hnc-header-logo" rel="home">
					<img
						src="<?php echo esc_url( $logo_url ); ?>"
						alt="<?php echo esc_attr( $site_name ); ?>"
						class="hnc-header-logo-img"
						width="148"
						height="32"
						loading="eager"
						decoding="async"
					/>
					<span class="screen-reader-text"><?php echo esc_html( $site_name ); ?></span>
				</a>
				<?php
				$desc = get_bloginfo( 'description', 'display' );
				if ( ! empty( $desc ) ) :
					?>
					<p class="hnc-header-tag"><?php echo esc_html( $desc ); ?></p>
				<?php endif; ?>
			</div>

			<button
				class="hnc-header-toggle"
				type="button"
				aria-expanded="false"
				aria-controls="hnc-primary-menu"
				aria-label="<?php esc_attr_e( 'Open menu', 'helpnagaland-child' ); ?>"
				data-hnc-nav-toggle
			>
				<span class="hnc-header-toggle-bar" aria-hidden="true"></span>
				<span class="hnc-header-toggle-bar" aria-hidden="true"></span>
				<span class="hnc-header-toggle-bar" aria-hidden="true"></span>
			</button>

			<nav
				id="hnc-primary-menu"
				class="hnc-header-nav"
				role="navigation"
				aria-label="<?php esc_attr_e( 'Primary', 'helpnagaland-child' ); ?>"
			>
				<?php
				if ( has_nav_menu( 'primary' ) ) {
					wp_nav_menu(
						array(
							'theme_location' => 'primary',
							'menu_id'        => 'primary-menu',
							'menu_class'     => 'hnc-header-menu',
							'container'      => false,
							'depth'          => 2,
							'fallback_cb'    => false,
						)
					);
				} else {
					?>
					<ul class="hnc-header-menu">
						<li><a href="<?php echo esc_url( home_url( '/report-alcohol/' ) ); ?>"><?php esc_html_e( 'Report alcohol', 'helpnagaland-child' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/report-drugs/' ) ); ?>"><?php esc_html_e( 'Report drugs', 'helpnagaland-child' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/map/' ) ); ?>"><?php esc_html_e( 'Map', 'helpnagaland-child' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/check-status/' ) ); ?>"><?php esc_html_e( 'Check status', 'helpnagaland-child' ); ?></a></li>
						<li><a href="<?php echo esc_url( home_url( '/transparency/' ) ); ?>"><?php esc_html_e( 'Transparency', 'helpnagaland-child' ); ?></a></li>
					</ul>
					<?php
				}
				?>

				<?php
				/*
				 * Donate CTA — always rendered, regardless of whether the
				 * primary menu is registered. Sits to the right of the nav
				 * (or below it on mobile) as a brand-pill button.
				 *
				 * Resolves the donate page URL by slug so a future rename
				 * of the page body doesn't break the link, with home_url()
				 * fallback if the page hasn't been created yet.
				 */
				$hnc_donate_page = get_page_by_path( 'premium-membership' );
				if ( ! ( $hnc_donate_page instanceof WP_Post ) ) {
					// Backwards-compatible lookup in case the page slug differs.
					$hnc_donate_page = get_page_by_path( 'membership' );
				}
				$hnc_donate_url  = ( $hnc_donate_page instanceof WP_Post )
					? get_permalink( $hnc_donate_page )
					: home_url( '/premium-membership/' );
				?>
				<a
					href="<?php echo esc_url( $hnc_donate_url ); ?>"
					class="hnc-header-cta"
					aria-label="<?php esc_attr_e( 'Become a Premium Member', 'helpnagaland-child' ); ?>"
				>
					<span class="hnc-header-cta-heart" aria-hidden="true">★</span>
					<span><?php esc_html_e( 'Premium Membership', 'helpnagaland-child' ); ?></span>
				</a>
			</nav>

		</div>

		<?php
		/*
		 * Kill-switch banner: surfaced to visitors so they aren't
		 * confused when submission forms return "platform paused"
		 * errors. Prefer the plugin's own HNC_Killswitch::is_active()
		 * when loaded so a site owner who filters the option still
		 * gets the correct result; fall back to a typed option check
		 * otherwise. The fallback uses an integer cast because WP can
		 * return the stored option as either int 1 or string "1"
		 * depending on cache state, and a strict '===' string match
		 * would silently miss the latter.
		 */
		$hnc_ks_active = class_exists( 'HNC_Killswitch' )
			? (bool) HNC_Killswitch::is_active()
			: ( (int) get_option( 'hnc_killswitch_active', 0 ) === 1 );
		if ( $hnc_ks_active ) :
			$hnc_ks_public_message = class_exists( 'HNC_Killswitch' )
				? (string) HNC_Killswitch::public_message()
				: '';
			?>
			<div class="hnc-header-banner" role="status" aria-live="polite">
				<?php
				if ( '' !== $hnc_ks_public_message ) {
					echo esc_html( $hnc_ks_public_message );
				} else {
					esc_html_e( 'Submissions are temporarily paused. The public map and transparency pages remain available.', 'helpnagaland-child' );
				}
				?>
			</div>
			<?php
		endif;
		?>
	</header>