/*!
 * Help Nagaland Child — theme.js
 *
 * Minimal, untracked front-end JS for the theme. Handles:
 *   - Mobile nav toggle with correct aria-expanded state.
 *   - Collapsing the mobile nav when a link is activated, the Escape
 *     key is pressed, or focus leaves the nav.
 *   - Dismiss of the kill-switch banner is intentionally NOT provided —
 *     the banner should stay visible until the operator turns
 *     submissions back on.
 *
 * No analytics. No third-party scripts. No cookies set.
 *
 * (c) Nagaland Me. GPL-2.0-or-later.
 */

( function () {
	'use strict';

	/**
	 * Ready-state handler.
	 *
	 * @param {Function} fn
	 */
	function ready( fn ) {
		if ( document.readyState !== 'loading' ) {
			fn();
		} else {
			document.addEventListener( 'DOMContentLoaded', fn, { once: true } );
		}
	}

	ready( function () {
		var toggle = document.querySelector( '[data-hnc-nav-toggle]' );
		var nav    = document.getElementById( 'hnc-primary-menu' );

		if ( ! toggle || ! nav ) {
			return;
		}

		/**
		 * Set nav open/closed state.
		 *
		 * @param {boolean} open
		 */
		function setOpen( open ) {
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			toggle.setAttribute(
				'aria-label',
				open ? 'Close menu' : 'Open menu'
			);
			nav.classList.toggle( 'is-open', open );
		}

		toggle.addEventListener( 'click', function ( e ) {
			e.preventDefault();
			var isOpen = toggle.getAttribute( 'aria-expanded' ) === 'true';
			setOpen( ! isOpen );
		} );

		// Close on Escape.
		document.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Escape' && toggle.getAttribute( 'aria-expanded' ) === 'true' ) {
				setOpen( false );
				toggle.focus();
			}
		} );

		// Close when a nav link is clicked (useful for same-page anchors).
		nav.addEventListener( 'click', function ( e ) {
			var t = e.target;
			if ( t && t.tagName === 'A' && window.matchMedia( '(max-width: 820px)' ).matches ) {
				setOpen( false );
			}
		} );

		// Close when viewport resizes back up into desktop layout so we
		// don't leave an orphaned "open" state behind.
		var mql = window.matchMedia( '(min-width: 821px)' );
		var mqlListener = function () {
			if ( mql.matches ) {
				setOpen( false );
			}
		};
		if ( typeof mql.addEventListener === 'function' ) {
			mql.addEventListener( 'change', mqlListener );
		} else if ( typeof mql.addListener === 'function' ) {
			// Safari < 14 fallback.
			mql.addListener( mqlListener );
		}
	} );
} )();
