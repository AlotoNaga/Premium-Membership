<?php
/**
 * Template — Monthly Transparency
 *
 * Thin shell. The admin places the [hnc_transparency_page] shortcode
 * (and any surrounding copy) in the WordPress page editor.
 *
 * @package HelpNagalandChild
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-page hnc-page-transparency">

	<div class="hnc-wide">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				the_content();
			}
		}
		?>
	</div>

</main>

<?php
get_footer();
