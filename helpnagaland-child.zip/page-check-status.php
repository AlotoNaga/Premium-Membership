<?php
/**
 * Template — Check Report Status
 *
 * Thin shell. The admin places the [hnc_status_check] shortcode (and
 * any surrounding copy) in the WordPress page editor. Functions.php
 * forces noindex on this slug because the content is per-reporter.
 *
 * @package HelpNagalandChild
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main hnc-page hnc-page-status">

	<div class="hnc-wide">
		<?php
		if ( have_posts() ) {
			while ( have_posts() ) {
				the_post();
				the_content();
			}
		}
		?>
	</div>

</main>

<?php
get_footer();
