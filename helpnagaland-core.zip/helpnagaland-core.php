<?php
/**
 * Plugin Name:       Help Nagaland Core
 * Plugin URI:        https://helpnagaland.com
 * Description:       Core platform for Clean Nagaland, a civic reporting system for alcohol and drug activity in Nagaland. Operated by Nagaland Me.
 * Version:           1.2.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Nagaland Me
 * Author URI:        https://nagaland.me
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       helpnagaland-core
 * Domain Path:       /languages
 *
 * @package HelpNagalandCore
 *
 * ========================================================================
 * CLEAN NAGALAND - CORE PLUGIN
 * ========================================================================
 *
 * This plugin powers two independent reporting pipelines at helpnagaland.com:
 *
 *   1. ALCOHOL pipeline (public)
 *      Citizens pin alcohol sale locations on a public map. Every submission
 *      requires live GPS and a live camera photo. Photos are auto deleted
 *      after 30 days to minimize liability.
 *
 *   2. DRUG pipeline (confidential)
 *      Citizens submit drug activity reports that are never public. Reports
 *      flow to the admin only, and optionally to vetted partner organizations.
 *      Reporter phone numbers are encrypted with AES-256-GCM in a separate
 *      vault table and cannot be revealed without explicit admin action.
 *
 * The two pipelines are intentionally separated at the database, API, class,
 * and directory levels. There is no shared base class for reports. There are
 * no foreign keys crossing between them. This is a deliberate design choice
 * and must be preserved in all future development.
 *
 * Non-negotiable rules are documented in specification section 18.
 *
 * ========================================================================
 * PHASE 1: FOUNDATION
 * ========================================================================
 *
 * This main file loads these Phase 1 classes:
 *   - HNC_Activator    Creates database tables and sets default options
 *   - HNC_Schema       Defines all CREATE TABLE statements
 *   - HNC_Deactivator  Cleans up scheduled events
 *   - HNC_Roles        Registers custom capabilities and roles
 *
 * Submission, moderation, API, and admin UI are wired in later phases.
 * Do not add references here to classes that do not yet exist on disk.
 *
 * ========================================================================
 */

// Block direct access.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/* ============================================================
 * PLUGIN CONSTANTS
 * ============================================================ */

/** Plugin version, also stored in the options table for upgrade detection. */
define( 'HNC_VERSION', '1.2.0' );

/** Database schema version. Increment whenever HNC_Schema changes. */
define( 'HNC_DB_VERSION', '1.3.0' );

/** Absolute path to this file. */
define( 'HNC_FILE', __FILE__ );

/** Absolute path to the plugin directory, with trailing slash. */
define( 'HNC_PATH', plugin_dir_path( __FILE__ ) );

/** URL to the plugin directory, with trailing slash. */
define( 'HNC_URL', plugin_dir_url( __FILE__ ) );

/** Plugin basename, used by action_links and deactivate_plugins(). */
define( 'HNC_BASENAME', plugin_basename( __FILE__ ) );

/** Database table prefix. Combined with $wpdb->prefix at query time. */
define( 'HNC_TABLE_PREFIX', 'hnc_' );

/** REST API namespace. Full path is wp-json/hnc/v1/... */
define( 'HNC_API_NAMESPACE', 'hnc/v1' );

/** Name of the private uploads directory inside wp-content/uploads/. */
define( 'HNC_UPLOADS_DIR', 'hnc-private' );

/** Minimum supported PHP version. */
define( 'HNC_MIN_PHP', '7.4.0' );

/** Minimum supported WordPress version. */
define( 'HNC_MIN_WP', '6.0' );


/* ============================================================
 * REQUIREMENTS CHECK
 * ============================================================ */

/**
 * Verify that the host environment meets the minimum requirements.
 * Returns an array of human readable error strings. Empty array means OK.
 *
 * @return string[]
 */
function hnc_check_requirements() {
	global $wp_version;

	$errors = array();

	if ( version_compare( PHP_VERSION, HNC_MIN_PHP, '<' ) ) {
		$errors[] = sprintf(
			/* translators: 1: required PHP version, 2: current PHP version */
			__( 'Help Nagaland Core requires PHP %1$s or higher. This server is running PHP %2$s.', 'helpnagaland-core' ),
			HNC_MIN_PHP,
			PHP_VERSION
		);
	}

	if ( isset( $wp_version ) && version_compare( $wp_version, HNC_MIN_WP, '<' ) ) {
		$errors[] = sprintf(
			/* translators: 1: required WP version, 2: current WP version */
			__( 'Help Nagaland Core requires WordPress %1$s or higher. This site is running %2$s.', 'helpnagaland-core' ),
			HNC_MIN_WP,
			$wp_version
		);
	}

	// Required PHP extensions for encryption, JSON, image processing, multibyte strings.
	$required_extensions = array( 'openssl', 'json', 'mbstring' );
	foreach ( $required_extensions as $ext ) {
		if ( ! extension_loaded( $ext ) ) {
			$errors[] = sprintf(
				/* translators: %s: PHP extension name */
				__( 'Help Nagaland Core requires the %s PHP extension.', 'helpnagaland-core' ),
				$ext
			);
		}
	}

	// GD or Imagick is needed for EXIF stripping on photo upload.
	if ( ! extension_loaded( 'gd' ) && ! extension_loaded( 'imagick' ) ) {
		$errors[] = __( 'Help Nagaland Core requires either the GD or Imagick PHP extension for image processing.', 'helpnagaland-core' );
	}

	return $errors;
}

/**
 * Display an admin notice listing requirement errors, then deactivate the plugin.
 * Called during activation if requirements fail, and on each admin load if still failing.
 */
function hnc_show_requirements_notice() {
	$errors = hnc_check_requirements();
	if ( empty( $errors ) ) {
		return;
	}

	add_action(
		'admin_notices',
		function () use ( $errors ) {
			echo '<div class="notice notice-error">';
			echo '<p><strong>' . esc_html__( 'Help Nagaland Core cannot run:', 'helpnagaland-core' ) . '</strong></p>';
			echo '<ul style="list-style: disc; padding-left: 20px; margin: 0 0 10px 0;">';
			foreach ( $errors as $error ) {
				echo '<li>' . esc_html( $error ) . '</li>';
			}
			echo '</ul>';
			echo '</div>';
		}
	);
}


/* ============================================================
 * AUTOLOADER
 * ============================================================
 *
 * Maps HNC_ prefixed class names to files using these conventions:
 *
 *   Core classes live in /includes/:
 *     HNC_Activator             -> includes/class-hnc-activator.php
 *     HNC_Schema                -> includes/class-hnc-schema.php
 *     HNC_Roles                 -> includes/class-hnc-roles.php
 *     HNC_Payment               -> includes/class-hnc-payment.php
 *
 *   Submodule classes live in subdirectories:
 *     HNC_Alcohol_Submit        -> includes/alcohol/class-alcohol-submit.php
 *     HNC_Drug_Submit           -> includes/drug/class-drug-submit.php
 *     HNC_Phone_Vault           -> includes/vault/class-phone-vault.php
 *     HNC_Vault_Session         -> includes/vault/class-vault-session.php
 *     HNC_Transparency_Snapshot -> includes/transparency/class-transparency-snapshot.php
 *     HNC_Partner_Registry      -> includes/partners/class-partner-registry.php
 *     HNC_Api_Router            -> includes/api/class-api-router.php
 *     HNC_Admin_Menu            -> admin/class-admin-menu.php
 *     HNC_Public_Enqueue        -> public/class-public-enqueue.php
 *
 * The autoloader is silent when it cannot find a class, so PHP can try other
 * autoloaders (for example the WordPress core one or a theme's).
 */
spl_autoload_register(
	function ( $class_name ) {
		// Ignore non HNC classes.
		if ( strpos( $class_name, 'HNC_' ) !== 0 ) {
			return;
		}

		// Strip the "HNC_" prefix and normalize for filename.
		$suffix = substr( $class_name, 4 );

		// First segment determines subdirectory.
		$first_underscore = strpos( $suffix, '_' );
		$first_segment    = $first_underscore !== false ? substr( $suffix, 0, $first_underscore ) : $suffix;
		$first_segment    = strtolower( $first_segment );

		$dir_map = array(
			'alcohol'      => 'includes/alcohol/',
			'drug'         => 'includes/drug/',
			'phone'        => 'includes/vault/',   // HNC_Phone_Vault lives in vault/
			'vault'        => 'includes/vault/',
			'transparency' => 'includes/transparency/',
			'partner'      => 'includes/partners/',
			'api'          => 'includes/api/',
			'admin'        => 'admin/',
			'public'       => 'public/',
		);

		if ( isset( $dir_map[ $first_segment ] ) ) {
			// Submodule class. Filename is class-<lowercased suffix with dashes>.php.
			$filename = 'class-' . strtolower( str_replace( '_', '-', $suffix ) ) . '.php';
			$path     = HNC_PATH . $dir_map[ $first_segment ] . $filename;
		} else {
			// Core class. Filename is class-hnc-<lowercased suffix with dashes>.php in includes/.
			// HNC_Payment matches this fallback path: includes/class-hnc-payment.php
			$filename = 'class-hnc-' . strtolower( str_replace( '_', '-', $suffix ) ) . '.php';
			$path     = HNC_PATH . 'includes/' . $filename;
		}

		if ( file_exists( $path ) ) {
			require_once $path;
		}
	}
);


/* ============================================================
 * ACTIVATION
 * ============================================================ */

register_activation_hook(
	__FILE__,
	function () {
		// Check requirements first. If they fail, block activation entirely.
		$errors = hnc_check_requirements();
		if ( ! empty( $errors ) ) {
			// WP will catch this and show the message.
			// Using wp_die here prevents the plugin from being marked as active.
			wp_die(
				esc_html__( 'Help Nagaland Core cannot activate:', 'helpnagaland-core' ) . '<br><br>' . esc_html( implode( '  ', $errors ) ),
				esc_html__( 'Plugin Activation Error', 'helpnagaland-core' ),
				array( 'back_link' => true )
			);
		}

		if ( class_exists( 'HNC_Activator' ) ) {
			HNC_Activator::activate();
		}

		// Schedule every cron event defined by HNC_Cron. Idempotent.
		if ( class_exists( 'HNC_Cron' ) ) {
			HNC_Cron::ensure_all_scheduled();
		}

		// Schedule payment-system cron events. Idempotent — the
		// wp_next_scheduled checks prevent duplicate registrations on
		// reactivation.
		if ( class_exists( 'HNC_Payment' ) ) {
			if ( ! wp_next_scheduled( HNC_Payment::HOOK_PAYMENT_RECONCILE ) ) {
				wp_schedule_event( time() + 600, 'hourly', HNC_Payment::HOOK_PAYMENT_RECONCILE );
			}
			if ( ! wp_next_scheduled( HNC_Payment::HOOK_PAYMENT_PURGE_PII ) ) {
				wp_schedule_event( time() + 3600, 'daily', HNC_Payment::HOOK_PAYMENT_PURGE_PII );
			}
		}
	}
);


/* ============================================================
 * DEACTIVATION
 * ============================================================ */

register_deactivation_hook(
	__FILE__,
	function () {
		if ( class_exists( 'HNC_Deactivator' ) ) {
			HNC_Deactivator::deactivate();
		}

		// Clear payment-system scheduled events. Hardcoded literal hook
		// names (not class constants) because HNC_Payment may not be
		// loaded during deactivation in some scenarios.
		wp_clear_scheduled_hook( 'hnc_payment_cron_reconcile' );
		wp_clear_scheduled_hook( 'hnc_payment_cron_purge_pii' );
	}
);


/* ============================================================
 * MAIN BOOTSTRAP
 * ============================================================
 *
 * Runs after all plugins are loaded. This is where we initialize the live
 * plugin. Activation setup (DB creation, option seeding) has already happened
 * by this point.
 */
add_action(
	'plugins_loaded',
	function () {
		// Load textdomain for translations.
		load_plugin_textdomain( 'helpnagaland-core', false, dirname( HNC_BASENAME ) . '/languages' );

		// If requirements are not met at runtime, show notice and abort.
		if ( ! empty( hnc_check_requirements() ) ) {
			hnc_show_requirements_notice();
			return;
		}

		// Check for schema upgrades. The stored db version is compared to the
		// constant above. If they differ, the schema is (re)installed. dbDelta
		// is idempotent, so running it on every upgrade is safe.
		$installed_db_version = get_option( 'hnc_db_version' );
		if ( $installed_db_version !== HNC_DB_VERSION && class_exists( 'HNC_Schema' ) ) {
			HNC_Schema::install();
			update_option( 'hnc_db_version', HNC_DB_VERSION );
		}

		// Ensure custom capabilities are present on the administrator role.
		// This handles the case where WP roles were reset by another plugin.
		if ( class_exists( 'HNC_Roles' ) ) {
			HNC_Roles::init();
		}

		/* ----------------------------------------------------------------
		 * PHASE 2 UTILITIES: cron schedule and default workers.
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Cron' ) ) {
			// Idempotently re-register every schedule in the cron table.
			// Safe to call on every page load.
			HNC_Cron::ensure_all_scheduled();

			// Wire the default system-level workers that do not belong to
			// any one pipeline.
			add_action( HNC_Cron::HOOK_IP_SALT_ROTATE, array( 'HNC_Cron', 'rotate_ip_salt' ) );
			add_action( HNC_Cron::HOOK_DEVICE_CLEANUP, array( 'HNC_Cron', 'run_device_cleanup' ) );
			add_action( HNC_Cron::HOOK_RETENTION_DAILY, array( 'HNC_Cron', 'run_retention_heartbeat' ) );
		}

		/* ----------------------------------------------------------------
		 * PHASE 3: ALCOHOL PIPELINE.
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Alcohol_Submit' ) ) {
			HNC_Alcohol_Submit::init();
		}
		if ( class_exists( 'HNC_Alcohol_Map' ) ) {
			HNC_Alcohol_Map::init();
		}
		if ( class_exists( 'HNC_Alcohol_Retention' ) ) {
			HNC_Alcohol_Retention::init();
		}
		// HNC_Alcohol_Moderation has no cron or REST hooks of its own in
		// Phase 3 (those arrive with the REST API layer in Phase 6 and the
		// admin UI in Phase 7). Its static methods are called directly.

		/* ----------------------------------------------------------------
		 * PHASE 4: DRUG PIPELINE.
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Drug_Submit' ) ) {
			HNC_Drug_Submit::init();
		}
		if ( class_exists( 'HNC_Drug_Retention' ) ) {
			HNC_Drug_Retention::init();
		}
		// HNC_Drug_Moderation and HNC_Drug_Forward expose static methods
		// only in Phase 4. They get wired to REST and admin UI in later
		// phases, but are already safe to call from WP-CLI or internal code.

		/* ----------------------------------------------------------------
		 * PHASE 5: PHONE VAULT + TRANSPARENCY.
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Vault_Session' ) ) {
			HNC_Vault_Session::init();
		}
		if ( class_exists( 'HNC_Vault_Cron' ) ) {
			HNC_Vault_Cron::init();
		}
		if ( class_exists( 'HNC_Transparency_Publish' ) ) {
			HNC_Transparency_Publish::init();
		}
		if ( class_exists( 'HNC_Transparency_Export' ) ) {
			HNC_Transparency_Export::init();
		}
		// HNC_Phone_Vault and HNC_Transparency_Snapshot expose static methods
		// only. They are called from drug submit/moderation (phone storage)
		// and from transparency publish (snapshot build), respectively.

		/* ----------------------------------------------------------------
		 * PHASE 6: REST API LAYER.
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Api_Router' ) ) {
			HNC_Api_Router::init();
		}
		// HNC_Api_Router::init() calls HNC_Api_Public::init() and
		// HNC_Api_Admin::init() internally. HNC_Api_Nonce and
		// HNC_Api_Ratelimit are static helpers with no hooks of their own.

		/* ----------------------------------------------------------------
		 * PHASE 7: ADMIN UI.
		 * ---------------------------------------------------------------- */

		if ( is_admin() ) {
			if ( class_exists( 'HNC_Admin_Menu' ) ) {
				HNC_Admin_Menu::init();
			}
			if ( class_exists( 'HNC_Admin_Settings' ) ) {
				HNC_Admin_Settings::init();
			}
			// HNC_Admin_Dashboard, HNC_Admin_Alcohol, HNC_Admin_Drug,
			// HNC_Admin_Vault, HNC_Admin_Transparency, HNC_Admin_Audit
			// each expose only a static render() method, called by the
			// menu registrar. They have no hooks of their own.
		}

		/* ----------------------------------------------------------------
		 * PHASE 8: PUBLIC FRONTEND (shortcodes + conditional assets).
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Public_Shortcodes' ) ) {
			HNC_Public_Shortcodes::init();
		}
		if ( class_exists( 'HNC_Public_Enqueue' ) ) {
			HNC_Public_Enqueue::init();
		}
		if ( class_exists( 'HNC_Public_Donate' ) ) {
			HNC_Public_Donate::init();
		}
		// Shortcodes register themselves on add_shortcode at this hook.
		// The enqueue class waits until wp_enqueue_scripts to inspect the
		// current post and load only the JS/CSS bundles actually needed.

		/* ----------------------------------------------------------------
		 * PHASE 10: PARTNER DASHBOARD.
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Partner_Forward_Log' ) ) {
			HNC_Partner_Forward_Log::init();
		}
		if ( class_exists( 'HNC_Api_Partner' ) ) {
			HNC_Api_Partner::init();
		}
		if ( is_admin() && class_exists( 'HNC_Admin_Partners' ) ) {
			HNC_Admin_Partners::init();
		}
		// HNC_Partner_Model and HNC_Admin_Partner_Dashboard expose static
		// methods only. Model is called by the forward log (resolving
		// slugs) and by the admin onboarding form. Dashboard renderer is
		// invoked by the menu registrar when a partner visits their page.

		/* ----------------------------------------------------------------
		 * PHASE 11: PAYMENTS / DONATIONS PIPELINE.
		 *
		 * Razorpay-based donation processor. Handles one-time and recurring
		 * (weekly / monthly / twice-yearly / yearly) donations through the
		 * public REST API at /wp-json/hnc/v1/payment/*. Owns three tables:
		 *   wp_hnc_donations
		 *   wp_hnc_payment_events
		 *   wp_hnc_payment_customers
		 *
		 * HNC_Payment::init() is idempotent — it registers REST routes,
		 * the schema migration check, and the action callbacks for the two
		 * cron hooks below. The cron events themselves are scheduled here,
		 * guarded by wp_next_scheduled so we never stack duplicates on
		 * page reload.
		 *
		 * Required wp-config.php constants for live operation:
		 *   HNC_RAZORPAY_TEST_KEY_ID         + ..._KEY_SECRET + ..._WEBHOOK_SECRET
		 *   HNC_RAZORPAY_LIVE_KEY_ID         + ..._KEY_SECRET + ..._WEBHOOK_SECRET
		 *
		 * Mode is the wp_option hnc_payment_live_mode (0 = test, 1 = live).
		 *
		 * Razorpay webhook URL (to be configured in their dashboard):
		 *   https://helpnagaland.com/wp-json/hnc/v1/payment/webhook
		 * ---------------------------------------------------------------- */

		if ( class_exists( 'HNC_Payment' ) ) {
			HNC_Payment::init();

			// Schedule reconciliation + PII purge crons. Both are idempotent.
			if ( ! wp_next_scheduled( HNC_Payment::HOOK_PAYMENT_RECONCILE ) ) {
				wp_schedule_event( time() + 600, 'hourly', HNC_Payment::HOOK_PAYMENT_RECONCILE );
			}
			if ( ! wp_next_scheduled( HNC_Payment::HOOK_PAYMENT_PURGE_PII ) ) {
				wp_schedule_event( time() + 3600, 'daily', HNC_Payment::HOOK_PAYMENT_PURGE_PII );
			}
		}

		// Donations admin UI: top-level Donations menu, plus filter
		// callbacks that override payment-class defaults from saved
		// settings. The class itself decides what runs in admin vs
		// frontend; we just init it on every request.
		if ( class_exists( 'HNC_Admin_Payments' ) ) {
			HNC_Admin_Payments::init();
		}

		/*
		 * Future phases will initialize additional subsystems here.
		 *
		 * These classes do not exist yet and MUST NOT be referenced until their
		 * corresponding class files are present on the server.
		 */
	},
	5 // Priority 5 so we run before most other plugins that default to priority 10.
);


/* ============================================================
 * PLUGIN ACTION LINKS
 * ============================================================ */

/**
 * Add quick links to the plugins list row.
 */
add_filter(
	'plugin_action_links_' . HNC_BASENAME,
	function ( $links ) {
		// In Phase 1 the admin dashboard page does not exist yet, but the link
		// is harmless (will 404 within admin). It becomes live in Phase 7.
		$custom = array(
			'dashboard' => '<a href="' . esc_url( admin_url( 'admin.php?page=hnc-dashboard' ) ) . '">' . esc_html__( 'Dashboard', 'helpnagaland-core' ) . '</a>',
		);
		return array_merge( $custom, $links );
	}
);

/**
 * Add meta links under the plugin description.
 */
add_filter(
	'plugin_row_meta',
	function ( $links, $file ) {
		if ( HNC_BASENAME !== $file ) {
			return $links;
		}
		$extra = array(
			'<a href="https://helpnagaland.com" target="_blank" rel="noopener">' . esc_html__( 'Platform site', 'helpnagaland-core' ) . '</a>',
			'<a href="https://nagaland.me" target="_blank" rel="noopener">' . esc_html__( 'Operator', 'helpnagaland-core' ) . '</a>',
		);
		return array_merge( $links, $extra );
	},
	10,
	2
);