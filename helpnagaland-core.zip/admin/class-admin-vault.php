<?php
/**
 * Admin Vault screen.
 *
 * Provides:
 *   - Passphrase-setup flow (only appears if passphrase has not been set yet).
 *   - Unlock flow.
 *   - Vault status display with countdown to auto-lock.
 *   - Recent reveal events (filtered audit log).
 *
 * Actual reveals of individual phone numbers happen from within the drug
 * queue modal (where context is richer), not from this page. This page
 * is for vault operations and oversight.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Vault
 */
final class HNC_Admin_Vault {


	/**
	 * Render the vault admin page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_manage_vault' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'helpnagaland-core' ) );
		}

		$passphrase_set = class_exists( 'HNC_Encryption' ) && HNC_Encryption::passphrase_is_set();
		$can_reveal     = current_user_can( 'hnc_reveal_phone' );

		// TTL shown in the subtitle — read from the option so a site
		// owner who filters hnc_vault_session_minutes sees the real
		// number, not the hardcoded 15 from v1.0.0.
		$ttl_minutes = (int) get_option( 'hnc_vault_session_minutes', 15 );
		if ( $ttl_minutes < 1 ) {
			$ttl_minutes = 15;
		}

		// Client-side passphrase floor. Mirrors the server filter
		// `hnc_vault_min_passphrase_length` (default 16, hard floor 12)
		// so a site owner tightening this value sees the new number
		// in the UI label too.
		$min_passphrase = (int) apply_filters( 'hnc_vault_min_passphrase_length', 16 );
		if ( $min_passphrase < 12 ) {
			$min_passphrase = 12;
		}

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="vault" data-hnc-can-reveal="<?php echo $can_reveal ? '1' : '0'; ?>" data-hnc-min-passphrase="<?php echo esc_attr( $min_passphrase ); ?>">
			<h1 class="hnc-title">
				<?php esc_html_e( 'Phone Vault', 'helpnagaland-core' ); ?>
				<span class="hnc-pill hnc-pill-gold">ENCRYPTED</span>
			</h1>

			<p class="hnc-subtitle">
				<?php
				printf(
					/* translators: %d is the number of idle minutes before auto-lock. */
					esc_html__( 'AES-256-GCM encrypted phone storage. The vault key is derived at unlock time from the passphrase and held in your PHP session for %d minutes. Forgetting the passphrase is unrecoverable.', 'helpnagaland-core' ),
					(int) $ttl_minutes
				);
				?>
			</p>

			<?php if ( ! $passphrase_set ) : ?>
				<div class="hnc-card hnc-card-warning">
					<h2><?php esc_html_e( 'Set vault passphrase', 'helpnagaland-core' ); ?></h2>
					<p>
						<?php esc_html_e( 'No passphrase is set yet. Until a passphrase exists, phone numbers submitted by reporters cannot be stored. Set one now with a strong, memorable phrase you will not forget. This is a one-time action.', 'helpnagaland-core' ); ?>
					</p>
					<div class="hnc-passphrase-form" data-hnc-passphrase-form>
						<label>
							<span>
								<?php
								printf(
									/* translators: %d is the minimum passphrase length. */
									esc_html__( 'New passphrase (%d+ characters):', 'helpnagaland-core' ),
									(int) $min_passphrase
								);
								?>
							</span>
							<input type="password" data-hnc-passphrase autocomplete="new-password" />
						</label>
						<label>
							<span><?php esc_html_e( 'Confirm:', 'helpnagaland-core' ); ?></span>
							<input type="password" data-hnc-passphrase-confirm autocomplete="new-password" />
						</label>
						<button type="button" class="button button-primary" data-hnc-action="set-passphrase">
							<?php esc_html_e( 'Set passphrase (irreversible)', 'helpnagaland-core' ); ?>
						</button>
					</div>
				</div>
			<?php else : ?>
				<div class="hnc-card" data-hnc-vault-status>
					<div class="hnc-vault-status-row">
						<div class="hnc-vault-indicator" data-hnc-vault-indicator>—</div>
						<div class="hnc-vault-detail">
							<div data-hnc-vault-label>—</div>
							<div class="hnc-vault-countdown" data-hnc-vault-countdown></div>
						</div>
					</div>

					<div class="hnc-vault-actions">
						<div class="hnc-unlock-form" data-hnc-unlock-form>
							<label>
								<span><?php esc_html_e( 'Passphrase', 'helpnagaland-core' ); ?></span>
								<input type="password" data-hnc-unlock-input autocomplete="current-password" />
							</label>
							<button type="button" class="button button-primary" data-hnc-action="unlock">
								<?php esc_html_e( 'Unlock', 'helpnagaland-core' ); ?>
							</button>
						</div>
						<button type="button" class="button" data-hnc-action="lock">
							<?php esc_html_e( 'Lock now', 'helpnagaland-core' ); ?>
						</button>
					</div>
				</div>
			<?php endif; ?>

			<div class="hnc-card">
				<div class="hnc-card-header">
					<h2><?php esc_html_e( 'Vault counts', 'helpnagaland-core' ); ?></h2>
					<button type="button" class="button button-small" data-hnc-action="refresh-counts">
						<?php esc_html_e( 'Refresh', 'helpnagaland-core' ); ?>
					</button>
				</div>
				<div class="hnc-grid hnc-grid-3" data-hnc-vault-counts>
					<div class="hnc-card hnc-card-stat">
						<div class="hnc-stat-label"><?php esc_html_e( 'Active entries', 'helpnagaland-core' ); ?></div>
						<div class="hnc-stat-value" data-hnc-counts-total>—</div>
					</div>
					<div class="hnc-card hnc-card-stat">
						<div class="hnc-stat-label"><?php esc_html_e( 'Alcohol', 'helpnagaland-core' ); ?></div>
						<div class="hnc-stat-value" data-hnc-counts-alcohol>—</div>
					</div>
					<div class="hnc-card hnc-card-stat">
						<div class="hnc-stat-label"><?php esc_html_e( 'Drug', 'helpnagaland-core' ); ?></div>
						<div class="hnc-stat-value" data-hnc-counts-drug>—</div>
					</div>
				</div>
			</div>

			<?php if ( current_user_can( 'hnc_view_audit' ) ) : ?>
			<div class="hnc-card">
				<div class="hnc-card-header">
					<h2><?php esc_html_e( 'Recent vault events', 'helpnagaland-core' ); ?></h2>
					<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=' . HNC_Admin_Menu::MENU_SLUG_AUDIT . '&event_type=vault' ) ); ?>">
						<?php esc_html_e( 'Full audit', 'helpnagaland-core' ); ?>
					</a>
				</div>
				<div class="hnc-audit-recent" data-hnc-audit-recent>
					<div class="hnc-empty"><?php esc_html_e( 'Loading...', 'helpnagaland-core' ); ?></div>
				</div>
			</div>
			<?php endif; ?>
		</div>
		<?php
	}
}
