<?php
/**
 * Admin Partners screen: onboard and manage partner organizations.
 *
 * Accessed under Clean Nagaland → Partners by users with the
 * hnc_manage_partners capability. Renders a simple form-based UI for
 * creating partners and a table of existing ones with toggle buttons.
 *
 * Form submissions POST back to the admin-post.php endpoint so we get
 * standard WordPress nonce + capability enforcement for free.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Partners
 */
final class HNC_Admin_Partners {


	const NONCE_ACTION = 'hnc_admin_partners';


	/**
	 * Register admin-post handlers.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_post_hnc_partner_create', array( __CLASS__, 'handle_create' ) );
		add_action( 'admin_post_hnc_partner_toggle_active', array( __CLASS__, 'handle_toggle_active' ) );
	}


	/**
	 * Render the Partners management page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_manage_partners' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage partners.', 'helpnagaland-core' ), '', array( 'response' => 403 ) );
		}

		$partners = HNC_Partner_Model::list_all( false );
		$message  = isset( $_GET['hnc_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['hnc_msg'] ) ) : '';
		$error    = isset( $_GET['hnc_err'] ) ? sanitize_text_field( wp_unslash( $_GET['hnc_err'] ) ) : '';

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="partners">
			<h1 class="hnc-title"><?php esc_html_e( 'Partners', 'helpnagaland-core' ); ?></h1>

			<?php if ( '' !== $message ) : ?>
				<div class="hnc-card hnc-card-info"><?php echo esc_html( $message ); ?></div>
			<?php endif; ?>
			<?php if ( '' !== $error ) : ?>
				<div class="hnc-card hnc-card-warning"><?php echo esc_html( $error ); ?></div>
			<?php endif; ?>

			<div class="hnc-card" style="margin-bottom:2rem;">
				<h2><?php esc_html_e( 'Onboard a new partner', 'helpnagaland-core' ); ?></h2>
				<p class="description">
					<?php esc_html_e( 'The partner must already have a WordPress user account. Create the user first under Users → Add New, set their role to "HNC Partner", then fill in the form below.', 'helpnagaland-core' ); ?>
				</p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="hnc-form">
					<input type="hidden" name="action" value="hnc_partner_create" />
					<?php wp_nonce_field( self::NONCE_ACTION ); ?>

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="hnc_partner_slug"><?php esc_html_e( 'Slug', 'helpnagaland-core' ); ?></label></th>
							<td>
								<input type="text" id="hnc_partner_slug" name="slug" required maxlength="60" pattern="[a-z0-9_\-]+" placeholder="e.g. nsacs_kohima" class="regular-text" />
								<p class="description"><?php esc_html_e( 'Lowercase identifier used in forward actions. a-z, 0-9, dash, underscore. Immutable once set.', 'helpnagaland-core' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="hnc_partner_name"><?php esc_html_e( 'Display name', 'helpnagaland-core' ); ?></label></th>
							<td>
								<input type="text" id="hnc_partner_name" name="name" required maxlength="120" class="regular-text" />
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="hnc_partner_user"><?php esc_html_e( 'WordPress user', 'helpnagaland-core' ); ?></label></th>
							<td>
								<?php
								$users = function_exists( 'get_users' ) ? get_users( array( 'role__in' => array( 'hnc_partner', 'administrator' ), 'number' => 500 ) ) : array();
								?>
								<select id="hnc_partner_user" name="wp_user_id" required class="regular-text">
									<option value=""><?php esc_html_e( '— Select user —', 'helpnagaland-core' ); ?></option>
									<?php foreach ( $users as $u ) : ?>
										<option value="<?php echo (int) $u->ID; ?>">
											<?php echo esc_html( $u->display_name . ' (' . $u->user_login . ')' ); ?>
										</option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php esc_html_e( 'Only users with the HNC Partner role (or administrators) are shown.', 'helpnagaland-core' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="hnc_partner_email"><?php esc_html_e( 'Contact email', 'helpnagaland-core' ); ?></label></th>
							<td>
								<input type="email" id="hnc_partner_email" name="contact_email" maxlength="190" class="regular-text" />
								<p class="description"><?php esc_html_e( 'Optional. Used for out-of-band contact only. Not for forwarding secrets.', 'helpnagaland-core' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="hnc_partner_gpg"><?php esc_html_e( 'GPG fingerprint', 'helpnagaland-core' ); ?></label></th>
							<td>
								<input type="text" id="hnc_partner_gpg" name="gpg_fingerprint" maxlength="60" pattern="[0-9A-Fa-f\s]{40,60}" class="regular-text" placeholder="e.g. AAAA BBBB CCCC DDDD EEEE FFFF 1111 2222 3333 4444" />
								<p class="description"><?php esc_html_e( 'Optional, for future encrypted email. 40 hex characters, spaces allowed.', 'helpnagaland-core' ); ?></p>
							</td>
						</tr>
					</table>

					<?php submit_button( __( 'Onboard partner', 'helpnagaland-core' ), 'primary', 'submit', false ); ?>
				</form>
			</div>

			<h2><?php esc_html_e( 'Existing partners', 'helpnagaland-core' ); ?></h2>

			<?php if ( empty( $partners ) ) : ?>
				<p><?php esc_html_e( 'No partners onboarded yet.', 'helpnagaland-core' ); ?></p>
			<?php else : ?>
				<table class="widefat striped">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Name', 'helpnagaland-core' ); ?></th>
							<th><?php esc_html_e( 'Slug', 'helpnagaland-core' ); ?></th>
							<th><?php esc_html_e( 'WP User', 'helpnagaland-core' ); ?></th>
							<th><?php esc_html_e( 'Onboarded', 'helpnagaland-core' ); ?></th>
							<th><?php esc_html_e( 'Last login', 'helpnagaland-core' ); ?></th>
							<th><?php esc_html_e( 'Active', 'helpnagaland-core' ); ?></th>
							<th><?php esc_html_e( 'Actions', 'helpnagaland-core' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $partners as $p ) :
							$user = function_exists( 'get_userdata' ) ? get_userdata( (int) $p->wp_user_id ) : null;
							?>
							<tr>
								<td><?php echo esc_html( $p->name ); ?></td>
								<td><code><?php echo esc_html( $p->slug ); ?></code></td>
								<td><?php echo $user ? esc_html( $user->user_login ) : esc_html__( '(missing)', 'helpnagaland-core' ); ?></td>
								<td><?php echo esc_html( $p->onboarded_at ); ?></td>
								<td><?php echo $p->last_login ? esc_html( $p->last_login ) : '&mdash;'; ?></td>
								<td>
									<?php if ( (int) $p->active === 1 ) : ?>
										<span class="hnc-pill hnc-pill-green"><?php esc_html_e( 'Active', 'helpnagaland-core' ); ?></span>
									<?php else : ?>
										<span class="hnc-pill hnc-pill-gray"><?php esc_html_e( 'Inactive', 'helpnagaland-core' ); ?></span>
									<?php endif; ?>
								</td>
								<td>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
										<input type="hidden" name="action" value="hnc_partner_toggle_active" />
										<input type="hidden" name="partner_id" value="<?php echo (int) $p->id; ?>" />
										<input type="hidden" name="target" value="<?php echo (int) $p->active === 1 ? '0' : '1'; ?>" />
										<?php wp_nonce_field( self::NONCE_ACTION ); ?>
										<button type="submit" class="button">
											<?php echo (int) $p->active === 1
												? esc_html__( 'Deactivate', 'helpnagaland-core' )
												: esc_html__( 'Reactivate', 'helpnagaland-core' ); ?>
										</button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>

		</div>
		<?php
	}


	/**
	 * Handle the create form POST.
	 *
	 * @return void
	 */
	public static function handle_create() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'hnc_manage_partners' ) ) {
			wp_die( esc_html__( 'Forbidden.', 'helpnagaland-core' ), '', array( 'response' => 403 ) );
		}

		$input = array(
			'slug'            => isset( $_POST['slug'] ) ? sanitize_text_field( wp_unslash( $_POST['slug'] ) ) : '',
			'name'            => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
			'wp_user_id'      => isset( $_POST['wp_user_id'] ) ? (int) $_POST['wp_user_id'] : 0,
			'contact_email'   => isset( $_POST['contact_email'] ) ? sanitize_email( wp_unslash( $_POST['contact_email'] ) ) : '',
			'gpg_fingerprint' => isset( $_POST['gpg_fingerprint'] ) ? sanitize_text_field( wp_unslash( $_POST['gpg_fingerprint'] ) ) : '',
		);

		$result = HNC_Partner_Model::create( $input );
		$redir  = admin_url( 'admin.php?page=helpnagaland-partners' );

		if ( is_wp_error( $result ) ) {
			$redir = add_query_arg( 'hnc_err', rawurlencode( $result->get_error_message() ), $redir );
		} else {
			$redir = add_query_arg( 'hnc_msg', rawurlencode( __( 'Partner onboarded.', 'helpnagaland-core' ) ), $redir );
		}

		wp_safe_redirect( $redir );
		exit;
	}


	/**
	 * Handle the activate/deactivate toggle.
	 *
	 * @return void
	 */
	public static function handle_toggle_active() {
		check_admin_referer( self::NONCE_ACTION );
		if ( ! current_user_can( 'hnc_manage_partners' ) ) {
			wp_die( esc_html__( 'Forbidden.', 'helpnagaland-core' ), '', array( 'response' => 403 ) );
		}

		$partner_id = isset( $_POST['partner_id'] ) ? (int) $_POST['partner_id'] : 0;
		$target     = isset( $_POST['target'] ) ? (int) $_POST['target'] : 0;
		$result     = HNC_Partner_Model::set_active( $partner_id, (bool) $target );

		$redir = admin_url( 'admin.php?page=helpnagaland-partners' );
		if ( is_wp_error( $result ) ) {
			$redir = add_query_arg( 'hnc_err', rawurlencode( $result->get_error_message() ), $redir );
		} else {
			$redir = add_query_arg( 'hnc_msg', rawurlencode( __( 'Partner status updated.', 'helpnagaland-core' ) ), $redir );
		}

		wp_safe_redirect( $redir );
		exit;
	}
}
