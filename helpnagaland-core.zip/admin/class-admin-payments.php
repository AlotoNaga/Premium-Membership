<?php
/**
 * Admin: Donations / Payments settings page.
 *
 * Provides a top-level "Donations" menu in wp-admin with a Settings
 * subpage for configuring Razorpay credentials, mode (test / live),
 * and viewing the webhook URL + configuration health.
 *
 * The credentials are stored in wp_options. HNC_Payment reads from
 * wp-config.php constants FIRST, then falls back to these options.
 * If a constant is defined for a given field, the matching form field
 * is locked and a notice is shown.
 *
 * Capability required: manage_options (administrators only).
 *
 * @package HelpNagalandCore
 * @since   1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Payments
 */
final class HNC_Admin_Payments {

	const MENU_SLUG    = 'hnc-donations';
	const CAPABILITY   = 'manage_options';
	const NONCE_ACTION = 'hnc_donations_save_settings';
	const NONCE_NAME   = 'hnc_donations_settings_nonce';

	/**
	 * Sentinel string used as the placeholder shown in masked secret
	 * inputs. If the form is submitted with this exact value, we treat
	 * it as "no change" and keep the existing stored value.
	 */
	const SECRET_KEEP_SENTINEL = '__HNC_KEEP_EXISTING__';

	/**
	 * Initialise hooks.
	 *
	 * Registered filter callbacks fire on EVERY request (frontend REST API
	 * and admin), because they let the operator's saved settings override
	 * the payment class's hard-coded defaults for things like minimum
	 * amount, allowed frequencies, and PII retention.
	 *
	 * The menu and save handler register only inside wp-admin.
	 *
	 * @return void
	 */
	public static function init() {
		// Always-on filter callbacks. These let the wp_options stored by
		// this settings page override the payment class's defaults.
		add_filter( 'hnc_payment_min_amount_paise', array( __CLASS__, 'filter_min_amount_paise' ) );
		add_filter( 'hnc_payment_max_amount_paise', array( __CLASS__, 'filter_max_amount_paise' ) );
		add_filter( 'hnc_payment_allowed_frequencies', array( __CLASS__, 'filter_allowed_frequencies' ) );
		add_filter( 'hnc_payment_pii_retention_days', array( __CLASS__, 'filter_pii_retention_days' ) );

		// Admin-only: menu registration and form save handler.
		if ( is_admin() ) {
			add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
			add_action( 'admin_init', array( __CLASS__, 'maybe_save_settings' ) );
		}
	}

	/* --------------------------------------------------------------
	 * FILTER CALLBACKS
	 * --------------------------------------------------------------
	 *
	 * Read operator-saved options and override the payment class's
	 * hard-coded defaults. Each callback validates the stored value;
	 * invalid or empty values fall through to the default.
	 */

	/**
	 * Override min donation amount. Stored as INR, converted to paise.
	 *
	 * @param int $default Default in paise.
	 * @return int
	 */
	public static function filter_min_amount_paise( $default ) {
		$inr = (int) get_option( 'hnc_payment_min_amount_inr', 0 );
		return ( $inr > 0 ) ? ( $inr * 100 ) : (int) $default;
	}

	/**
	 * Override max donation amount. Stored as INR, converted to paise.
	 *
	 * @param int $default Default in paise.
	 * @return int
	 */
	public static function filter_max_amount_paise( $default ) {
		$inr = (int) get_option( 'hnc_payment_max_amount_inr', 0 );
		return ( $inr > 0 ) ? ( $inr * 100 ) : (int) $default;
	}

	/**
	 * Override allowed frequencies. Stored as array of frequency strings.
	 *
	 * @param array $default Default supported frequencies.
	 * @return array
	 */
	public static function filter_allowed_frequencies( $default ) {
		$option = get_option( 'hnc_payment_allowed_frequencies_v1', null );
		if ( ! is_array( $option ) || empty( $option ) ) {
			return $default;
		}
		// Filter to known values to avoid garbage propagating.
		$known = array( 'once', 'weekly', 'monthly', 'halfyearly', 'yearly' );
		$clean = array_values( array_intersect( $known, $option ) );
		return ! empty( $clean ) ? $clean : $default;
	}

	/**
	 * Override PII retention period. Stored as integer days.
	 *
	 * @param int $default Default days.
	 * @return int
	 */
	public static function filter_pii_retention_days( $default ) {
		$option = get_option( 'hnc_payment_pii_retention_days', null );
		if ( null === $option || '' === $option ) {
			return (int) $default;
		}
		$value = (int) $option;
		return $value < 0 ? 0 : $value;
	}

	/**
	 * Register the top-level Donations menu and its Settings subpage.
	 *
	 * @return void
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'Membership Settings', 'helpnagaland-core' ),
			__( 'Membership', 'helpnagaland-core' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( __CLASS__, 'render_settings_page' ),
			'dashicons-awards',
			56
		);

		// Rename the auto-created first submenu item to "Settings".
		add_submenu_page(
			self::MENU_SLUG,
			__( 'Settings', 'helpnagaland-core' ),
			__( 'Settings', 'helpnagaland-core' ),
			self::CAPABILITY,
			self::MENU_SLUG,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Field map: form_field_name => array( option_key, label, secret, placeholder ).
	 *
	 * @return array
	 */
	private static function fields() {
		return array(
			'test_key_id' => array(
				'option'      => 'hnc_payment_razorpay_test_key_id',
				'const'       => 'HNC_RAZORPAY_TEST_KEY_ID',
				'label'       => __( 'Test Key ID', 'helpnagaland-core' ),
				'secret'      => false,
				'placeholder' => 'rzp_test_xxxxxxxxxxxx',
			),
			'test_key_secret' => array(
				'option'      => 'hnc_payment_razorpay_test_key_secret',
				'const'       => 'HNC_RAZORPAY_TEST_KEY_SECRET',
				'label'       => __( 'Test Key Secret', 'helpnagaland-core' ),
				'secret'      => true,
				'placeholder' => '',
			),
			'test_webhook_secret' => array(
				'option'      => 'hnc_payment_razorpay_test_webhook_secret',
				'const'       => 'HNC_RAZORPAY_TEST_WEBHOOK_SECRET',
				'label'       => __( 'Test Webhook Secret', 'helpnagaland-core' ),
				'secret'      => true,
				'placeholder' => '',
			),
			'live_key_id' => array(
				'option'      => 'hnc_payment_razorpay_live_key_id',
				'const'       => 'HNC_RAZORPAY_LIVE_KEY_ID',
				'label'       => __( 'Live Key ID', 'helpnagaland-core' ),
				'secret'      => false,
				'placeholder' => 'rzp_live_xxxxxxxxxxxx',
			),
			'live_key_secret' => array(
				'option'      => 'hnc_payment_razorpay_live_key_secret',
				'const'       => 'HNC_RAZORPAY_LIVE_KEY_SECRET',
				'label'       => __( 'Live Key Secret', 'helpnagaland-core' ),
				'secret'      => true,
				'placeholder' => '',
			),
			'live_webhook_secret' => array(
				'option'      => 'hnc_payment_razorpay_live_webhook_secret',
				'const'       => 'HNC_RAZORPAY_LIVE_WEBHOOK_SECRET',
				'label'       => __( 'Live Webhook Secret', 'helpnagaland-core' ),
				'secret'      => true,
				'placeholder' => '',
			),
		);
	}

	/**
	 * Handle the form POST. Runs early (admin_init) so we can redirect
	 * after save and clear the POST data.
	 *
	 * @return void
	 */
	public static function maybe_save_settings() {
		if ( ! isset( $_POST[ self::NONCE_NAME ] ) ) {
			return;
		}
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		if ( ! wp_verify_nonce( wp_unslash( $_POST[ self::NONCE_NAME ] ), self::NONCE_ACTION ) ) {
			return;
		}

		// Mode: 0 (test) or 1 (live).
		$mode = isset( $_POST['hnc_payment_mode'] ) ? (int) $_POST['hnc_payment_mode'] : 0;
		$mode = ( 1 === $mode ) ? 1 : 0;
		update_option( 'hnc_payment_live_mode', $mode );

		foreach ( self::fields() as $field_key => $info ) {
			$form_name = 'hnc_payment_' . $field_key;
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
			$submitted = isset( $_POST[ $form_name ] ) ? trim( wp_unslash( $_POST[ $form_name ] ) ) : '';
			$submitted = sanitize_text_field( $submitted );

			// Skip if a wp-config constant is already overriding this field.
			// We do not allow the form to overwrite stored option in this
			// case to avoid confusion (the constant always wins anyway).
			if ( defined( $info['const'] ) && '' !== (string) constant( $info['const'] ) ) {
				continue;
			}

			if ( $info['secret'] ) {
				// For secret fields, an empty submission OR the keep-sentinel
				// means "do not change". User must type a new value to overwrite.
				if ( '' === $submitted || self::SECRET_KEEP_SENTINEL === $submitted ) {
					continue;
				}
				update_option( $info['option'], $submitted );
			} else {
				// Visible (Key ID) fields are always overwritten.
				update_option( $info['option'], $submitted );
			}
		}

		/* ------------------------------------------------------------
		 * DONATION FORM CONFIGURATION
		 * ------------------------------------------------------------ */

		// Min amount (INR). Hard floor at ₹1.
		if ( isset( $_POST['hnc_payment_min_amount_inr'] ) ) {
			$min_inr = (int) $_POST['hnc_payment_min_amount_inr'];
			if ( $min_inr < 1 ) {
				$min_inr = 1;
			}
			update_option( 'hnc_payment_min_amount_inr', $min_inr );
		}

		// Max amount (INR). Hard ceiling at ₹10,00,000 (10 lakh) so a
		// rogue admin can't set MAX = MIN = 0 and break everything.
		if ( isset( $_POST['hnc_payment_max_amount_inr'] ) ) {
			$max_inr = (int) $_POST['hnc_payment_max_amount_inr'];
			if ( $max_inr < 1 ) {
				$max_inr = 1;
			}
			if ( $max_inr > 1000000 ) {
				$max_inr = 1000000;
			}
			update_option( 'hnc_payment_max_amount_inr', $max_inr );
		}

		// Monthly plan price (INR). Fixed-price plan — no custom amount on
		// the form, by design (Razorpay flags free-amount flows as donations).
		if ( isset( $_POST['hnc_payment_monthly_amount_inr'] ) ) {
			$monthly_inr = (int) $_POST['hnc_payment_monthly_amount_inr'];
			if ( $monthly_inr < 1 ) {
				$monthly_inr = 1;
			}
			update_option( 'hnc_payment_monthly_amount_inr', $monthly_inr );
		}

		// Yearly plan price (INR).
		if ( isset( $_POST['hnc_payment_yearly_amount_inr'] ) ) {
			$yearly_inr = (int) $_POST['hnc_payment_yearly_amount_inr'];
			if ( $yearly_inr < 1 ) {
				$yearly_inr = 1;
			}
			update_option( 'hnc_payment_yearly_amount_inr', $yearly_inr );
		}

		// Allowed plan periods (multi-checkbox). Falls back to 'monthly' if
		// nothing else is checked, so the form has at least one plan tile.
		$known_freqs = array( 'monthly', 'yearly' );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$submitted_freqs = isset( $_POST['hnc_payment_allowed_frequencies'] ) && is_array( $_POST['hnc_payment_allowed_frequencies'] )
			? array_map( 'sanitize_text_field', wp_unslash( $_POST['hnc_payment_allowed_frequencies'] ) )
			: array();
		$clean_freqs = array_values( array_intersect( $known_freqs, $submitted_freqs ) );
		if ( empty( $clean_freqs ) ) {
			$clean_freqs = array( 'monthly' );
		}
		update_option( 'hnc_payment_allowed_frequencies_v1', $clean_freqs );

		// Default frequency. Must be one of the allowed frequencies.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$default_freq = isset( $_POST['hnc_payment_default_frequency'] ) ? sanitize_text_field( wp_unslash( $_POST['hnc_payment_default_frequency'] ) ) : '';
		if ( ! in_array( $default_freq, $clean_freqs, true ) ) {
			$default_freq = $clean_freqs[0];
		}
		update_option( 'hnc_payment_default_frequency', $default_freq );

		// PII retention days (integer, 0 to disable).
		if ( isset( $_POST['hnc_payment_pii_retention_days'] ) ) {
			$days = (int) $_POST['hnc_payment_pii_retention_days'];
			if ( $days < 0 ) {
				$days = 0;
			}
			if ( $days > 3650 ) { // 10 years cap.
				$days = 3650;
			}
			update_option( 'hnc_payment_pii_retention_days', $days );
		}

		// Redirect to clear the POST and show the saved-banner. Use
		// admin_url directly because menu_page_url() requires admin_menu
		// to have fired already, but this handler runs at admin_init.
		wp_safe_redirect( admin_url( 'admin.php?page=' . self::MENU_SLUG . '&saved=1' ) );
		exit;
	}

	/**
	 * Render the settings page.
	 *
	 * @return void
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'helpnagaland-core' ) );
		}

		$fields    = self::fields();
		$live_mode = (int) get_option( 'hnc_payment_live_mode', 0 ) === 1;
		$saved     = isset( $_GET['saved'] ) && '1' === $_GET['saved']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// Resolve current values + constant-overrides per field.
		$values = array();
		foreach ( $fields as $key => $info ) {
			$const_set     = defined( $info['const'] ) && '' !== (string) constant( $info['const'] );
			$option_value  = (string) get_option( $info['option'], '' );
			$values[ $key ] = array(
				'option_value'  => $option_value,
				'const_set'     => $const_set,
				'has_value'     => $const_set || '' !== $option_value,
			);
		}

		$webhook_url = esc_url_raw( rest_url( HNC_API_NAMESPACE . '/payment/webhook' ) );

		// Optional health snapshot (cheap; safe to call on render).
		$health = null;
		if ( class_exists( 'HNC_Payment' ) && method_exists( 'HNC_Payment', 'health_check' ) ) {
			$health = HNC_Payment::health_check();
		}

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Membership Settings', 'helpnagaland-core' ); ?></h1>

			<?php if ( $saved ) : ?>
				<div class="notice notice-success is-dismissible">
					<p><strong><?php esc_html_e( 'Settings saved.', 'helpnagaland-core' ); ?></strong></p>
				</div>
			<?php endif; ?>

			<?php self::render_status_banner( $health, $live_mode ); ?>

			<form method="post" action="">
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

				<h2 style="color:#0A7558; margin-top:24px;">
					<?php esc_html_e( 'Mode', 'helpnagaland-core' ); ?>
				</h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row">
							<label for="hnc_payment_mode"><?php esc_html_e( 'Active Mode', 'helpnagaland-core' ); ?></label>
						</th>
						<td>
							<select id="hnc_payment_mode" name="hnc_payment_mode" class="regular-text">
								<option value="0" <?php selected( ! $live_mode ); ?>>
									<?php esc_html_e( 'Test Mode (Sandbox)', 'helpnagaland-core' ); ?>
								</option>
								<option value="1" <?php selected( $live_mode ); ?>>
									<?php esc_html_e( 'Live Mode (Production)', 'helpnagaland-core' ); ?>
								</option>
							</select>
							<p class="description">
								<?php esc_html_e( 'Test mode uses test keys and never charges real money. Switch to Live only after end-to-end testing succeeds.', 'helpnagaland-core' ); ?>
							</p>
						</td>
					</tr>
				</table>

				<h2 style="color:#0A7558; margin-top:24px;">
					<?php esc_html_e( 'Test Mode Credentials', 'helpnagaland-core' ); ?>
				</h2>
				<table class="form-table" role="presentation">
					<?php
					self::render_field_row( 'test_key_id', $fields['test_key_id'], $values['test_key_id'] );
					self::render_field_row( 'test_key_secret', $fields['test_key_secret'], $values['test_key_secret'] );
					self::render_field_row( 'test_webhook_secret', $fields['test_webhook_secret'], $values['test_webhook_secret'] );
					?>
				</table>

				<h2 style="color:#0A7558; margin-top:24px;">
					<?php esc_html_e( 'Live Mode Credentials', 'helpnagaland-core' ); ?>
				</h2>
				<p style="color:#b32d2e;">
					<strong><?php esc_html_e( '⚠️ Only fill these after Razorpay activates your account for live payments (KYC required).', 'helpnagaland-core' ); ?></strong>
				</p>
				<table class="form-table" role="presentation">
					<?php
					self::render_field_row( 'live_key_id', $fields['live_key_id'], $values['live_key_id'] );
					self::render_field_row( 'live_key_secret', $fields['live_key_secret'], $values['live_key_secret'] );
					self::render_field_row( 'live_webhook_secret', $fields['live_webhook_secret'], $values['live_webhook_secret'] );
					?>
				</table>

				<h2 style="color:#0A7558; margin-top:32px;">
				<?php esc_html_e( 'Webhook URL', 'helpnagaland-core' ); ?>
			</h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">
						<label for="hnc_webhook_url"><?php esc_html_e( 'Configure in Razorpay Dashboard', 'helpnagaland-core' ); ?></label>
					</th>
					<td>
						<input
							type="text"
							id="hnc_webhook_url"
							class="large-text"
							readonly
							value="<?php echo esc_attr( $webhook_url ); ?>"
							onclick="this.select();"
						>
						<p class="description">
							<?php esc_html_e( 'Copy this URL into Razorpay Dashboard → Settings → Webhooks → Add New Webhook. Subscribe to all 17 events listed in the deployment guide.', 'helpnagaland-core' ); ?>
						</p>
					</td>
				</tr>
			</table>

			<?php self::render_donation_config_section(); ?>

			<?php submit_button( __( 'Save Settings', 'helpnagaland-core' ) ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Render a single form-table row for a credential field.
	 *
	 * @param string $field_key Field key (e.g. 'test_key_id').
	 * @param array  $info      Field metadata from self::fields().
	 * @param array  $value     Resolved values: option_value, const_set, has_value.
	 * @return void
	 */
	private static function render_field_row( $field_key, $info, $value ) {
		$form_name  = 'hnc_payment_' . $field_key;
		$is_secret  = (bool) $info['secret'];
		$const_set  = (bool) $value['const_set'];
		$has_stored = '' !== $value['option_value'];

		// Determine input value to render.
		$render_value = '';
		if ( $is_secret ) {
			// Never render secret values into HTML. If a value exists, show
			// the keep-sentinel so submitting with it unchanged keeps it.
			if ( $value['has_value'] ) {
				$render_value = self::SECRET_KEEP_SENTINEL;
			}
		} else {
			$render_value = $value['option_value'];
		}

		// Locked if a wp-config constant defines it.
		$locked = $const_set;

		?>
		<tr>
			<th scope="row">
				<label for="<?php echo esc_attr( $form_name ); ?>">
					<?php echo esc_html( $info['label'] ); ?>
				</label>
			</th>
			<td>
				<?php if ( $locked ) : ?>
					<input
						type="text"
						id="<?php echo esc_attr( $form_name ); ?>"
						class="regular-text"
						value="<?php echo esc_attr( $is_secret ? '••••••••••••••••' : '(set in wp-config.php)' ); ?>"
						disabled
					>
					<p class="description" style="color:#7a4f00;">
						<?php
						printf(
							/* translators: %s: PHP constant name */
							esc_html__( 'Locked: defined as %s in wp-config.php. Remove the constant to use this field.', 'helpnagaland-core' ),
							'<code>' . esc_html( $info['const'] ) . '</code>'
						);
						?>
					</p>
				<?php else : ?>
					<input
						type="<?php echo $is_secret ? 'password' : 'text'; ?>"
						id="<?php echo esc_attr( $form_name ); ?>"
						name="<?php echo esc_attr( $form_name ); ?>"
						class="regular-text"
						value="<?php echo esc_attr( $render_value ); ?>"
						<?php if ( ! empty( $info['placeholder'] ) ) : ?>
							placeholder="<?php echo esc_attr( $info['placeholder'] ); ?>"
						<?php endif; ?>
						autocomplete="off"
					>
					<?php if ( $is_secret && $has_stored ) : ?>
						<p class="description">
							<?php esc_html_e( 'A value is saved. Leave the dots as-is to keep it, or type a new value to replace.', 'helpnagaland-core' ); ?>
						</p>
					<?php elseif ( $is_secret ) : ?>
						<p class="description">
							<?php esc_html_e( 'No value saved yet. This secret is stored encrypted in the database and never returned to the frontend.', 'helpnagaland-core' ); ?>
						</p>
					<?php endif; ?>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * Render the "Donation Form Configuration" section. Operator-controlled
	 * settings for what donors see on the donation form (suggested amounts,
	 * frequencies, bounds, etc.).
	 *
	 * @return void
	 */
	private static function render_donation_config_section() {
		// Read current values with sensible defaults.
		$min_inr           = (int) get_option( 'hnc_payment_min_amount_inr', 99 );
		$max_inr           = (int) get_option( 'hnc_payment_max_amount_inr', 100000 );
		$monthly_inr       = (int) get_option( 'hnc_payment_monthly_amount_inr', 399 );
		$yearly_inr        = (int) get_option( 'hnc_payment_yearly_amount_inr', 1999 );
		$allowed_freqs     = get_option( 'hnc_payment_allowed_frequencies_v1', array( 'monthly', 'yearly' ) );
		if ( ! is_array( $allowed_freqs ) ) {
			$allowed_freqs = array( 'monthly', 'yearly' );
		}
		$default_freq      = (string) get_option( 'hnc_payment_default_frequency', 'monthly' );
		$pii_days          = (int) get_option( 'hnc_payment_pii_retention_days', 365 );

		// Friendly labels for frequencies.
		$freq_labels = array(
			'monthly' => __( 'Monthly', 'helpnagaland-core' ),
			'yearly'  => __( 'Yearly', 'helpnagaland-core' ),
		);
		?>

		<h2 style="color:#0A7558; margin-top:32px;">
			<?php esc_html_e( 'Membership Form Configuration', 'helpnagaland-core' ); ?>
		</h2>
		<p class="description" style="margin-bottom:16px;">
			<?php esc_html_e( 'Two fixed-price plans are shown on the membership form. There is no free-amount input, by design — Razorpay flags free-amount flows as donations. Set the price per plan below.', 'helpnagaland-core' ); ?>
		</p>
		<table class="form-table" role="presentation">

			<tr>
				<th scope="row">
					<label for="hnc_payment_monthly_amount_inr"><?php esc_html_e( 'Monthly plan price (₹)', 'helpnagaland-core' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						id="hnc_payment_monthly_amount_inr"
						name="hnc_payment_monthly_amount_inr"
						class="small-text"
						min="1"
						value="<?php echo esc_attr( (string) $monthly_inr ); ?>"
					> ₹
					<p class="description">
						<?php esc_html_e( 'Fixed price billed every month for the monthly Premium Membership plan.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="hnc_payment_yearly_amount_inr"><?php esc_html_e( 'Yearly plan price (₹)', 'helpnagaland-core' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						id="hnc_payment_yearly_amount_inr"
						name="hnc_payment_yearly_amount_inr"
						class="small-text"
						min="1"
						value="<?php echo esc_attr( (string) $yearly_inr ); ?>"
					> ₹
					<p class="description">
						<?php esc_html_e( 'Fixed price billed once a year for the yearly Premium Membership plan.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="hnc_payment_min_amount_inr"><?php esc_html_e( 'Minimum amount (₹)', 'helpnagaland-core' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						id="hnc_payment_min_amount_inr"
						name="hnc_payment_min_amount_inr"
						class="small-text"
						min="1"
						value="<?php echo esc_attr( (string) $min_inr ); ?>"
					> ₹
					<p class="description">
						<?php esc_html_e( 'Server-side floor. Should be ≤ the cheapest plan above. Used to reject API requests with bogus low amounts.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="hnc_payment_max_amount_inr"><?php esc_html_e( 'Maximum amount (₹)', 'helpnagaland-core' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						id="hnc_payment_max_amount_inr"
						name="hnc_payment_max_amount_inr"
						class="small-text"
						min="1"
						max="1000000"
						value="<?php echo esc_attr( (string) $max_inr ); ?>"
					> ₹
					<p class="description">
						<?php esc_html_e( 'Server-side ceiling. Should be ≥ the most expensive plan above. Hard cap is ₹10,00,000.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<?php esc_html_e( 'Allowed plans', 'helpnagaland-core' ); ?>
				</th>
				<td>
					<fieldset>
						<?php foreach ( $freq_labels as $freq_key => $freq_label ) :
							$checked = in_array( $freq_key, $allowed_freqs, true );
							?>
							<label style="display:block; margin-bottom:6px;">
								<input
									type="checkbox"
									name="hnc_payment_allowed_frequencies[]"
									value="<?php echo esc_attr( $freq_key ); ?>"
									<?php checked( $checked ); ?>
								>
								<?php echo esc_html( $freq_label ); ?>
							</label>
						<?php endforeach; ?>
					</fieldset>
					<p class="description">
						<?php esc_html_e( 'Tick the membership billing periods you want to offer. Unticked options will not appear on the form, and any direct API request for them will be rejected. At least one must be ticked.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="hnc_payment_default_frequency"><?php esc_html_e( 'Default plan', 'helpnagaland-core' ); ?></label>
				</th>
				<td>
					<select id="hnc_payment_default_frequency" name="hnc_payment_default_frequency" class="regular-text">
						<?php foreach ( $freq_labels as $freq_key => $freq_label ) : ?>
							<option value="<?php echo esc_attr( $freq_key ); ?>" <?php selected( $default_freq, $freq_key ); ?>>
								<?php echo esc_html( $freq_label ); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description">
						<?php esc_html_e( 'Pre-selected on the membership form. Should be one of the allowed billing periods above. If you select a period that you also disabled, the system will fall back to the first allowed one.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row">
					<label for="hnc_payment_pii_retention_days"><?php esc_html_e( 'PII retention (days)', 'helpnagaland-core' ); ?></label>
				</th>
				<td>
					<input
						type="number"
						id="hnc_payment_pii_retention_days"
						name="hnc_payment_pii_retention_days"
						class="small-text"
						min="0"
						max="3650"
						value="<?php echo esc_attr( (string) $pii_days ); ?>"
					>
					<?php esc_html_e( 'days', 'helpnagaland-core' ); ?>
					<p class="description">
						<?php esc_html_e( 'How long member name, email, phone, and IP are kept on completed membership payments before being automatically nulled. The payment record itself, the amount, and the receipt number are kept forever for accounting. Set to 0 to disable purging entirely. India\'s DPDP Act 2023 generally favours shorter retention; 365 days is a reasonable default.', 'helpnagaland-core' ); ?>
					</p>
				</td>
			</tr>

		</table>
		<?php
	}


	/**
	 * Render the configuration health banner at the top of the page.
	 *
	 * @param array|null $health   Result of HNC_Payment::health_check().
	 * @param bool       $live_mode Whether live mode is active.
	 * @return void
	 */
	private static function render_status_banner( $health, $live_mode ) {
		if ( ! is_array( $health ) ) {
			return;
		}

		$configured = ! empty( $health['configured'] );
		$mode_label = $live_mode ? __( 'LIVE', 'helpnagaland-core' ) : __( 'TEST', 'helpnagaland-core' );

		if ( $configured ) {
			$bg     = '#d4edda';
			$border = '#0A7558';
			$text   = '#155724';
			$status = sprintf(
				/* translators: %s: mode label */
				__( '✅ Premium Membership is configured and active in %s mode.', 'helpnagaland-core' ),
				$mode_label
			);
		} else {
			$bg     = '#f8d7da';
			$border = '#b32d2e';
			$text   = '#721c24';
			$missing = array();
			if ( isset( $health['config_detail'] ) && is_array( $health['config_detail'] ) ) {
				$d = $health['config_detail'];
				if ( empty( $d['key_id_set'] ) ) {
					$missing[] = __( 'Key ID', 'helpnagaland-core' );
				}
				if ( empty( $d['key_secret_set'] ) ) {
					$missing[] = __( 'Key Secret', 'helpnagaland-core' );
				}
				if ( empty( $d['webhook_secret_set'] ) ) {
					$missing[] = __( 'Webhook Secret', 'helpnagaland-core' );
				}
			}
			$status = sprintf(
				/* translators: 1: mode label, 2: comma-separated list of missing fields */
				__( '⚠️ %1$s mode is missing: %2$s. Membership payments will fail until configured.', 'helpnagaland-core' ),
				$mode_label,
				$missing ? implode( ', ', $missing ) : __( 'credentials', 'helpnagaland-core' )
			);
		}

		echo '<div style="margin:12px 0;padding:12px 16px;border-left:4px solid ' . esc_attr( $border ) . ';background:' . esc_attr( $bg ) . ';color:' . esc_attr( $text ) . ';">';
		echo '<strong>' . esc_html( $status ) . '</strong>';

		// Extra stats line (24h webhook activity).
		if ( isset( $health['webhook_24h'], $health['signature_failures_24h'] ) ) {
			echo '<br><small>';
			printf(
				/* translators: 1: signed webhooks count, 2: signature failure count */
				esc_html__( 'Last 24h: %1$d signed webhooks, %2$d signature failures.', 'helpnagaland-core' ),
				(int) $health['webhook_24h'],
				(int) $health['signature_failures_24h']
			);
			echo '</small>';
		}

		echo '</div>';
	}
}