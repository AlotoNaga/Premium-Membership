<?php
/**
 * Admin Transparency screen.
 *
 * Manages monthly transparency snapshots. Lists draft and published
 * periods, lets the moderator build/rebuild a snapshot, publish one,
 * unpublish one, or edit the accompanying note.
 *
 * The monthly cron auto-publishes the previous month on the 1st at
 * 09:00 IST, so under normal operation this screen is mostly used for
 * post-hoc note edits or emergency corrections.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Admin_Transparency
 */
final class HNC_Admin_Transparency {


	/**
	 * Render the transparency admin page.
	 *
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'hnc_publish_transparency' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'helpnagaland-core' ) );
		}

		$now_year  = (int) current_time( 'Y' );
		$now_month = (int) current_time( 'n' );

		// Default to previous month (the most common build target).
		$default_year  = $now_year;
		$default_month = $now_month - 1;
		if ( $default_month < 1 ) {
			$default_month = 12;
			$default_year  = $now_year - 1;
		}

		?>
		<div class="wrap hnc-wrap" data-hnc-screen="transparency">
			<h1 class="hnc-title">
				<?php esc_html_e( 'Transparency', 'helpnagaland-core' ); ?>
				<span class="hnc-pill hnc-pill-blue">MONTHLY</span>
			</h1>

			<p class="hnc-subtitle">
				<?php esc_html_e( 'Monthly snapshots of alcohol and drug report counts. The cron auto-publishes the previous month on the 1st at 09:00 IST. You can also build and publish on demand.', 'helpnagaland-core' ); ?>
			</p>

			<div class="hnc-card">
				<h2><?php esc_html_e( 'Build or rebuild a snapshot', 'helpnagaland-core' ); ?></h2>
				<div class="hnc-build-form">
					<label>
						<span><?php esc_html_e( 'Year', 'helpnagaland-core' ); ?></span>
						<input type="number" data-hnc-year value="<?php echo esc_attr( (string) $default_year ); ?>" min="2024" max="<?php echo esc_attr( (string) ( $now_year + 1 ) ); ?>" />
					</label>
					<label>
						<span><?php esc_html_e( 'Month', 'helpnagaland-core' ); ?></span>
						<select data-hnc-month>
							<?php
							$month_names = array( '', 'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December' );
							for ( $m = 1; $m <= 12; $m++ ) :
								?>
								<option value="<?php echo (int) $m; ?>" <?php selected( $m, $default_month ); ?>><?php echo esc_html( $month_names[ $m ] ); ?></option>
							<?php endfor; ?>
						</select>
					</label>
					<button type="button" class="button button-primary" data-hnc-action="build">
						<?php esc_html_e( 'Build snapshot', 'helpnagaland-core' ); ?>
					</button>
				</div>
				<p class="hnc-help-text">
					<?php esc_html_e( 'Building does not make the snapshot public. Review the counts, then publish when ready. Building again overwrites the counts but preserves any existing publish state and admin note.', 'helpnagaland-core' ); ?>
				</p>
			</div>

			<div class="hnc-card">
				<div class="hnc-card-header">
					<h2><?php esc_html_e( 'Published snapshots', 'helpnagaland-core' ); ?></h2>
					<button type="button" class="button button-small" data-hnc-action="refresh-list">
						<?php esc_html_e( 'Refresh', 'helpnagaland-core' ); ?>
					</button>
				</div>
				<div class="hnc-snapshot-list" data-hnc-snapshot-list>
					<div class="hnc-empty"><?php esc_html_e( 'Loading...', 'helpnagaland-core' ); ?></div>
				</div>
			</div>

			<div class="hnc-card">
				<h2><?php esc_html_e( 'Export', 'helpnagaland-core' ); ?></h2>
				<p>
					<?php esc_html_e( 'Public exports of all published snapshots:', 'helpnagaland-core' ); ?>
				</p>
				<p>
					<a class="button" href="<?php echo esc_url( rest_url( HNC_API_NAMESPACE . '/transparency/export/csv' ) ); ?>">
						<?php esc_html_e( 'Download CSV', 'helpnagaland-core' ); ?>
					</a>
					<a class="button" href="<?php echo esc_url( rest_url( HNC_API_NAMESPACE . '/transparency/export/json' ) ); ?>" target="_blank">
						<?php esc_html_e( 'View JSON', 'helpnagaland-core' ); ?>
					</a>
				</p>
			</div>
		</div>
		<?php
	}
}
