<?php
/**
 * Cron scheduling.
 *
 * Centralized registration for all scheduled tasks used by the plugin.
 * The HOOKS are registered here in Phase 2. The WORK for each hook is
 * implemented by pipeline-specific retention classes in Phases 3 to 5.
 *
 * Registering hooks without implementations is intentional. When a
 * pipeline retention class lands on disk, it will `add_action` against
 * the hook and the scheduled event will start doing useful work. Until
 * then, the scheduled event fires and does nothing, which is harmless.
 *
 * Default schedule (IST, the timezone Aloto operates in):
 *
 *   hnc_retention_sweep_daily              Every day 02:00 IST
 *   hnc_alcohol_photo_cleanup              Every day 02:15 IST
 *   hnc_alcohol_archive_old_pins           Every day 02:30 IST
 *   hnc_alcohol_purge_rejected             Every day 02:45 IST
 *   hnc_drug_media_cleanup                 Every day 03:00 IST
 *   hnc_drug_archive_old                   Every day 03:15 IST
 *   hnc_drug_purge_rejected                Every day 03:30 IST
 *   hnc_phone_vault_cleanup                Every day 03:45 IST
 *   hnc_device_fingerprint_cleanup         Every day 04:00 IST
 *   hnc_ip_salt_rotate_daily               Every day 00:05 IST
 *   hnc_transparency_auto_publish_monthly  On configured day of month 09:00 IST
 *   hnc_audit_log_archive_yearly           Every January 02:00 IST
 *
 * All times are stored as UTC timestamps to survive DST transitions (not
 * relevant in India, but this keeps the code portable). Conversion from
 * IST to UTC is a flat minus 5 hours 30 minutes.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Cron
 */
final class HNC_Cron {


	/* ------------------------------------------------------------------
	 * HOOK CONSTANTS
	 * ------------------------------------------------------------------ */

	const HOOK_RETENTION_DAILY      = 'hnc_retention_sweep_daily';
	const HOOK_ALCOHOL_PHOTO        = 'hnc_alcohol_photo_cleanup';
	const HOOK_ALCOHOL_ARCHIVE      = 'hnc_alcohol_archive_old_pins';
	const HOOK_ALCOHOL_PURGE        = 'hnc_alcohol_purge_rejected';
	const HOOK_DRUG_MEDIA           = 'hnc_drug_media_cleanup';
	const HOOK_DRUG_ARCHIVE         = 'hnc_drug_archive_old';
	const HOOK_DRUG_PURGE           = 'hnc_drug_purge_rejected';
	const HOOK_PHONE_CLEANUP        = 'hnc_phone_vault_cleanup';
	const HOOK_DEVICE_CLEANUP       = 'hnc_device_fingerprint_cleanup';
	const HOOK_IP_SALT_ROTATE       = 'hnc_ip_salt_rotate_daily';
	const HOOK_TRANSPARENCY_PUBLISH = 'hnc_transparency_auto_publish_monthly';
	const HOOK_AUDIT_ARCHIVE        = 'hnc_audit_log_archive_yearly';


	/**
	 * List of every cron hook used by the plugin, with the recurrence and
	 * the IST hour and minute at which it should run. Hours are 0-23 IST.
	 *
	 * @return array<int,array{hook:string,recurrence:string,hour:int,minute:int}>
	 */
	public static function schedule_table() {
		return array(
			array(
				'hook'       => self::HOOK_IP_SALT_ROTATE,
				'recurrence' => 'daily',
				'hour'       => 0,
				'minute'     => 5,
			),
			array(
				'hook'       => self::HOOK_RETENTION_DAILY,
				'recurrence' => 'daily',
				'hour'       => 2,
				'minute'     => 0,
			),
			array(
				'hook'       => self::HOOK_ALCOHOL_PHOTO,
				'recurrence' => 'daily',
				'hour'       => 2,
				'minute'     => 15,
			),
			array(
				'hook'       => self::HOOK_ALCOHOL_ARCHIVE,
				'recurrence' => 'daily',
				'hour'       => 2,
				'minute'     => 30,
			),
			array(
				'hook'       => self::HOOK_ALCOHOL_PURGE,
				'recurrence' => 'daily',
				'hour'       => 2,
				'minute'     => 45,
			),
			array(
				'hook'       => self::HOOK_DRUG_MEDIA,
				'recurrence' => 'daily',
				'hour'       => 3,
				'minute'     => 0,
			),
			array(
				'hook'       => self::HOOK_DRUG_ARCHIVE,
				'recurrence' => 'daily',
				'hour'       => 3,
				'minute'     => 15,
			),
			array(
				'hook'       => self::HOOK_DRUG_PURGE,
				'recurrence' => 'daily',
				'hour'       => 3,
				'minute'     => 30,
			),
			array(
				'hook'       => self::HOOK_PHONE_CLEANUP,
				'recurrence' => 'daily',
				'hour'       => 3,
				'minute'     => 45,
			),
			array(
				'hook'       => self::HOOK_DEVICE_CLEANUP,
				'recurrence' => 'daily',
				'hour'       => 4,
				'minute'     => 0,
			),
			array(
				'hook'       => self::HOOK_TRANSPARENCY_PUBLISH,
				'recurrence' => 'hnc_monthly',
				'hour'       => 9,
				'minute'     => 0,
			),
			array(
				'hook'       => self::HOOK_AUDIT_ARCHIVE,
				'recurrence' => 'hnc_yearly',
				'hour'       => 2,
				'minute'     => 0,
			),
		);
	}


	/* ------------------------------------------------------------------
	 * INITIALIZATION
	 * ------------------------------------------------------------------ */

	/**
	 * Wire up custom schedules and hook the built-in default actions.
	 * Called from the main plugin bootstrap on plugins_loaded.
	 *
	 * @return void
	 */
	public static function init() {
		// Register custom cron intervals not provided by core.
		add_filter( 'cron_schedules', array( __CLASS__, 'register_custom_schedules' ) );

		// Ensure every hook is scheduled.
		add_action( 'init', array( __CLASS__, 'ensure_all_scheduled' ), 20 );

		// Hook the default internal workers. Pipeline-specific actions are
		// registered by each pipeline's own class in later phases.
		add_action( self::HOOK_IP_SALT_ROTATE, array( __CLASS__, 'rotate_ip_salt' ) );
		add_action( self::HOOK_DEVICE_CLEANUP, array( __CLASS__, 'run_device_cleanup' ) );
		add_action( self::HOOK_RETENTION_DAILY, array( __CLASS__, 'run_retention_heartbeat' ) );
	}

	/**
	 * Add our custom cron intervals: monthly and yearly.
	 *
	 * @param array $schedules WP default schedules.
	 * @return array
	 */
	public static function register_custom_schedules( $schedules ) {
		if ( ! isset( $schedules['hnc_monthly'] ) ) {
			$schedules['hnc_monthly'] = array(
				'interval' => 30 * DAY_IN_SECONDS,
				'display'  => __( 'Once every 30 days', 'helpnagaland-core' ),
			);
		}
		if ( ! isset( $schedules['hnc_yearly'] ) ) {
			$schedules['hnc_yearly'] = array(
				'interval' => 365 * DAY_IN_SECONDS,
				'display'  => __( 'Once every 365 days', 'helpnagaland-core' ),
			);
		}
		return $schedules;
	}

	/**
	 * Ensure every hook in the schedule table is registered with WP cron.
	 *
	 * This is idempotent: wp_schedule_event returns false when an identical
	 * event is already registered. We also repair drift: if a hook went missing
	 * (because WP options were wiped or migrated), this re-schedules it.
	 *
	 * @return void
	 */
	public static function ensure_all_scheduled() {
		foreach ( self::schedule_table() as $row ) {
			if ( ! wp_next_scheduled( $row['hook'] ) ) {
				$first_run = self::next_ist_run( $row['hour'], $row['minute'] );
				wp_schedule_event( $first_run, $row['recurrence'], $row['hook'] );
			}
		}
	}

	/**
	 * Compute the next UTC timestamp at which to run a daily event whose
	 * target time is a given hour and minute IN IST. If today's IST slot
	 * has not yet passed, use today. Otherwise use tomorrow.
	 *
	 * India is UTC+5:30. There are no DST transitions in India.
	 *
	 * @param int $ist_hour   0 to 23.
	 * @param int $ist_minute 0 to 59.
	 * @return int UNIX timestamp in UTC.
	 */
	public static function next_ist_run( $ist_hour, $ist_minute ) {
		/*
		 * We use a "pseudo-timestamp in the IST frame" trick throughout:
		 *   $now_ist = $now_utc + 19800 is NOT a real UTC timestamp — it
		 *   is a shifted value that, when passed to gmdate(), prints the
		 *   calendar date and time currently on a clock in Kolkata. We
		 *   do all arithmetic in this frame and convert back at the end.
		 *
		 * This is safe because:
		 *   - strtotime( $day . ' HH:MM:00 UTC' ) returns a pseudo in the
		 *     same frame as $now_ist, so the <= comparison is apples to
		 *     apples.
		 *   - The final subtraction undoes the offset exactly.
		 *
		 * India has no DST, so the +5:30 offset is constant.
		 */
		$now_utc    = time();
		$ist_offset = 5 * HOUR_IN_SECONDS + 30 * MINUTE_IN_SECONDS;
		$now_ist    = $now_utc + $ist_offset;

		$today_ist_day = gmdate( 'Y-m-d', $now_ist );
		$target_ist    = strtotime( $today_ist_day . ' ' . sprintf( '%02d:%02d:00', $ist_hour, $ist_minute ) . ' UTC' );
		if ( false === $target_ist ) {
			// strtotime() parsing failure is unexpected. Fall back to
			// one hour from now so the schedule doesn't get dropped.
			return $now_utc + HOUR_IN_SECONDS;
		}
		// Equal is treated as past — we want the NEXT slot, not the
		// current one.
		if ( $target_ist <= $now_ist ) {
			$target_ist += DAY_IN_SECONDS;
		}
		return $target_ist - $ist_offset;
	}


	/* ------------------------------------------------------------------
	 * DEFAULT WORKERS
	 * ------------------------------------------------------------------ */

	/**
	 * Rotate the daily IP hashing salt. Runs once a day. A fresh salt means
	 * previously-hashed IPs become unlinkable to new hashes.
	 *
	 * @return void
	 */
	public static function rotate_ip_salt() {
		$old_salt_preview = substr( (string) get_option( 'hnc_ip_daily_salt', '' ), 0, 6 );
		$new_salt         = wp_generate_password( 32, true, true );
		update_option( 'hnc_ip_daily_salt', $new_salt );
		update_option( 'hnc_ip_salt_rotated_at', current_time( 'mysql' ) );
		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system(
				'ip_salt_rotate',
				array( 'old_prefix' => $old_salt_preview )
			);
		}
	}

	/**
	 * Run the device fingerprint cleanup sweep.
	 *
	 * @return void
	 */
	public static function run_device_cleanup() {
		if ( class_exists( 'HNC_Device' ) ) {
			$deleted = HNC_Device::purge_stale();
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_system(
					'device_cleanup',
					array( 'deleted_rows' => $deleted )
				);
			}
		}
	}

	/**
	 * Heartbeat for the daily retention umbrella hook. Fires pipeline-specific
	 * hooks internally via do_action. This lets pipeline classes listen to a
	 * single hook instead of individual schedules if they prefer.
	 *
	 * @return void
	 */
	public static function run_retention_heartbeat() {
		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_system( HNC_Logger::ACTION_RETENTION_RUN );
		}
		do_action( 'hnc_retention_heartbeat' );
	}


	/* ------------------------------------------------------------------
	 * CLEAR ALL (used by deactivation)
	 * ------------------------------------------------------------------ */

	/**
	 * Unschedule every HNC cron hook. Used by the deactivator.
	 *
	 * @return void
	 */
	public static function clear_all() {
		foreach ( self::schedule_table() as $row ) {
			$ts = wp_next_scheduled( $row['hook'] );
			while ( false !== $ts ) {
				wp_unschedule_event( $ts, $row['hook'] );
				$ts = wp_next_scheduled( $row['hook'] );
			}
			wp_clear_scheduled_hook( $row['hook'] );
		}
	}
}
