<?php
/**
 * Drug pipeline: moderator actions.
 *
 * Drug reports never appear on a public map, so the moderation surface is
 * slightly different from alcohol:
 *
 *   - status values include 'resolved' in addition to pending/approved/
 *     rejected/hold/archived.
 *   - There is no verify_by_operator action (no public pin to verify).
 *   - There is no merge (reports are too sensitive and too different from
 *     each other to meaningfully auto-merge).
 *   - There is a set_severity action that tags a report 1-5 to help the
 *     moderator triage caseload.
 *
 * All methods are capability gated on hnc_moderate_drug. Every mutation
 * writes to the audit log. No mutation method accepts input that would
 * write back to the public tracking code surface.
 *
 * REST endpoints for these actions are NOT registered here. The admin UI
 * in Phase 7 and the REST layer in Phase 6 will wrap the static methods.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Drug_Moderation
 */
final class HNC_Drug_Moderation {


	/* ------------------------------------------------------------------
	 * ERROR CODES
	 * ------------------------------------------------------------------ */

	const ERR_UNAUTHORIZED  = 'hnc_unauthorized';
	const ERR_NOT_FOUND     = 'hnc_report_not_found';
	const ERR_BAD_STATUS    = 'hnc_bad_status_transition';
	const ERR_UPDATE_FAILED = 'hnc_update_failed';
	const ERR_BAD_REASON    = 'hnc_bad_rejection_reason';
	const ERR_BAD_SEVERITY  = 'hnc_bad_severity';


	/* ------------------------------------------------------------------
	 * APPROVE
	 * ------------------------------------------------------------------ */

	/**
	 * Approve a pending or held drug report. This does not make the report
	 * public (nothing about drug reports is ever public). It simply signals
	 * that a moderator has read the report and accepted it as a real case.
	 *
	 * @param int    $id   Report ID.
	 * @param string $note Optional admin note (audit log only).
	 * @return true|WP_Error
	 */
	public static function approve( $id, $note = '' ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$allowed_from = array( HNC_Drug_Submit::STATUS_PENDING, HNC_Drug_Submit::STATUS_HOLD );
		if ( ! in_array( $row->status, $allowed_from, true ) ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot approve a drug report currently in status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$ok = self::write_status( (int) $id, HNC_Drug_Submit::STATUS_APPROVED );
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_APPROVE,
			(int) $id,
			array(
				'previous_status' => $row->status,
				'note'            => class_exists( 'HNC_Sanitizer' ) ? HNC_Sanitizer::admin_note( $note ) : (string) $note,
			)
		);
		return true;
	}


	/* ------------------------------------------------------------------
	 * REJECT
	 * ------------------------------------------------------------------ */

	/**
	 * Reject a drug report. Deletes the media (if any) immediately. The row
	 * is kept for a short window (default 24 hours) then purged by cron.
	 *
	 * If the report carried an encrypted phone in the vault, the vault
	 * entry is marked for deletion via HNC_Phone_Vault (Phase 5). Until
	 * that class exists we leave the phone_vault_id alone; the Phase 5
	 * retention sweep will catch orphaned vault entries.
	 *
	 * @param int    $id     Report ID.
	 * @param string $reason Short rejection reason (required, max 120 chars).
	 * @return true|WP_Error
	 */
	public static function reject( $id, $reason ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$allowed_from = array(
			HNC_Drug_Submit::STATUS_PENDING,
			HNC_Drug_Submit::STATUS_HOLD,
			HNC_Drug_Submit::STATUS_APPROVED,
		);
		if ( ! in_array( $row->status, $allowed_from, true ) ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot reject a drug report currently in status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$clean_reason = class_exists( 'HNC_Sanitizer' )
			? HNC_Sanitizer::rejection_reason( $reason )
			: substr( trim( (string) $reason ), 0, 120 );
		if ( '' === $clean_reason ) {
			return new WP_Error( self::ERR_BAD_REASON, __( 'A short rejection reason is required.', 'helpnagaland-core' ) );
		}

		// Delete the media file first, same pattern as alcohol reject.
		if ( ! empty( $row->media_uuid ) && class_exists( 'HNC_Media' ) ) {
			HNC_Media::delete_by_uuid( 'drug', (string) $row->media_uuid );
		}

		// Delete the phone vault entry if present. Only if the vault class
		// is deployed. Otherwise a nightly sweep will collect orphans.
		if ( ! empty( $row->phone_vault_id )
			&& class_exists( 'HNC_Phone_Vault' )
			&& is_callable( array( 'HNC_Phone_Vault', 'delete' ) ) ) {
			HNC_Phone_Vault::delete( (int) $row->phone_vault_id );
		}

		$ok = self::write_status(
			(int) $id,
			HNC_Drug_Submit::STATUS_REJECTED,
			array(
				'media_uuid' => null,
				'media_type' => null,
				'media_hash' => null,
			)
		);
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_REJECT,
			(int) $id,
			array(
				'previous_status' => $row->status,
				'reason'          => $clean_reason,
				'media_deleted'   => ! empty( $row->media_uuid ),
				'phone_purged'    => ! empty( $row->phone_vault_id ),
			)
		);
		return true;
	}


	/* ------------------------------------------------------------------
	 * HOLD / UNHOLD
	 * ------------------------------------------------------------------ */

	/**
	 * Put a report on hold for further review.
	 *
	 * @param int    $id   Report ID.
	 * @param string $note Optional note.
	 * @return true|WP_Error
	 */
	public static function hold( $id, $note = '' ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Drug_Submit::STATUS_PENDING !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only pending drug reports can be put on hold. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$ok = self::write_status( (int) $id, HNC_Drug_Submit::STATUS_HOLD );
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_HOLD,
			(int) $id,
			array( 'note' => class_exists( 'HNC_Sanitizer' ) ? HNC_Sanitizer::admin_note( $note ) : (string) $note )
		);
		return true;
	}

	/**
	 * Release a held drug report back to pending.
	 *
	 * @param int $id Report ID.
	 * @return true|WP_Error
	 */
	public static function unhold( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Drug_Submit::STATUS_HOLD !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only held drug reports can be released. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		$ok = self::write_status( (int) $id, HNC_Drug_Submit::STATUS_PENDING );
		if ( ! $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action( HNC_Logger::ACTION_UNHOLD, (int) $id );
		return true;
	}


	/* ------------------------------------------------------------------
	 * RESOLVE
	 * ------------------------------------------------------------------
	 *
	 * Approved reports move to resolved when the moderator marks a case as
	 * handled (forwarded to authorities, action taken, no further work
	 * needed). Media is deleted on resolve; phone vault entry is kept
	 * until the standard retention window expires since the operator may
	 * still need to call back to confirm the outcome.
	 */

	/**
	 * Mark an approved report as resolved.
	 *
	 * @param int    $id   Report ID.
	 * @param string $note Optional note.
	 * @return true|WP_Error
	 */
	public static function resolve( $id, $note = '' ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Drug_Submit::STATUS_APPROVED !== $row->status ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Only approved drug reports can be resolved. Current status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		// Remove the media on resolve so the file stops existing as soon as
		// the case is closed.
		if ( ! empty( $row->media_uuid ) && class_exists( 'HNC_Media' ) ) {
			HNC_Media::delete_by_uuid( 'drug', (string) $row->media_uuid );
		}

		global $wpdb;
		$table = self::table();
		$ok    = $wpdb->update(
			$table,
			array(
				'status'       => HNC_Drug_Submit::STATUS_RESOLVED,
				'resolved_at'  => current_time( 'mysql' ),
				'moderated_at' => current_time( 'mysql' ),
				'moderator_id' => get_current_user_id() ? (int) get_current_user_id() : null,
				'media_uuid'   => null,
				'media_type'   => null,
				'media_hash'   => null,
			),
			array( 'id' => (int) $id ),
			array( '%s', '%s', '%s', '%d', '%s', '%s', '%s' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_RESOLVE,
			(int) $id,
			array(
				'note'          => class_exists( 'HNC_Sanitizer' ) ? HNC_Sanitizer::admin_note( $note ) : (string) $note,
				'media_deleted' => ! empty( $row->media_uuid ),
			)
		);
		return true;
	}


	/* ------------------------------------------------------------------
	 * ARCHIVE
	 * ------------------------------------------------------------------ */

	/**
	 * Archive a resolved, approved, or rejected drug report. Archived rows
	 * stay in the database for historical reference but are excluded from
	 * active queues.
	 *
	 * @param int $id Report ID.
	 * @return true|WP_Error
	 */
	public static function archive( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		$allowed_from = array(
			HNC_Drug_Submit::STATUS_APPROVED,
			HNC_Drug_Submit::STATUS_RESOLVED,
			HNC_Drug_Submit::STATUS_REJECTED,
		);
		if ( ! in_array( $row->status, $allowed_from, true ) ) {
			return new WP_Error(
				self::ERR_BAD_STATUS,
				sprintf(
					/* translators: %s: current status */
					__( 'Cannot archive a drug report currently in status: %s', 'helpnagaland-core' ),
					$row->status
				)
			);
		}

		global $wpdb;
		$table = self::table();
		$ok    = $wpdb->update(
			$table,
			array(
				'status'       => HNC_Drug_Submit::STATUS_ARCHIVED,
				'archived_at'  => current_time( 'mysql' ),
				'moderated_at' => current_time( 'mysql' ),
				'moderator_id' => get_current_user_id() ? (int) get_current_user_id() : null,
			),
			array( 'id' => (int) $id ),
			array( '%s', '%s', '%s', '%d' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			HNC_Logger::ACTION_ARCHIVE,
			(int) $id,
			array( 'previous_status' => $row->status )
		);
		return true;
	}


	/* ------------------------------------------------------------------
	 * SEVERITY
	 * ------------------------------------------------------------------ */

	/**
	 * Set the severity flag. 1 (low) to 5 (critical). Used for triage
	 * filtering in the moderation queue. Severity may be set at any point
	 * before archive.
	 *
	 * @param int $id       Report ID.
	 * @param int $severity 1 to 5.
	 * @return true|WP_Error
	 */
	public static function set_severity( $id, $severity ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		$severity = (int) $severity;
		if ( $severity < 1 || $severity > 5 ) {
			return new WP_Error( self::ERR_BAD_SEVERITY, __( 'Severity must be between 1 and 5.', 'helpnagaland-core' ) );
		}

		$row = self::fetch_or_error( (int) $id );
		if ( is_wp_error( $row ) ) {
			return $row;
		}

		if ( HNC_Drug_Submit::STATUS_ARCHIVED === $row->status ) {
			return new WP_Error( self::ERR_BAD_STATUS, __( 'Cannot change severity on an archived report.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$table = self::table();
		$ok    = $wpdb->update(
			$table,
			array( 'severity_flag' => $severity ),
			array( 'id' => (int) $id ),
			array( '%d' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_UPDATE_FAILED, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		self::log_action(
			'set_severity',
			(int) $id,
			array(
				'previous' => is_null( $row->severity_flag ) ? null : (int) $row->severity_flag,
				'new'      => $severity,
			)
		);
		return true;
	}


	/* ------------------------------------------------------------------
	 * READ QUERIES
	 * ------------------------------------------------------------------ */

	/**
	 * Return a paginated list of drug reports for the moderator queue.
	 *
	 * Filters supported:
	 *   - status       (string) default 'pending'
	 *   - district     (string) optional
	 *   - category     (string) optional
	 *   - severity_min (int)    optional
	 *   - page         (int)    default 1
	 *   - per_page     (int)    default 20, max 100
	 *
	 * @param array $filters Filters.
	 * @return array|WP_Error
	 */
	public static function get_queue( $filters = array() ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}

		global $wpdb;
		$table = self::table();

		$status       = isset( $filters['status'] ) ? (string) $filters['status'] : HNC_Drug_Submit::STATUS_PENDING;
		$district     = isset( $filters['district'] ) ? (string) $filters['district'] : '';
		$category     = isset( $filters['category'] ) ? (string) $filters['category'] : '';
		$severity_min = isset( $filters['severity_min'] ) ? (int) $filters['severity_min'] : 0;
		$per_page     = isset( $filters['per_page'] ) ? max( 1, min( 100, (int) $filters['per_page'] ) ) : 20;
		$page         = isset( $filters['page'] ) ? max( 1, (int) $filters['page'] ) : 1;

		$valid_statuses = array(
			HNC_Drug_Submit::STATUS_PENDING,
			HNC_Drug_Submit::STATUS_APPROVED,
			HNC_Drug_Submit::STATUS_REJECTED,
			HNC_Drug_Submit::STATUS_HOLD,
			HNC_Drug_Submit::STATUS_RESOLVED,
			HNC_Drug_Submit::STATUS_ARCHIVED,
		);
		if ( ! in_array( $status, $valid_statuses, true ) ) {
			$status = HNC_Drug_Submit::STATUS_PENDING;
		}

		$where      = array( 'status = %s' );
		$where_args = array( $status );

		if ( '' !== $district ) {
			$where[]      = 'district = %s';
			$where_args[] = $district;
		}
		if ( '' !== $category ) {
			$where[]      = 'category = %s';
			$where_args[] = $category;
		}
		if ( $severity_min > 0 ) {
			$where[]      = 'severity_flag >= %d';
			$where_args[] = $severity_min;
		}

		$where_sql = implode( ' AND ', $where );

		$count_sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM {$table} WHERE {$where_sql}",
			$where_args
		);
		$total = (int) $wpdb->get_var( $count_sql );

		$offset = ( $page - 1 ) * $per_page;
		$order  = ( HNC_Drug_Submit::STATUS_PENDING === $status ) ? 'ASC' : 'DESC';
		$sel    = $wpdb->prepare(
			"SELECT * FROM {$table} WHERE {$where_sql} ORDER BY submitted_at {$order} LIMIT %d OFFSET %d",
			array_merge( $where_args, array( $per_page, $offset ) )
		);
		$rows = $wpdb->get_results( $sel );
		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		return array(
			'rows'     => $rows,
			'total'    => $total,
			'page'     => $page,
			'per_page' => $per_page,
		);
	}

	/**
	 * Fetch a single drug report for moderator view. Caller is responsible
	 * for not echoing free-text fields to anywhere public.
	 *
	 * @param int $id Report ID.
	 * @return object|WP_Error
	 */
	public static function get_report( $id ) {
		$auth = self::require_cap();
		if ( is_wp_error( $auth ) ) {
			return $auth;
		}
		return self::fetch_or_error( (int) $id );
	}

	/**
	 * Look up a drug report by public code for the /status endpoint.
	 *
	 * Unlike the alcohol status endpoint, drug status intentionally gives
	 * the reporter almost nothing: just whether the code exists and the
	 * current high-level status bucket. No district, no category, no text.
	 * This is to prevent the status endpoint from being used as a probe to
	 * reconstruct information about a report.
	 *
	 * @param string $code Canonical code.
	 * @return array|null
	 */
	public static function get_public_status_by_code( $code ) {
		$code = class_exists( 'HNC_Codes' ) ? HNC_Codes::normalize( $code ) : '';
		if ( '' === $code ) {
			return null;
		}

		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT status, submitted_at FROM {$table} WHERE public_code = %s LIMIT 1",
				$code
			)
		);
		if ( ! $row ) {
			return null;
		}

		// Collapse several statuses into a single public value to avoid
		// leaking moderation decisions.
		$bucket = 'received';
		switch ( (string) $row->status ) {
			case HNC_Drug_Submit::STATUS_APPROVED:
			case HNC_Drug_Submit::STATUS_RESOLVED:
				$bucket = 'acted_on';
				break;
			case HNC_Drug_Submit::STATUS_REJECTED:
				$bucket = 'closed';
				break;
			case HNC_Drug_Submit::STATUS_ARCHIVED:
				$bucket = 'archived';
				break;
			case HNC_Drug_Submit::STATUS_PENDING:
			case HNC_Drug_Submit::STATUS_HOLD:
			default:
				$bucket = 'received';
				break;
		}

		return array(
			'status'       => $bucket,
			'submitted_at' => (string) $row->submitted_at,
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Table name helper.
	 *
	 * @return string
	 */
	private static function table() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
	}

	/**
	 * Capability gate.
	 *
	 * @return true|WP_Error
	 */
	private static function require_cap() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_MODERATE_DRUG : 'hnc_moderate_drug';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to moderate drug reports.', 'helpnagaland-core' )
			);
		}
		return true;
	}

	/**
	 * Fetch a row or return WP_Error.
	 *
	 * @param int $id Report ID.
	 * @return object|WP_Error
	 */
	private static function fetch_or_error( $id ) {
		global $wpdb;
		$table = self::table();
		$row   = $wpdb->get_row(
			$wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d LIMIT 1", (int) $id )
		);
		if ( ! $row ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Drug report not found.', 'helpnagaland-core' ) );
		}
		return $row;
	}

	/**
	 * Write a status change with moderator stamp and optional extras.
	 *
	 * @param int    $id     Report ID.
	 * @param string $status New status.
	 * @param array  $extras Extra column => value pairs.
	 * @return bool
	 */
	private static function write_status( $id, $status, $extras = array() ) {
		global $wpdb;
		$table = self::table();

		$data = array_merge(
			array(
				'status'       => $status,
				'moderated_at' => current_time( 'mysql' ),
				'moderator_id' => get_current_user_id() ? (int) get_current_user_id() : null,
			),
			is_array( $extras ) ? $extras : array()
		);

		$formats = array();
		foreach ( $data as $col => $val ) {
			$formats[] = ( 'moderator_id' === $col || 'severity_flag' === $col || 'phone_vault_id' === $col )
				? '%d'
				: '%s';
		}

		$ok = $wpdb->update( $table, $data, array( 'id' => (int) $id ), $formats, array( '%d' ) );
		return ( false !== $ok );
	}

	/**
	 * Log a moderation event with the drug event type.
	 *
	 * @param string $action Action constant or string.
	 * @param int    $id     Report ID.
	 * @param array  $detail Extra detail.
	 * @return void
	 */
	private static function log_action( $action, $id, $detail = array() ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		HNC_Logger::log_drug( (string) $action, (int) $id, is_array( $detail ) ? $detail : array() );
	}
}
