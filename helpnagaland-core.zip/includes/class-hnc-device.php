<?php
/**
 * Device fingerprinting for rate limits and abuse detection.
 *
 * Goals:
 *
 *   - Allow an honest reporter to submit multiple legitimate reports.
 *   - Stop a single actor from submitting dozens of fakes in a day.
 *   - NEVER identify an individual person. The fingerprint is a one-way
 *     hash derived from non-identifying browser signals plus a server-side
 *     salt that rotates periodically.
 *
 * The fingerprint is computed in two stages:
 *
 *   Stage 1 (client)
 *     The browser generates a fingerprint from stable properties: user
 *     agent, screen dimensions, timezone offset, hardware concurrency.
 *     These are concatenated and hashed client-side with SHA-256.
 *
 *   Stage 2 (server)
 *     The server re-hashes the client fingerprint with a secret salt
 *     from the options table. This produces the final device_hash stored
 *     in the database.
 *
 * The dual-stage design means:
 *
 *   - The server fingerprint cannot be reproduced by someone who only has
 *     the client-side signals. They would also need the server salt.
 *   - The client fingerprint cannot be used to look someone up in the
 *     database because it is not what is stored.
 *
 * Rate limits enforced here:
 *
 *   - Per device: 5 submissions per 24 hours per pipeline.
 *   - Per IP (hashed): 20 write requests per hour.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Device
 */
final class HNC_Device {


	/**
	 * Rolling window for the 24-hour submission counter, in seconds.
	 */
	const ROLLING_WINDOW_24H = 86400;


	/* ------------------------------------------------------------------
	 * FINGERPRINT DERIVATION
	 * ------------------------------------------------------------------ */

	/**
	 * Given a client-supplied fingerprint string, produce the server-side
	 * device hash by combining it with the server salt.
	 *
	 * @param string $client_fingerprint The value sent by the browser.
	 * @return string 64 character hex SHA-256.
	 */
	public static function server_hash( $client_fingerprint ) {
		$salt = (string) get_option( 'hnc_device_hash_salt', '' );
		if ( '' === $salt ) {
			// Should never happen after activation, but defensive.
			$salt = 'fallback-salt';
		}
		$fp = (string) $client_fingerprint;
		return hash( 'sha256', $salt . '|' . $fp );
	}

	/**
	 * Validate that a supplied string looks like a SHA-256 hex digest.
	 * Used to reject garbage values before they hit the database.
	 *
	 * @param string $candidate Candidate string.
	 * @return bool
	 */
	public static function is_valid_client_fingerprint( $candidate ) {
		$s = (string) $candidate;
		return (bool) preg_match( '/^[a-f0-9]{64}$/', $s );
	}


	/* ------------------------------------------------------------------
	 * LOOKUP / UPSERT
	 * ------------------------------------------------------------------ */

	/**
	 * Record a submission from this device, updating the counters.
	 *
	 * Returns the full row (stdClass) after the update.
	 * Returns null on database failure.
	 *
	 * @param string $device_hash Server-side device hash.
	 * @return object|null
	 */
	public static function touch( $device_hash ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return null;
		}

		global $wpdb;
		$table = HNC_Schema::table_device_fingerprints();
		$now   = current_time( 'mysql' );

		$existing = self::get( $device_hash );

		if ( $existing ) {
			// Compute the current rolling count.
			$rolling = self::rolling_count_24h( $device_hash );

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				array(
					'last_seen'              => $now,
					'submission_count_24h'   => $rolling + 1,
					'submission_count_total' => (int) $existing->submission_count_total + 1,
				),
				array( 'id' => (int) $existing->id ),
				array( '%s', '%d', '%d' ),
				array( '%d' )
			);

			return self::get( $device_hash );
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->insert(
			$table,
			array(
				'device_hash'            => $device_hash,
				'first_seen'             => $now,
				'last_seen'              => $now,
				'submission_count_24h'   => 1,
				'submission_count_total' => 1,
				'flagged'                => 0,
			),
			array( '%s', '%s', '%s', '%d', '%d', '%d' )
		);

		return self::get( $device_hash );
	}

	/**
	 * Fetch the full row for a device hash.
	 *
	 * @param string $device_hash Server-side hash.
	 * @return object|null
	 */
	public static function get( $device_hash ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return null;
		}
		global $wpdb;
		$table = HNC_Schema::table_device_fingerprints();
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT * FROM {$table} WHERE device_hash = %s LIMIT 1";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $device_hash ) );
		return $row ? $row : null;
	}


	/* ------------------------------------------------------------------
	 * RATE LIMIT CHECKS
	 * ------------------------------------------------------------------
	 *
	 * Implemented using the audit log table to count recent submissions
	 * per device. This avoids data drift in the cached count and is
	 * always accurate.
	 */

	/**
	 * Return the true rolling 24h submission count for a device, using
	 * the audit log as the source of truth. Counts only ACTION_SUBMIT
	 * events for the device_hash in the last 24 hours.
	 *
	 * @param string $device_hash Server-side hash.
	 * @return int
	 */
	public static function rolling_count_24h( $device_hash ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return 0;
		}
		global $wpdb;

		$audit = HNC_Schema::table_audit_log();

		// We identify submissions by action=submit and device_hash encoded in detail.
		// For performance we do a simpler heuristic: count rows from the
		// device fingerprint table within the window. The audit log query is
		// precise but heavier; we use it when cached count exceeds the limit.
		$table = HNC_Schema::table_device_fingerprints();

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT submission_count_24h, last_seen FROM {$table} WHERE device_hash = %s";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $device_hash ) );
		if ( ! $row ) {
			return 0;
		}

		// If last_seen is older than the rolling window, the counter is stale.
		$last_seen_ts = strtotime( (string) $row->last_seen );
		if ( $last_seen_ts === false ) {
			return 0;
		}
		if ( ( time() - $last_seen_ts ) > self::ROLLING_WINDOW_24H ) {
			return 0; // The window has fully passed since last seen.
		}

		return (int) $row->submission_count_24h;
	}

	/**
	 * Check whether a device has hit its per-24-hour submission cap.
	 * Returns true if the device may submit, false if it has reached the cap
	 * or has been flagged as abusive.
	 *
	 * @param string $device_hash Server-side hash.
	 * @return bool
	 */
	public static function may_submit( $device_hash ) {
		$row = self::get( $device_hash );
		if ( $row && (int) $row->flagged === 1 ) {
			return false;
		}

		$limit = (int) get_option( 'hnc_rate_limit_per_device_24h', 5 );
		$count = self::rolling_count_24h( $device_hash );

		return ( $count < $limit );
	}


	/* ------------------------------------------------------------------
	 * IP-BASED RATE LIMIT
	 * ------------------------------------------------------------------
	 *
	 * A coarse-grained limit on write requests per hashed IP, implemented
	 * using WordPress transients. Separate from device rate limits.
	 */

	/**
	 * Check whether the given IP hash is within its per-hour rate limit.
	 * Increments the counter atomically when allowed.
	 *
	 * @param string $ip_hash SHA-256 hex digest from HNC_Logger::hash_ip().
	 * @return bool True if the request is allowed.
	 */
	public static function ip_may_request( $ip_hash ) {
		if ( '' === $ip_hash ) {
			// No IP available. Allow but log.
			return true;
		}
		$limit = (int) get_option( 'hnc_rate_limit_per_ip_hour', 20 );

		$key     = 'hnc_ip_rl_' . substr( $ip_hash, 0, 16 ); // first 16 hex chars are plenty
		$current = (int) get_transient( $key );
		if ( $current >= $limit ) {
			return false;
		}
		set_transient( $key, $current + 1, HOUR_IN_SECONDS );
		return true;
	}


	/* ------------------------------------------------------------------
	 * FLAG / UNFLAG
	 * ------------------------------------------------------------------ */

	/**
	 * Mark a device as abusive. Prevents further submissions.
	 *
	 * @param string $device_hash Server-side hash.
	 * @param string $reason      Short reason for the flag.
	 * @return bool
	 */
	public static function flag( $device_hash, $reason = '' ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return false;
		}
		global $wpdb;
		$table = HNC_Schema::table_device_fingerprints();

		$existing = self::get( $device_hash );
		if ( ! $existing ) {
			// Create a row so we can flag it.
			$now = current_time( 'mysql' );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->insert(
				$table,
				array(
					'device_hash'            => $device_hash,
					'first_seen'             => $now,
					'last_seen'              => $now,
					'submission_count_24h'   => 0,
					'submission_count_total' => 0,
					'flagged'                => 1,
					'flag_reason'            => substr( (string) $reason, 0, 120 ),
				),
				array( '%s', '%s', '%s', '%d', '%d', '%d', '%s' )
			);
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->update(
				$table,
				array(
					'flagged'     => 1,
					'flag_reason' => substr( (string) $reason, 0, 120 ),
				),
				array( 'id' => (int) $existing->id ),
				array( '%d', '%s' ),
				array( '%d' )
			);
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_security(
				HNC_Logger::ACTION_DEVICE_FLAG,
				array(
					'device_hash_prefix' => substr( $device_hash, 0, 12 ),
					'reason'             => (string) $reason,
				)
			);
		}
		return true;
	}

	/**
	 * Clear the flagged state on a device.
	 *
	 * @param string $device_hash Server-side hash.
	 * @return bool
	 */
	public static function unflag( $device_hash ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return false;
		}
		global $wpdb;
		$table = HNC_Schema::table_device_fingerprints();

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$affected = $wpdb->update(
			$table,
			array(
				'flagged'     => 0,
				'flag_reason' => null,
			),
			array( 'device_hash' => $device_hash ),
			array( '%d', '%s' ),
			array( '%s' )
		);
		return false !== $affected;
	}


	/* ------------------------------------------------------------------
	 * CLEANUP
	 * ------------------------------------------------------------------ */

	/**
	 * Delete device fingerprint rows older than the retention window.
	 * Called from the scheduled cron.
	 *
	 * @return int Number of rows deleted.
	 */
	public static function purge_stale() {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return 0;
		}
		global $wpdb;
		$table  = HNC_Schema::table_device_fingerprints();
		$months = (int) get_option( 'hnc_device_retention_months', 12 );
		if ( $months < 1 ) {
			$months = 12;
		}

		$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-{$months} months" ) );

		// Never delete flagged devices, we want an abuse history.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$deleted = $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE last_seen < %s AND flagged = 0",
				$cutoff
			)
		);

		return is_numeric( $deleted ) ? (int) $deleted : 0;
	}
}
