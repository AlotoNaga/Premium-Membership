<?php
/**
 * Transparency Export: CSV and JSON download endpoints.
 *
 * Builds machine-readable exports of published transparency snapshots so
 * journalists, researchers, and government partners can pull the numbers
 * without scraping the HTML transparency page.
 *
 * Four public REST endpoints:
 *
 *   GET /hnc/v1/transparency/export/csv
 *       Returns a CSV of all published snapshots, most recent first.
 *       Content-Type: text/csv. Safe to open in Excel or pipe into pandas.
 *
 *   GET /hnc/v1/transparency/export/json
 *       Returns a JSON array of all published snapshots.
 *
 *   GET /hnc/v1/transparency/export/csv/{year}/{month}
 *       Returns a CSV with one data row for a specific period.
 *
 *   GET /hnc/v1/transparency/export/json/{year}/{month}
 *       Returns a JSON object for a specific period.
 *
 * Only PUBLISHED snapshots are exposed. Draft snapshots are admin-only
 * and accessed via the Phase 6 admin REST surface.
 *
 * The endpoints set a long cache-control so CDN caching is safe. A
 * snapshot once published is immutable except for admin_note edits,
 * which are rare enough that stale cache is an acceptable tradeoff.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Transparency_Export
 */
final class HNC_Transparency_Export {


	/** CSV cache duration in seconds (1 day). */
	const CACHE_TTL_SECONDS = 86400;

	/** Max rows in a bulk export. */
	const MAX_BULK_ROWS = 240;


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register the four export endpoints. All public.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/transparency/export/csv',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_bulk_csv' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/transparency/export/json',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_bulk_json' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/transparency/export/csv/(?P<year>\d{4})/(?P<month>\d{1,2})',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_single_csv' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'year'  => array( 'type' => 'integer', 'required' => true ),
					'month' => array( 'type' => 'integer', 'required' => true ),
				),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/transparency/export/json/(?P<year>\d{4})/(?P<month>\d{1,2})',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_single_json' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'year'  => array( 'type' => 'integer', 'required' => true ),
					'month' => array( 'type' => 'integer', 'required' => true ),
				),
			)
		);
	}


	/* ------------------------------------------------------------------
	 * REST CALLBACKS
	 * ------------------------------------------------------------------ */

	/**
	 * Bulk CSV export of every published snapshot.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_bulk_csv() {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}
		$rows = self::fetch_published_rows();
		$csv  = self::rows_to_csv( $rows );
		return self::csv_response( $csv, 'helpnagaland-transparency.csv' );
	}

	/**
	 * Bulk JSON export of every published snapshot.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_bulk_json() {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}
		$rows = self::fetch_published_rows();
		$out  = array_map( array( __CLASS__, 'shape_row' ), $rows );
		$response = new WP_REST_Response(
			array(
				'success' => true,
				'count'   => count( $out ),
				'data'    => $out,
			),
			200
		);
		$response->header( 'Cache-Control', 'public, max-age=' . self::CACHE_TTL_SECONDS );
		return $response;
	}

	/**
	 * Single-period CSV export.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_single_csv( $request ) {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}
		$year  = (int) $request->get_param( 'year' );
		$month = (int) $request->get_param( 'month' );
		$row   = self::fetch_published_single( $year, $month );
		if ( null === $row ) {
			return self::not_found_response();
		}
		$csv = self::rows_to_csv( array( $row ) );
		return self::csv_response( $csv, sprintf( 'helpnagaland-transparency-%04d-%02d.csv', $year, $month ) );
	}

	/**
	 * Single-period JSON export.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_single_json( $request ) {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}
		$year  = (int) $request->get_param( 'year' );
		$month = (int) $request->get_param( 'month' );
		$row   = self::fetch_published_single( $year, $month );
		if ( null === $row ) {
			return self::not_found_response();
		}
		$response = new WP_REST_Response(
			array(
				'success' => true,
				'data'    => self::shape_row( $row ),
			),
			200
		);
		$response->header( 'Cache-Control', 'public, max-age=' . self::CACHE_TTL_SECONDS );
		return $response;
	}


	/* ------------------------------------------------------------------
	 * PUBLIC BUILDERS
	 * ------------------------------------------------------------------
	 *
	 * These static methods are exposed for admin exports, WP-CLI, and
	 * any Phase 7 admin UI button that wants to produce a CSV/JSON on
	 * demand without going through the public REST endpoints.
	 */

	/**
	 * Produce a CSV string for a single published period, or empty string.
	 *
	 * @param int $year  Year.
	 * @param int $month Month.
	 * @return string
	 */
	public static function csv( $year, $month ) {
		$row = self::fetch_published_single( (int) $year, (int) $month );
		return ( null === $row ) ? '' : self::rows_to_csv( array( $row ) );
	}

	/**
	 * Produce a JSON-encoded string for a single published period.
	 *
	 * @param int $year  Year.
	 * @param int $month Month.
	 * @return string JSON or empty string.
	 */
	public static function json( $year, $month ) {
		$row = self::fetch_published_single( (int) $year, (int) $month );
		if ( null === $row ) {
			return '';
		}
		return wp_json_encode( self::shape_row( $row ) );
	}

	/**
	 * Produce a CSV of all published periods.
	 *
	 * @return string
	 */
	public static function csv_all() {
		$rows = self::fetch_published_rows();
		return self::rows_to_csv( $rows );
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Return published snapshot rows in reverse chronological order.
	 *
	 * @return array Array of stdClass rows.
	 */
	private static function fetch_published_rows() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT period_year, period_month,
				        alcohol_received, alcohol_approved, alcohol_rejected, alcohol_acted_by_police,
				        drug_received, drug_approved, drug_forwarded, drug_acted,
				        published_at, admin_note
				 FROM {$table}
				 WHERE published_at IS NOT NULL
				 ORDER BY period_year DESC, period_month DESC
				 LIMIT %d",
				self::MAX_BULK_ROWS
			)
		);
		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Return a single published snapshot or null.
	 *
	 * @param int $year  Year.
	 * @param int $month Month.
	 * @return object|null
	 */
	private static function fetch_published_single( $year, $month ) {
		if ( $year < 2020 || $year > 2100 || $month < 1 || $month > 12 ) {
			return null;
		}
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT period_year, period_month,
				        alcohol_received, alcohol_approved, alcohol_rejected, alcohol_acted_by_police,
				        drug_received, drug_approved, drug_forwarded, drug_acted,
				        published_at, admin_note
				 FROM {$table}
				 WHERE period_year = %d
				   AND period_month = %d
				   AND published_at IS NOT NULL
				 LIMIT 1",
				(int) $year,
				(int) $month
			)
		);
		return $row ? $row : null;
	}

	/**
	 * Convert a row (stdClass from DB) to the public-safe JSON shape.
	 *
	 * @param object $row Row.
	 * @return array
	 */
	private static function shape_row( $row ) {
		return array(
			'period' => sprintf( '%04d-%02d', (int) $row->period_year, (int) $row->period_month ),
			'year'   => (int) $row->period_year,
			'month'  => (int) $row->period_month,
			'alcohol' => array(
				'received'        => (int) $row->alcohol_received,
				'approved'        => (int) $row->alcohol_approved,
				'rejected'        => (int) $row->alcohol_rejected,
				'acted_by_police' => (int) $row->alcohol_acted_by_police,
			),
			'drug' => array(
				'received'  => (int) $row->drug_received,
				'approved'  => (int) $row->drug_approved,
				'forwarded' => (int) $row->drug_forwarded,
				'acted'     => (int) $row->drug_acted,
			),
			'published_at' => (string) $row->published_at,
			'note'         => is_null( $row->admin_note ) ? '' : (string) $row->admin_note,
		);
	}

	/**
	 * Convert rows to a CSV string. Headers come first. Uses fputcsv via
	 * an in-memory php://temp stream so quoting is correct for commas,
	 * newlines, and double quotes inside fields (like admin_note).
	 *
	 * @param array $rows Array of stdClass rows.
	 * @return string
	 */
	private static function rows_to_csv( $rows ) {
		$headers = array(
			'period', 'year', 'month',
			'alcohol_received', 'alcohol_approved', 'alcohol_rejected', 'alcohol_acted_by_police',
			'drug_received', 'drug_approved', 'drug_forwarded', 'drug_acted',
			'published_at', 'note',
		);

		$fh = fopen( 'php://temp', 'r+' );
		if ( false === $fh ) {
			return implode( ',', $headers ) . "\n";
		}

		// UTF-8 BOM helps Excel open the file with correct encoding.
		fwrite( $fh, "\xEF\xBB\xBF" );

		fputcsv( $fh, $headers );

		foreach ( $rows as $r ) {
			$period = sprintf( '%04d-%02d', (int) $r->period_year, (int) $r->period_month );
			fputcsv(
				$fh,
				array(
					self::csv_safe( $period ),
					(int) $r->period_year,
					(int) $r->period_month,
					(int) $r->alcohol_received,
					(int) $r->alcohol_approved,
					(int) $r->alcohol_rejected,
					(int) $r->alcohol_acted_by_police,
					(int) $r->drug_received,
					(int) $r->drug_approved,
					(int) $r->drug_forwarded,
					(int) $r->drug_acted,
					self::csv_safe( (string) $r->published_at ),
					self::csv_safe( is_null( $r->admin_note ) ? '' : (string) $r->admin_note ),
				)
			);
		}

		rewind( $fh );
		$out = stream_get_contents( $fh );
		fclose( $fh );
		return ( false === $out ) ? '' : $out;
	}

	/**
	 * Neutralise CSV injection. Spreadsheet apps interpret a leading
	 * `=`, `+`, `-`, `@`, tab or CR as the start of a formula. A
	 * reporter or moderator who managed to place such a character in a
	 * free-text admin_note could execute code in a user's Excel when
	 * the CSV is opened. Prepending a single quote converts the cell
	 * to a literal string in every spreadsheet implementation that
	 * auto-parses formulas.
	 *
	 * Reference: OWASP CSV Injection / CWE-1236.
	 *
	 * @param string $value Raw cell value.
	 * @return string Safe cell value.
	 */
	private static function csv_safe( $value ) {
		$value = (string) $value;
		if ( '' === $value ) {
			return $value;
		}
		$first = $value[0];
		if ( '=' === $first || '+' === $first || '-' === $first || '@' === $first
			|| "\t" === $first || "\r" === $first ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * Build a CSV response with appropriate headers.
	 *
	 * @param string $csv      CSV content.
	 * @param string $filename Suggested filename.
	 * @return WP_REST_Response
	 */
	private static function csv_response( $csv, $filename ) {
		$response = new WP_REST_Response( $csv, 200 );
		$response->header( 'Content-Type', 'text/csv; charset=UTF-8' );
		$safe_filename = preg_replace( '/[^A-Za-z0-9._-]/', '_', (string) $filename );
		$response->header( 'Content-Disposition', 'attachment; filename="' . $safe_filename . '"' );
		$response->header( 'Cache-Control', 'public, max-age=' . self::CACHE_TTL_SECONDS );
		$response->header( 'X-Content-Type-Options', 'nosniff' );
		return $response;
	}

	/**
	 * Return a standard "published snapshot not found" 404.
	 *
	 * @return WP_REST_Response
	 */
	private static function not_found_response() {
		return new WP_REST_Response(
			array(
				'success' => false,
				'code'    => 'hnc_snapshot_not_found',
				'message' => __( 'No published snapshot for that period.', 'helpnagaland-core' ),
			),
			404
		);
	}
}
