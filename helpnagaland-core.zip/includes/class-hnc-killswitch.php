<?php
/**
 * Emergency kill switch.
 *
 * Purpose: give the operator a single button that removes the platform
 * from public availability in under a minute, while preserving all data.
 *
 * What the kill switch DOES:
 *
 *   - Rejects every public write endpoint (alcohol/submit, drug/submit, etc).
 *   - Hides the public map by refusing the map/public endpoint.
 *   - Shows a maintenance message on all public frontend pages.
 *   - Prevents status code lookups (so reporters cannot probe state).
 *
 * What the kill switch does NOT do:
 *
 *   - Does not affect WP-Admin access. Moderators and the admin can
 *     still log in, review queues, and export data.
 *   - Does not delete data. All existing reports remain in the database.
 *   - Does not turn off the plugin. It is a soft state, toggleable.
 *
 * Use cases:
 *
 *   - A legal threat is received and the lawyer advises temporary takedown.
 *   - A live DDoS or abuse campaign is underway and needs containment.
 *   - An admin error (wrong settings) needs to be rolled back quickly.
 *   - Any situation where "pull the plug on the public side" is the
 *     safest next step while other decisions are made.
 *
 * Activating the kill switch writes an immutable audit log entry so the
 * incident timeline is preserved. Deactivating it also logs.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Killswitch
 */
final class HNC_Killswitch {


	/**
	 * Option key.
	 */
	const OPT_ACTIVE     = 'hnc_killswitch_active';
	const OPT_ACTIVATED  = 'hnc_killswitch_activated_at';
	const OPT_DEACTIVATED = 'hnc_killswitch_deactivated_at';
	const OPT_REASON     = 'hnc_killswitch_reason';
	const OPT_MESSAGE    = 'hnc_killswitch_message';


	/* ------------------------------------------------------------------
	 * STATE QUERIES
	 * ------------------------------------------------------------------ */

	/**
	 * True if the kill switch is currently engaged.
	 *
	 * @return bool
	 */
	public static function is_active() {
		return (int) get_option( self::OPT_ACTIVE, 0 ) === 1;
	}

	/**
	 * Alias for is_active, used at public-surface guard points so the call
	 * reads naturally: `if ( HNC_Killswitch::is_blocking_public() ) { ... }`.
	 *
	 * @return bool
	 */
	public static function is_blocking_public() {
		return self::is_active();
	}

	/**
	 * Get the current public-facing maintenance message, falling back to
	 * a sensible default if none was set.
	 *
	 * @return string
	 */
	public static function public_message() {
		$msg = (string) get_option( self::OPT_MESSAGE, '' );
		if ( '' === $msg ) {
			$msg = __(
				'Clean Nagaland is temporarily offline while we address an urgent matter. We will be back shortly. Thank you for your patience.',
				'helpnagaland-core'
			);
		}
		return $msg;
	}

	/**
	 * Get the internal reason recorded when the kill switch was last activated.
	 * Not shown to the public.
	 *
	 * @return string
	 */
	public static function internal_reason() {
		return (string) get_option( self::OPT_REASON, '' );
	}

	/**
	 * Timestamp at which the kill switch was last activated, or empty string.
	 *
	 * @return string
	 */
	public static function activated_at() {
		return (string) get_option( self::OPT_ACTIVATED, '' );
	}


	/* ------------------------------------------------------------------
	 * ACTIVATE / DEACTIVATE
	 * ------------------------------------------------------------------ */

	/**
	 * Engage the kill switch. Requires the caller to have the
	 * hnc_operate_killswitch capability. Returns true if the state changed,
	 * false if it was already active or permission denied.
	 *
	 * @param string $internal_reason Short reason for the audit log (admin-only text).
	 * @param string $public_message  Optional custom public-facing message.
	 * @return bool
	 */
	public static function activate( $internal_reason = '', $public_message = '' ) {
		if ( ! self::caller_can() ) {
			return false;
		}
		if ( self::is_active() ) {
			return false;
		}

		update_option( self::OPT_ACTIVE, 1 );
		update_option( self::OPT_ACTIVATED, current_time( 'mysql' ) );
		update_option( self::OPT_REASON, self::sanitize_short( $internal_reason, 500 ) );
		if ( '' !== $public_message ) {
			update_option( self::OPT_MESSAGE, self::sanitize_short( $public_message, 500 ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log(
				HNC_Logger::EVENT_KILLSWITCH,
				HNC_Logger::ACTION_KILLSWITCH_ON,
				array(
					'report_type' => 'system',
					'detail'      => array(
						'internal_reason' => self::sanitize_short( $internal_reason, 500 ),
					),
				)
			);
		}

		// Fire an action so other subsystems (caching, CDN) can react.
		do_action( 'hnc_killswitch_activated', self::internal_reason() );

		return true;
	}

	/**
	 * Disengage the kill switch. Requires capability. Returns true if the
	 * state changed, false if already off or permission denied.
	 *
	 * @param string $notes Optional note for the audit log.
	 * @return bool
	 */
	public static function deactivate( $notes = '' ) {
		if ( ! self::caller_can() ) {
			return false;
		}
		if ( ! self::is_active() ) {
			return false;
		}

		update_option( self::OPT_ACTIVE, 0 );
		update_option( self::OPT_DEACTIVATED, current_time( 'mysql' ) );

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log(
				HNC_Logger::EVENT_KILLSWITCH,
				HNC_Logger::ACTION_KILLSWITCH_OFF,
				array(
					'report_type' => 'system',
					'detail'      => array(
						'notes' => self::sanitize_short( $notes, 500 ),
					),
				)
			);
		}

		do_action( 'hnc_killswitch_deactivated' );

		return true;
	}


	/* ------------------------------------------------------------------
	 * GUARDS
	 * ------------------------------------------------------------------
	 *
	 * Convenience helpers for use inside public endpoint handlers. Each
	 * guard returns a WP_REST_Response on block, or null when the
	 * caller should proceed normally. Use like:
	 *
	 *   $blocked = HNC_Killswitch::guard_public_endpoint();
	 *   if ( $blocked ) { return $blocked; }
	 */

	/**
	 * Return a 503 REST response if the kill switch is active, otherwise null.
	 *
	 * @return \WP_REST_Response|null
	 */
	public static function guard_public_endpoint() {
		if ( ! self::is_blocking_public() ) {
			return null;
		}
		if ( ! class_exists( 'WP_REST_Response' ) ) {
			return null; // cannot block without REST context
		}
		$response = new WP_REST_Response(
			array(
				'code'    => 'hnc_platform_paused',
				'message' => self::public_message(),
				'data'    => array( 'status' => 503 ),
			),
			503
		);
		// Retry-After header tells well-behaved clients to back off.
		$response->header( 'Retry-After', '3600' );
		return $response;
	}

	/**
	 * True if the admin UI should show a red banner warning that the kill
	 * switch is engaged.
	 *
	 * @return bool
	 */
	public static function should_show_admin_banner() {
		return self::is_active();
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * True if the current user can operate the kill switch.
	 *
	 * @return bool
	 */
	private static function caller_can() {
		if ( ! function_exists( 'current_user_can' ) ) {
			return false;
		}
		if ( class_exists( 'HNC_Roles' ) ) {
			return current_user_can( HNC_Roles::CAP_OPERATE_KILLSWITCH );
		}
		return current_user_can( 'manage_options' );
	}

	/**
	 * Sanitize a short piece of operator-entered text for storage.
	 *
	 * @param string $s   Input.
	 * @param int    $max Max length.
	 * @return string
	 */
	private static function sanitize_short( $s, $max ) {
		$s = (string) $s;
		if ( function_exists( 'wp_strip_all_tags' ) ) {
			$s = wp_strip_all_tags( $s, true );
		} else {
			$s = strip_tags( $s );
		}
		$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s );
		$s = trim( preg_replace( '/\s+/u', ' ', $s ) );
		if ( function_exists( 'mb_substr' ) ) {
			return mb_substr( $s, 0, $max, 'UTF-8' );
		}
		return substr( $s, 0, $max );
	}
}
