<?php
/**
 * Database schema for Help Nagaland Core.
 *
 * All CREATE TABLE statements live in this file. When the schema needs to
 * change, you:
 *
 *   1. Modify the CREATE TABLE statement(s) below.
 *   2. Bump HNC_DB_VERSION in helpnagaland-core.php.
 *   3. On next page load, the main bootstrap detects the version mismatch and
 *      calls HNC_Schema::install() which runs dbDelta to apply the changes.
 *
 * dbDelta is idempotent when used correctly, but it is also picky about
 * formatting. The rules are:
 *
 *   - Each column on its own line.
 *   - Use KEY not INDEX for secondary indexes.
 *   - Two spaces between "PRIMARY KEY" and the column definition.
 *   - No backticks around column or table names.
 *   - No FOREIGN KEY constraints (dbDelta drops them silently).
 *
 * Foreign key style relationships are enforced in PHP code at the model layer
 * rather than at the database layer. This matches the WordPress convention.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Schema
 *
 * Handles creation, upgrade, and teardown of all database tables used by
 * the Help Nagaland Core plugin.
 */
final class HNC_Schema {


	/* --------------------------------------------------------------
	 * TABLE NAME HELPERS
	 * --------------------------------------------------------------
	 *
	 * All HNC tables are prefixed with the WordPress prefix plus "hnc_".
	 * For the default WP install this gives names like wp_hnc_alcohol_reports.
	 * Always access table names through the helper methods below, never
	 * hardcode a table name elsewhere in the codebase.
	 */

	/**
	 * Returns the full name of the hnc_alcohol_reports table.
	 *
	 * @return string
	 */
	public static function table_alcohol_reports() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
	}

	/**
	 * Returns the full name of the hnc_drug_reports table.
	 *
	 * @return string
	 */
	public static function table_drug_reports() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
	}

	/**
	 * Returns the full name of the hnc_phone_vault table.
	 *
	 * @return string
	 */
	public static function table_phone_vault() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'phone_vault';
	}

	/**
	 * Returns the full name of the hnc_audit_log table.
	 *
	 * @return string
	 */
	public static function table_audit_log() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'audit_log';
	}

	/**
	 * Returns the full name of the hnc_device_fingerprints table.
	 *
	 * @return string
	 */
	public static function table_device_fingerprints() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'device_fingerprints';
	}

	/**
	 * Returns the full name of the hnc_transparency_snapshots table.
	 *
	 * @return string
	 */
	public static function table_transparency_snapshots() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'transparency_snapshots';
	}

	/**
	 * Returns the full name of the hnc_partners table.
	 *
	 * @return string
	 */
	public static function table_partners() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'partners';
	}

	/**
	 * Partner forwards junction table (Phase 10).
	 *
	 * @return string
	 */
	public static function table_partner_forwards() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'partner_forwards';
	}

	/**
	 * Returns the full name of the hnc_donations table.
	 * Owned by HNC_Payment; one row per donation (one-time or subscription).
	 *
	 * @return string
	 */
	public static function table_donations() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'donations';
	}

	/**
	 * Returns the full name of the hnc_payment_events table.
	 * Owned by HNC_Payment; append-only ledger of webhook events.
	 *
	 * @return string
	 */
	public static function table_payment_events() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'payment_events';
	}

	/**
	 * Returns the full name of the hnc_payment_customers table.
	 * Owned by HNC_Payment; donor cache keyed on email hash.
	 *
	 * @return string
	 */
	public static function table_payment_customers() {
		global $wpdb;
		return $wpdb->prefix . HNC_TABLE_PREFIX . 'payment_customers';
	}

	/**
	 * Returns all HNC table names as an array.
	 *
	 * @return string[]
	 */
	public static function all_tables() {
		return array(
			self::table_alcohol_reports(),
			self::table_drug_reports(),
			self::table_phone_vault(),
			self::table_audit_log(),
			self::table_device_fingerprints(),
			self::table_transparency_snapshots(),
			self::table_partners(),
			self::table_partner_forwards(),
			self::table_donations(),
			self::table_payment_events(),
			self::table_payment_customers(),
		);
	}


	/* --------------------------------------------------------------
	 * INSTALL
	 * -------------------------------------------------------------- */

	/**
	 * Install or upgrade all tables. Safe to run multiple times.
	 *
	 * @return void
	 */
	public static function install() {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$statements = array(
			self::create_alcohol_reports( $charset_collate ),
			self::create_drug_reports( $charset_collate ),
			self::create_phone_vault( $charset_collate ),
			self::create_audit_log( $charset_collate ),
			self::create_device_fingerprints( $charset_collate ),
			self::create_transparency_snapshots( $charset_collate ),
			self::create_partners( $charset_collate ),
			self::create_partner_forwards( $charset_collate ),
			self::create_donations( $charset_collate ),
			self::create_payment_events( $charset_collate ),
			self::create_payment_customers( $charset_collate ),
		);

		foreach ( $statements as $sql ) {
			// dbDelta returns an array of results, mostly informational.
			// We intentionally do not halt on individual statement failures
			// because dbDelta sometimes returns non fatal notices.
			dbDelta( $sql );
		}
	}

	/**
	 * Drop all tables. Called only from uninstall.php with explicit opt in.
	 *
	 * @return void
	 */
	public static function drop_all() {
		global $wpdb;
		foreach ( self::all_tables() as $table ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
		}
	}

	/**
	 * Verify that all expected tables exist in the database.
	 * Used by the health check screen.
	 *
	 * @return array Map of table name => bool exists.
	 */
	public static function verify() {
		global $wpdb;
		$result = array();
		foreach ( self::all_tables() as $table ) {
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$found            = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			$result[ $table ] = ( $found === $table );
		}
		return $result;
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_alcohol_reports
	 * --------------------------------------------------------------
	 *
	 * Holds every alcohol report, from pending through archived. The lat/lng
	 * columns store the grid snapped coordinates used for public display.
	 * The lat_raw/lng_raw columns store the original GPS reading and are
	 * admin only.
	 */
	private static function create_alcohol_reports( $charset_collate ) {
		$table = self::table_alcohol_reports();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			public_code VARCHAR(9) NOT NULL,
			lat DECIMAL(10,7) NOT NULL,
			lng DECIMAL(10,7) NOT NULL,
			lat_raw DECIMAL(10,7) NOT NULL,
			lng_raw DECIMAL(10,7) NOT NULL,
			district VARCHAR(60) NOT NULL DEFAULT '',
			category VARCHAR(40) NOT NULL,
			description TEXT NULL,
			time_pattern VARCHAR(30) NULL,
			photo_uuid CHAR(36) NULL,
			photo_hash CHAR(64) NULL,
			device_hash CHAR(64) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			verified_by_operator TINYINT(1) NOT NULL DEFAULT 0,
			merged_into BIGINT UNSIGNED NULL,
			report_count INT UNSIGNED NOT NULL DEFAULT 1,
			phone_vault_id BIGINT UNSIGNED NULL,
			submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			moderated_at DATETIME NULL,
			moderator_id BIGINT UNSIGNED NULL,
			rejection_reason VARCHAR(120) NULL,
			archived_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY public_code (public_code),
			KEY status_submitted (status, submitted_at),
			KEY district_category (district, category),
			KEY device_hash (device_hash),
			KEY merged_into (merged_into),
			KEY phone_vault_id (phone_vault_id),
			KEY lat_lng (lat, lng),
			KEY moderator_id (moderator_id)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_drug_reports
	 * --------------------------------------------------------------
	 *
	 * Drug reports are confidential. No row in this table should ever be
	 * exposed via a public REST endpoint. Aggregate counts only are allowed
	 * on the transparency page.
	 */
	private static function create_drug_reports( $charset_collate ) {
		$table = self::table_drug_reports();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			public_code VARCHAR(9) NOT NULL,
			district VARCHAR(60) NOT NULL,
			area_desc VARCHAR(200) NOT NULL,
			category VARCHAR(40) NOT NULL,
			pattern TEXT NOT NULL,
			vehicle_info VARCHAR(100) NULL,
			media_uuid CHAR(36) NULL,
			media_type VARCHAR(20) NULL,
			media_hash CHAR(64) NULL,
			submission_mode VARCHAR(20) NOT NULL DEFAULT 'anonymous',
			phone_vault_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			severity_flag TINYINT NULL,
			submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			moderated_at DATETIME NULL,
			moderator_id BIGINT UNSIGNED NULL,
			resolved_at DATETIME NULL,
			archived_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY public_code (public_code),
			KEY status_submitted (status, submitted_at),
			KEY district_category (district, category),
			KEY submission_mode (submission_mode),
			KEY phone_vault_id (phone_vault_id),
			KEY severity_flag (severity_flag),
			KEY moderator_id (moderator_id)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_phone_vault
	 * --------------------------------------------------------------
	 *
	 * Encrypted phone storage. Phones are encrypted with AES-256-GCM. The
	 * encryption key itself is NOT stored anywhere in the database. It is
	 * derived at vault unlock time from a passphrase known only to the admin,
	 * held in a PHP session for at most 15 minutes, then discarded.
	 *
	 * If the admin forgets the passphrase, the vault is permanently
	 * inaccessible. This is a deliberate design choice.
	 */
	private static function create_phone_vault( $charset_collate ) {
		$table = self::table_phone_vault();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			report_type VARCHAR(20) NOT NULL,
			report_id BIGINT UNSIGNED NOT NULL,
			encrypted_phone VARBINARY(255) NOT NULL,
			nonce VARBINARY(16) NOT NULL,
			tag VARBINARY(16) NOT NULL,
			consent_forward TINYINT(1) NOT NULL DEFAULT 0,
			consent_partner VARCHAR(60) NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			scheduled_delete_at DATETIME NOT NULL,
			deleted_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY report_lookup (report_type, report_id),
			KEY scheduled_delete_at (scheduled_delete_at),
			KEY deleted_at (deleted_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_audit_log
	 * --------------------------------------------------------------
	 *
	 * Immutable record of every admin action, partner action, and sensitive
	 * system event. Entries are append only. The admin UI does not expose
	 * a delete button. Logs are retained for 5 years then archived to cold
	 * storage by the retention cron.
	 */
	private static function create_audit_log( $charset_collate ) {
		$table = self::table_audit_log();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			event_type VARCHAR(40) NOT NULL,
			actor_id BIGINT UNSIGNED NULL,
			report_type VARCHAR(20) NULL,
			report_id BIGINT UNSIGNED NULL,
			action VARCHAR(40) NOT NULL,
			detail TEXT NULL,
			ip_hash CHAR(64) NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY  (id),
			KEY event_type (event_type),
			KEY actor_id (actor_id),
			KEY report_lookup (report_type, report_id),
			KEY created_at (created_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_device_fingerprints
	 * --------------------------------------------------------------
	 *
	 * Non reversible device fingerprint hashes used for rate limiting and
	 * abuse detection. The hash is derived from stable browser properties
	 * and cannot be used to identify a person, but it is stable enough
	 * to catch repeat abusers.
	 */
	private static function create_device_fingerprints( $charset_collate ) {
		$table = self::table_device_fingerprints();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			device_hash CHAR(64) NOT NULL,
			first_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			submission_count_24h INT UNSIGNED NOT NULL DEFAULT 0,
			submission_count_total INT UNSIGNED NOT NULL DEFAULT 0,
			flagged TINYINT(1) NOT NULL DEFAULT 0,
			flag_reason VARCHAR(120) NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY device_hash (device_hash),
			KEY flagged (flagged),
			KEY last_seen (last_seen)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_transparency_snapshots
	 * --------------------------------------------------------------
	 *
	 * Monthly aggregate statistics published on the transparency page.
	 * Snapshots are never edited once published. Corrections are added
	 * as appended notes.
	 */
	private static function create_transparency_snapshots( $charset_collate ) {
		$table = self::table_transparency_snapshots();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			period_year SMALLINT NOT NULL,
			period_month TINYINT NOT NULL,
			alcohol_received INT NOT NULL DEFAULT 0,
			alcohol_approved INT NOT NULL DEFAULT 0,
			alcohol_rejected INT NOT NULL DEFAULT 0,
			alcohol_acted_by_police INT NOT NULL DEFAULT 0,
			drug_received INT NOT NULL DEFAULT 0,
			drug_approved INT NOT NULL DEFAULT 0,
			drug_forwarded INT NOT NULL DEFAULT 0,
			drug_acted INT NOT NULL DEFAULT 0,
			published_at DATETIME NULL,
			admin_note TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY period (period_year, period_month),
			KEY published_at (published_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_partners
	 * --------------------------------------------------------------
	 *
	 * Vetted partner organizations that may receive forwarded drug reports.
	 * In Phase 1 this table is created but not populated. Partner onboarding
	 * is deferred to Phase 10.
	 */
	private static function create_partners( $charset_collate ) {
		$table = self::table_partners();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug VARCHAR(60) NOT NULL DEFAULT '',
			name VARCHAR(120) NOT NULL,
			wp_user_id BIGINT UNSIGNED NOT NULL,
			contact_email VARCHAR(190) NULL,
			contact_gpg_fingerprint VARCHAR(64) NULL,
			onboarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			last_login DATETIME NULL,
			active TINYINT(1) NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY wp_user_id (wp_user_id),
			UNIQUE KEY slug (slug),
			KEY active (active)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_partner_forwards
	 * --------------------------------------------------------------
	 *
	 * Junction table tracking each (partner, drug_report) pair that has
	 * been forwarded. Partners see only rows in this table scoped to
	 * their partner_id. Moderators can see every row.
	 *
	 * States:
	 *   forwarded_at    - set at insert (the moment HNC_Drug_Forward fires)
	 *   acknowledged_at - partner clicked "I have seen this" in their dashboard
	 *   acted_at        - partner marked the case as "acted on" (took action)
	 *   closed_at       - partner marked the case as closed (no further work)
	 *
	 * A single drug report can have multiple forward rows (one per partner
	 * it was forwarded to). This is intentional: a case can engage both a
	 * health partner and a legal liaison simultaneously.
	 */
	private static function create_partner_forwards( $charset_collate ) {
		$table = self::table_partner_forwards();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			partner_id BIGINT UNSIGNED NOT NULL,
			report_id BIGINT UNSIGNED NOT NULL,
			forwarded_by_user_id BIGINT UNSIGNED NULL,
			forwarded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			acknowledged_at DATETIME NULL,
			acted_at DATETIME NULL,
			closed_at DATETIME NULL,
			partner_note TEXT NULL,
			moderator_note TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY partner_report (partner_id, report_id),
			KEY partner_id (partner_id),
			KEY report_id (report_id),
			KEY forwarded_at (forwarded_at),
			KEY acknowledged_at (acknowledged_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_donations
	 * --------------------------------------------------------------
	 *
	 * One row per donation, owned by HNC_Payment. Covers both one-time
	 * and recurring (subscription) donations through Razorpay.
	 *
	 * Status machine (see HNC_Payment::STATUS_* constants):
	 *   created -> authorized -> captured                    (one-time success)
	 *   created -> failed                                    (one-time failure)
	 *   created -> authenticated -> active -> charged x N    (subscription)
	 *   active  -> halted | paused | cancelled | completed   (sub state changes)
	 *   captured -> partially_refunded -> refunded           (refund flow)
	 *
	 * Money is stored exclusively as paise integers — never as floats.
	 * amount_paise is the per-charge amount; amount_paid_paise accumulates
	 * across all successful charges (relevant for subscriptions).
	 *
	 * receipt_no is reserved at the moment of first successful capture only,
	 * never on creation, to avoid gaps in the fiscal-year sequence required
	 * for 80G compliance.
	 *
	 * Donor PII (name, email, phone) is nullable so the daily PII-purge cron
	 * can null these fields after the configured retention period (default
	 * 3 years). pii_purged_at stamps when the purge happened.
	 */
	private static function create_donations( $charset_collate ) {
		$table = self::table_donations();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			public_code VARCHAR(20) NOT NULL,
			receipt_no VARCHAR(40) NULL,
			provider VARCHAR(20) NOT NULL DEFAULT 'razorpay',
			type VARCHAR(20) NOT NULL,
			frequency VARCHAR(20) NOT NULL,
			status VARCHAR(30) NOT NULL DEFAULT 'created',
			amount_paise BIGINT UNSIGNED NOT NULL,
			currency VARCHAR(3) NOT NULL DEFAULT 'INR',
			amount_paid_paise BIGINT UNSIGNED NOT NULL DEFAULT 0,
			amount_refunded_paise BIGINT UNSIGNED NOT NULL DEFAULT 0,
			charge_count INT UNSIGNED NOT NULL DEFAULT 0,
			provider_order_id VARCHAR(60) NULL,
			provider_payment_id VARCHAR(60) NULL,
			provider_subscription_id VARCHAR(60) NULL,
			provider_plan_id VARCHAR(60) NULL,
			provider_customer_id VARCHAR(60) NULL,
			customer_id BIGINT UNSIGNED NULL,
			donor_name VARCHAR(120) NULL,
			donor_email VARCHAR(190) NULL,
			donor_email_hash CHAR(64) NULL,
			donor_phone_e164 VARCHAR(20) NULL,
			donor_anonymous TINYINT(1) NOT NULL DEFAULT 0,
			ip_hash CHAR(64) NULL,
			user_agent VARCHAR(255) NULL,
			idempotency_key VARCHAR(80) NULL,
			notes TEXT NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			captured_at DATETIME NULL,
			cancelled_at DATETIME NULL,
			pii_purged_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY public_code (public_code),
			UNIQUE KEY receipt_no (receipt_no),
			UNIQUE KEY provider_order_id (provider_order_id),
			UNIQUE KEY provider_subscription_id (provider_subscription_id),
			UNIQUE KEY idempotency_key (idempotency_key),
			KEY status_created (status, created_at),
			KEY type_status (type, status),
			KEY frequency (frequency),
			KEY donor_email_hash (donor_email_hash),
			KEY customer_id (customer_id),
			KEY provider_payment_id (provider_payment_id),
			KEY provider_customer_id (provider_customer_id),
			KEY pii_purged_at (pii_purged_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_payment_events
	 * --------------------------------------------------------------
	 *
	 * Append-only event ledger for every webhook delivery and every
	 * reconciliation tick. One row per inbound Razorpay event.
	 *
	 * The UNIQUE KEY on (provider, provider_event_id) is the primary
	 * dedup mechanism — Razorpay retries webhooks up to ~6 times if our
	 * 200 is delayed, and this constraint ensures we never double-process.
	 *
	 * Bad-signature events are recorded too (with signature_ok = 0) for
	 * forensic value, then the request is rejected with 401. Reconciliation
	 * synthesises events with deterministic IDs like "reconcile_<order_id>"
	 * so the same dedup applies.
	 *
	 * outcome captures the dispatch result: processed, skipped, sig_fail,
	 * error, duplicate, or unhandled. Inspect outcome_detail for context.
	 */
	private static function create_payment_events( $charset_collate ) {
		$table = self::table_payment_events();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			donation_id BIGINT UNSIGNED NULL,
			provider VARCHAR(20) NOT NULL DEFAULT 'razorpay',
			provider_event_id VARCHAR(80) NOT NULL,
			event_type VARCHAR(60) NOT NULL,
			provider_object_type VARCHAR(20) NULL,
			provider_object_id VARCHAR(60) NULL,
			signature_ok TINYINT(1) NOT NULL DEFAULT 0,
			ip_hash CHAR(64) NULL,
			received_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			processed_at DATETIME NULL,
			outcome VARCHAR(30) NULL,
			outcome_detail TEXT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY provider_event_id (provider, provider_event_id),
			KEY donation_id (donation_id),
			KEY event_type (event_type),
			KEY provider_object (provider_object_type, provider_object_id),
			KEY received_at (received_at)
		) {$charset_collate};";
	}


	/* --------------------------------------------------------------
	 * TABLE: hnc_payment_customers
	 * --------------------------------------------------------------
	 *
	 * Donor cache, deduped on email_hash (SHA-256 of normalised email).
	 * One row per donor; Razorpay customer_id is reused across donations
	 * so we skip the customer-create round-trip on repeat donors.
	 *
	 * email + name + phone_e164 are PII (nullable for purge). email_hash
	 * is the durable key — it survives PII purge so refund/audit lookups
	 * remain possible even after personally-identifying fields are nulled.
	 *
	 * total_donated_paise and donation_count are operator-visible counters
	 * (populated by HNC_Payment downstream listeners; not maintained by
	 * the schema itself).
	 */
	private static function create_payment_customers( $charset_collate ) {
		$table = self::table_payment_customers();
		return "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			provider VARCHAR(20) NOT NULL DEFAULT 'razorpay',
			provider_customer_id VARCHAR(60) NOT NULL,
			email VARCHAR(190) NULL,
			email_hash CHAR(64) NOT NULL,
			name VARCHAR(120) NULL,
			phone_e164 VARCHAR(20) NULL,
			total_donated_paise BIGINT UNSIGNED NOT NULL DEFAULT 0,
			donation_count INT UNSIGNED NOT NULL DEFAULT 0,
			first_donated_at DATETIME NULL,
			last_donated_at DATETIME NULL,
			created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			pii_purged_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY provider_customer (provider, provider_customer_id),
			UNIQUE KEY email_hash (email_hash),
			KEY last_donated_at (last_donated_at)
		) {$charset_collate};";
	}
}