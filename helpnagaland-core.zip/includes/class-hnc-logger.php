<?php
/**
 * Audit logger.
 *
 * Writes immutable entries to the hnc_audit_log table. Every admin action,
 * partner action, and sensitive system event MUST produce a log entry.
 * Logging is the only way to:
 *
 *   - Reconstruct what happened when an incident occurs
 *   - Prove moderation decisions were made deliberately in court
 *   - Monitor for abuse by admins themselves
 *   - Demonstrate compliance with data protection obligations
 *
 * Design rules:
 *
 *   - Logging must NEVER throw. If logging fails, the primary action
 *     still completes. We prefer a missing log entry over a blocked user action.
 *   - Log entries are append only. The admin UI does not expose a delete
 *     button. There is no update_entry() method here either.
 *   - IP addresses are stored as a SHA-256 hash using the daily rotating
 *     salt from options. Raw IPs are NEVER written.
 *   - The detail field holds a JSON blob. Keep it small. Do not log full
 *     report bodies or phone numbers, only identifiers and metadata.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Logger
 */
final class HNC_Logger {


	/* ------------------------------------------------------------------
	 * EVENT TYPE CONSTANTS
	 * ------------------------------------------------------------------
	 *
	 * Event types group related actions. Use the constants below when
	 * calling log() so that queries and filters stay consistent across
	 * the codebase. Do NOT invent new event types in ad hoc strings.
	 */

	const EVENT_ALCOHOL      = 'alcohol';        // Anything touching alcohol reports.
	const EVENT_DRUG         = 'drug';           // Anything touching drug reports.
	const EVENT_PHONE_VAULT  = 'phone_vault';    // Vault unlock, phone reveal, deletion.
	const EVENT_PARTNER      = 'partner';        // Partner onboarding, access, forwards.
	const EVENT_TRANSPARENCY = 'transparency';   // Snapshot publication, edits.
	const EVENT_SETTINGS     = 'settings';       // Plugin settings changes.
	const EVENT_ROLE         = 'role';           // Role assignment changes.
	const EVENT_KILLSWITCH   = 'killswitch';     // Killswitch toggle.
	const EVENT_SYSTEM       = 'system';         // Cron, retention sweeps, upgrades.
	const EVENT_SECURITY     = 'security';       // Rate limit hits, abuse detection.
	const EVENT_AUTH         = 'auth';           // Login, logout, failed login.


	/* ------------------------------------------------------------------
	 * ACTION CONSTANTS
	 * ------------------------------------------------------------------
	 *
	 * Actions describe exactly what happened within an event type.
	 * Combined with event_type they form the unique signature of an event.
	 */

	// Moderation actions (used with EVENT_ALCOHOL or EVENT_DRUG)
	const ACTION_SUBMIT     = 'submit';
	const ACTION_APPROVE    = 'approve';
	const ACTION_REJECT     = 'reject';
	const ACTION_HOLD       = 'hold';
	const ACTION_UNHOLD     = 'unhold';
	const ACTION_MERGE      = 'merge';
	const ACTION_UNMERGE    = 'unmerge';
	const ACTION_ARCHIVE    = 'archive';
	const ACTION_UNARCHIVE  = 'unarchive';
	const ACTION_RESOLVE    = 'resolve';
	const ACTION_FORWARD    = 'forward';

	// Phone vault actions
	const ACTION_VAULT_UNLOCK      = 'vault_unlock';
	const ACTION_VAULT_LOCK        = 'vault_lock';
	const ACTION_VAULT_FAIL        = 'vault_unlock_failed';
	const ACTION_VAULT_STORE       = 'vault_store';
	const ACTION_PHONE_REVEAL      = 'phone_reveal';
	const ACTION_PHONE_DELETE      = 'phone_delete';
	const ACTION_VAULT_PASSPHRASE  = 'vault_passphrase_set';

	// Settings and config
	const ACTION_SETTING_UPDATE = 'setting_update';
	const ACTION_KILLSWITCH_ON  = 'killswitch_on';
	const ACTION_KILLSWITCH_OFF = 'killswitch_off';

	// Retention
	const ACTION_PHOTO_PURGE   = 'photo_purge';
	const ACTION_REPORT_PURGE  = 'report_purge';
	const ACTION_RETENTION_RUN = 'retention_run';

	// Moderator read-only views of sensitive content
	const ACTION_MEDIA_VIEW    = 'media_view';

	// System
	const ACTION_ACTIVATE   = 'activate';
	const ACTION_DEACTIVATE = 'deactivate';
	const ACTION_UPGRADE    = 'upgrade';
	const ACTION_SCHEMA_RUN = 'schema_run';
	const ACTION_CRON_RUN   = 'cron_run';

	// Security
	const ACTION_RATE_LIMIT = 'rate_limit_hit';
	const ACTION_DEVICE_FLAG = 'device_flag';
	const ACTION_SIGNATURE_FAIL = 'signature_fail';


	/* ------------------------------------------------------------------
	 * CORE LOG METHOD
	 * ------------------------------------------------------------------ */

	/**
	 * Write a log entry.
	 *
	 * Never throws. Returns the inserted row ID on success, or 0 on failure.
	 *
	 * @param string   $event_type  One of the EVENT_* constants.
	 * @param string   $action      One of the ACTION_* constants.
	 * @param array    $args        Optional associative array of additional context:
	 *                              - actor_id     (int)    WP user ID performing the action.
	 *                              - report_type  (string) 'alcohol', 'drug', 'phone', 'partner', 'system'.
	 *                              - report_id    (int)    Related report row ID.
	 *                              - detail       (array)  JSON serializable details.
	 *                              - ip           (string) Raw IP. Will be hashed.
	 * @return int Inserted row ID, or 0 on failure.
	 */
	public static function log( $event_type, $action, $args = array() ) {

		// Never let logger exceptions bubble up. The calling code must be
		// able to trust that logging failure never blocks the user action.
		try {

			global $wpdb;

			if ( ! class_exists( 'HNC_Schema' ) ) {
				return 0;
			}

			$table = HNC_Schema::table_audit_log();

			$defaults = array(
				'actor_id'    => 0,
				'report_type' => null,
				'report_id'   => null,
				'detail'      => null,
				'ip'          => null,
			);
			$args     = array_merge( $defaults, $args );

			// Default actor to current WP user if not specified.
			if ( empty( $args['actor_id'] ) ) {
				$current = function_exists( 'get_current_user_id' ) ? get_current_user_id() : 0;
				if ( $current ) {
					$args['actor_id'] = (int) $current;
				}
			}

			// Hash the IP if provided. If not provided, attempt to read from
			// the server globals using a helper that respects trusted proxies.
			$ip_hash = null;
			$raw_ip  = $args['ip'];
			if ( $raw_ip === null && isset( $_SERVER['REMOTE_ADDR'] ) ) {
				$raw_ip = self::client_ip();
			}
			if ( ! empty( $raw_ip ) ) {
				$ip_hash = self::hash_ip( $raw_ip );
			}

			// JSON encode detail safely. If encoding fails, drop the detail.
			$detail_json = null;
			if ( ! empty( $args['detail'] ) ) {
				$encoded = wp_json_encode( $args['detail'] );
				if ( is_string( $encoded ) ) {
					// Hard limit to keep audit log rows compact.
					$detail_json = substr( $encoded, 0, 65000 );
				}
			}

			$data = array(
				'event_type'  => self::truncate( $event_type, 40 ),
				'actor_id'    => $args['actor_id'] ? (int) $args['actor_id'] : null,
				'report_type' => $args['report_type'] ? self::truncate( $args['report_type'], 20 ) : null,
				'report_id'   => $args['report_id'] ? (int) $args['report_id'] : null,
				'action'      => self::truncate( $action, 40 ),
				'detail'      => $detail_json,
				'ip_hash'     => $ip_hash,
				'created_at'  => current_time( 'mysql' ),
			);

			$formats = array(
				'%s',  // event_type
				'%d',  // actor_id (nullable, but wpdb handles null values in format arrays via $data value being NULL)
				'%s',  // report_type
				'%d',  // report_id
				'%s',  // action
				'%s',  // detail
				'%s',  // ip_hash
				'%s',  // created_at
			);

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$inserted = $wpdb->insert( $table, $data, $formats );

			if ( false === $inserted ) {
				return 0;
			}

			return (int) $wpdb->insert_id;

		} catch ( Throwable $t ) {
			// Last resort: log to PHP error log so we have a breadcrumb.
			// Do NOT surface the exception to the caller.
			if ( function_exists( 'error_log' ) ) {
				error_log( 'HNC_Logger::log failed: ' . $t->getMessage() );
			}
			return 0;
		}
	}


	/* ------------------------------------------------------------------
	 * CONVENIENCE WRAPPERS
	 * ------------------------------------------------------------------
	 *
	 * These shortcuts make call sites more readable and searchable. Prefer
	 * these over direct log() calls when the situation fits.
	 */

	/**
	 * Log an alcohol moderation action.
	 *
	 * @param string $action    ACTION_* constant.
	 * @param int    $report_id hnc_alcohol_reports.id.
	 * @param array  $detail    Optional extra detail.
	 * @return int
	 */
	public static function log_alcohol( $action, $report_id, $detail = array() ) {
		return self::log(
			self::EVENT_ALCOHOL,
			$action,
			array(
				'report_type' => 'alcohol',
				'report_id'   => $report_id,
				'detail'      => $detail,
			)
		);
	}

	/**
	 * Log a drug moderation action.
	 *
	 * @param string $action    ACTION_* constant.
	 * @param int    $report_id hnc_drug_reports.id.
	 * @param array  $detail    Optional extra detail.
	 * @return int
	 */
	public static function log_drug( $action, $report_id, $detail = array() ) {
		return self::log(
			self::EVENT_DRUG,
			$action,
			array(
				'report_type' => 'drug',
				'report_id'   => $report_id,
				'detail'      => $detail,
			)
		);
	}

	/**
	 * Log a phone vault event.
	 *
	 * @param string $action  ACTION_* constant.
	 * @param int    $vault_id hnc_phone_vault.id (optional).
	 * @param array  $detail  Optional extra detail.
	 * @return int
	 */
	public static function log_vault( $action, $vault_id = 0, $detail = array() ) {
		return self::log(
			self::EVENT_PHONE_VAULT,
			$action,
			array(
				'report_type' => 'phone',
				'report_id'   => $vault_id ? $vault_id : null,
				'detail'      => $detail,
			)
		);
	}

	/**
	 * Log a settings change.
	 *
	 * @param string $setting_key The option key that was changed.
	 * @param mixed  $old_value   Previous value (can be redacted for sensitive options).
	 * @param mixed  $new_value   New value (can be redacted).
	 * @return int
	 */
	public static function log_setting_update( $setting_key, $old_value = null, $new_value = null ) {
		return self::log(
			self::EVENT_SETTINGS,
			self::ACTION_SETTING_UPDATE,
			array(
				'report_type' => 'system',
				'detail'      => array(
					'key' => (string) $setting_key,
					'old' => self::redact_if_sensitive( $setting_key, $old_value ),
					'new' => self::redact_if_sensitive( $setting_key, $new_value ),
				),
			)
		);
	}

	/**
	 * Log a system event (cron, retention, upgrade).
	 *
	 * @param string $action ACTION_* constant.
	 * @param array  $detail Optional extra detail.
	 * @return int
	 */
	public static function log_system( $action, $detail = array() ) {
		return self::log(
			self::EVENT_SYSTEM,
			$action,
			array(
				'report_type' => 'system',
				'actor_id'    => 0,
				'detail'      => $detail,
			)
		);
	}

	/**
	 * Log a security event (rate limit, device flag, signature failure).
	 *
	 * @param string $action ACTION_* constant.
	 * @param array  $detail Optional extra detail.
	 * @return int
	 */
	public static function log_security( $action, $detail = array() ) {
		return self::log(
			self::EVENT_SECURITY,
			$action,
			array(
				'report_type' => 'system',
				'detail'      => $detail,
			)
		);
	}


	/* ------------------------------------------------------------------
	 * QUERIES
	 * ------------------------------------------------------------------ */

	/**
	 * Fetch recent log entries, newest first. Used by the admin audit screen.
	 *
	 * @param array $filters Accepted filters:
	 *                       - event_type (string)
	 *                       - actor_id   (int)
	 *                       - action     (string)
	 *                       - report_type (string)
	 *                       - report_id  (int)
	 *                       - since      (string Y-m-d H:i:s)
	 *                       - until      (string Y-m-d H:i:s)
	 *                       - limit      (int, default 50, max 500)
	 *                       - offset     (int, default 0)
	 * @return array Array of row objects.
	 */
	public static function query( $filters = array() ) {
		global $wpdb;

		if ( ! class_exists( 'HNC_Schema' ) ) {
			return array();
		}

		$table = HNC_Schema::table_audit_log();

		$where   = array( '1=1' );
		$prepare = array();

		if ( ! empty( $filters['event_type'] ) ) {
			$where[]   = 'event_type = %s';
			$prepare[] = $filters['event_type'];
		}
		if ( ! empty( $filters['actor_id'] ) ) {
			$where[]   = 'actor_id = %d';
			$prepare[] = (int) $filters['actor_id'];
		}
		if ( ! empty( $filters['action'] ) ) {
			$where[]   = 'action = %s';
			$prepare[] = $filters['action'];
		}
		if ( ! empty( $filters['report_type'] ) ) {
			$where[]   = 'report_type = %s';
			$prepare[] = $filters['report_type'];
		}
		if ( ! empty( $filters['report_id'] ) ) {
			$where[]   = 'report_id = %d';
			$prepare[] = (int) $filters['report_id'];
		}
		if ( ! empty( $filters['since'] ) ) {
			$where[]   = 'created_at >= %s';
			$prepare[] = $filters['since'];
		}
		if ( ! empty( $filters['until'] ) ) {
			$where[]   = 'created_at <= %s';
			$prepare[] = $filters['until'];
		}

		$limit  = isset( $filters['limit'] ) ? max( 1, min( 500, (int) $filters['limit'] ) ) : 50;
		$offset = isset( $filters['offset'] ) ? max( 0, (int) $filters['offset'] ) : 0;

		$where_sql = implode( ' AND ', $where );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";

		$prepare[] = $limit;
		$prepare[] = $offset;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$prepared = $wpdb->prepare( $sql, $prepare );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $prepared );

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Count log entries matching filters. Same filter shape as query().
	 *
	 * @param array $filters Filters.
	 * @return int
	 */
	public static function count( $filters = array() ) {
		global $wpdb;

		if ( ! class_exists( 'HNC_Schema' ) ) {
			return 0;
		}

		$table = HNC_Schema::table_audit_log();

		$where   = array( '1=1' );
		$prepare = array();

		foreach ( array( 'event_type', 'action', 'report_type' ) as $f ) {
			if ( ! empty( $filters[ $f ] ) ) {
				$where[]   = "{$f} = %s";
				$prepare[] = $filters[ $f ];
			}
		}
		foreach ( array( 'actor_id', 'report_id' ) as $f ) {
			if ( ! empty( $filters[ $f ] ) ) {
				$where[]   = "{$f} = %d";
				$prepare[] = (int) $filters[ $f ];
			}
		}
		if ( ! empty( $filters['since'] ) ) {
			$where[]   = 'created_at >= %s';
			$prepare[] = $filters['since'];
		}
		if ( ! empty( $filters['until'] ) ) {
			$where[]   = 'created_at <= %s';
			$prepare[] = $filters['until'];
		}

		$where_sql = implode( ' AND ', $where );
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";

		if ( empty( $prepare ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
			return (int) $wpdb->get_var( $sql );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$prepared = $wpdb->prepare( $sql, $prepare );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $prepared );
	}


	/* ------------------------------------------------------------------
	 * IP HASHING
	 * ------------------------------------------------------------------ */

	/**
	 * Return the best-guess client IP. Tries a small set of trusted headers
	 * then falls back to REMOTE_ADDR.
	 *
	 * @return string
	 */
	public static function client_ip() {
		// REMOTE_ADDR is usually the safest choice. Proxy headers can be spoofed
		// unless the site is configured with a trusted reverse proxy. We default
		// to REMOTE_ADDR and expose filters for advanced setups.
		$candidate = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		$candidate = apply_filters( 'hnc_client_ip', $candidate );
		return is_string( $candidate ) ? $candidate : '';
	}

	/**
	 * Hash an IP address with the current daily salt. Returns 64 char hex.
	 *
	 * @param string $ip Raw IP address.
	 * @return string SHA-256 hex.
	 */
	public static function hash_ip( $ip ) {
		$salt = (string) get_option( 'hnc_ip_daily_salt', '' );
		if ( '' === $salt ) {
			// Should not happen after activation, but defensive.
			$salt = 'fallback';
		}
		return hash( 'sha256', $salt . '|' . $ip );
	}


	/* ------------------------------------------------------------------
	 * INTERNAL HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Truncate a string to a max byte length without breaking UTF-8.
	 *
	 * @param mixed $value Input, casted to string.
	 * @param int   $max   Max byte length.
	 * @return string
	 */
	private static function truncate( $value, $max ) {
		$s = (string) $value;
		if ( strlen( $s ) <= $max ) {
			return $s;
		}
		if ( function_exists( 'mb_strcut' ) ) {
			return mb_strcut( $s, 0, $max, 'UTF-8' );
		}
		return substr( $s, 0, $max );
	}

	/**
	 * Redact values for sensitive option keys so secrets never appear in the log.
	 *
	 * @param string $key   Option key.
	 * @param mixed  $value Value.
	 * @return mixed
	 */
	private static function redact_if_sensitive( $key, $value ) {
		$sensitive = array(
			'hnc_ip_daily_salt',
			'hnc_device_hash_salt',
			'hnc_vault_passphrase_hash',
		);
		if ( in_array( $key, $sensitive, true ) ) {
			return '[REDACTED]';
		}
		return $value;
	}
}
