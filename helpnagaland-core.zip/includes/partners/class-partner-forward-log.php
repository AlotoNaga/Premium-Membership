<?php
/**
 * Partner Forward Log: tracks which drug reports have been forwarded to
 * which partners, and what those partners have done with them.
 *
 * This class is the bridge between HNC_Drug_Forward (which fires the
 * forward event) and the partner dashboard (which reads the queue).
 *
 * Hooks:
 *   - hnc_drug_forwarded (from HNC_Drug_Forward::forward): creates a
 *     junction row linking the drug report to the partner. Safe to
 *     ignore if the partner slug does not resolve to an active record.
 *
 * Partner-facing methods (used by HNC_Api_Partner and the dashboard):
 *   - list_for_partner( wp_user_id, filters )
 *   - get_for_partner( wp_user_id, forward_id )
 *   - acknowledge( wp_user_id, forward_id, note )
 *   - mark_acted( wp_user_id, forward_id, note )
 *   - mark_closed( wp_user_id, forward_id, note )
 *
 * All partner-facing methods scope by partner_id derived from the
 * wp_user_id. A partner CANNOT see another partner's forwards, ever.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Partner_Forward_Log
 */
final class HNC_Partner_Forward_Log {


	const ERR_UNAUTHORIZED    = 'hnc_unauthorized';
	const ERR_NOT_FOUND       = 'hnc_forward_not_found';
	const ERR_NOT_ACTIVE      = 'hnc_partner_not_active';
	const ERR_BAD_STATE       = 'hnc_forward_bad_state';
	const ERR_DB              = 'hnc_forward_db_error';


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Wire the action hook that HNC_Drug_Forward fires.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'hnc_drug_forwarded', array( __CLASS__, 'on_drug_forwarded' ), 10, 3 );
		add_action( 'wp_login', array( 'HNC_Partner_Model', 'touch_last_login' ), 10, 2 );
	}


	/* ------------------------------------------------------------------
	 * HANDLER: hnc_drug_forwarded
	 * ------------------------------------------------------------------ */

	/**
	 * When a moderator forwards a drug report, file a junction row so
	 * the partner can see it in their dashboard. If the partner slug
	 * cannot be resolved (partner not onboarded yet, or inactive), log
	 * the mismatch but do not break the forward — moderators may be
	 * forwarding to a label that hasn't been formally onboarded.
	 *
	 * @param int    $report_id          Drug report ID.
	 * @param string $partner_identifier Slug or numeric ID used in the UI.
	 * @param string $note               Moderator's note to the partner.
	 * @return int|null Junction row ID on success, null on silent skip.
	 */
	public static function on_drug_forwarded( $report_id, $partner_identifier, $note = '' ) {
		$partner = HNC_Partner_Model::resolve( (string) $partner_identifier );
		if ( null === $partner ) {
			// No matching partner record. Log, but do not error.
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_system(
					'partner_forward_unmatched',
					array(
						'report_id'  => (int) $report_id,
						'identifier' => (string) $partner_identifier,
					)
				);
			}
			return null;
		}

		if ( (int) $partner->active !== 1 ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_system(
					'partner_forward_inactive',
					array(
						'report_id'  => (int) $report_id,
						'partner_id' => (int) $partner->id,
					)
				);
			}
			return null;
		}

		global $wpdb;
		$table = HNC_Schema::table_partner_forwards();

		// If this (partner, report) pair already exists, update the
		// moderator_note and forwarded_at timestamp but keep the acknowledge
		// state. A moderator forwarding the same case twice shouldn't wipe
		// the partner's prior acknowledgment.
		$existing = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id FROM {$table} WHERE partner_id = %d AND report_id = %d LIMIT 1",
				(int) $partner->id,
				(int) $report_id
			)
		);

		$clean_note = class_exists( 'HNC_Sanitizer' )
			? HNC_Sanitizer::admin_note( $note )
			: substr( (string) $note, 0, 1500 );

		$forwarded_by = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;

		if ( $existing ) {
			$wpdb->update(
				$table,
				array(
					'forwarded_at'         => current_time( 'mysql' ),
					'forwarded_by_user_id' => $forwarded_by > 0 ? $forwarded_by : null,
					'moderator_note'       => $clean_note,
				),
				array( 'id' => (int) $existing->id ),
				array( '%s', '%d', '%s' ),
				array( '%d' )
			);
			return (int) $existing->id;
		}

		$ok = $wpdb->insert(
			$table,
			array(
				'partner_id'           => (int) $partner->id,
				'report_id'            => (int) $report_id,
				'forwarded_by_user_id' => $forwarded_by > 0 ? $forwarded_by : null,
				'forwarded_at'         => current_time( 'mysql' ),
				'moderator_note'       => $clean_note,
			),
			array( '%d', '%d', '%d', '%s', '%s' )
		);
		if ( ! $ok ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_system(
					'partner_forward_insert_failed',
					array(
						'partner_id' => (int) $partner->id,
						'report_id'  => (int) $report_id,
						'db_error'   => $wpdb->last_error,
					)
				);
			}
			return null;
		}

		return (int) $wpdb->insert_id;
	}


	/* ------------------------------------------------------------------
	 * PARTNER QUERIES
	 * ------------------------------------------------------------------ */

	/**
	 * Return the list of forwarded cases scoped to the partner owning
	 * $wp_user_id. Partners never see each other's queues.
	 *
	 * Filters:
	 *   - state: 'all' | 'unseen' | 'open' | 'acted' | 'closed'
	 *   - page, per_page
	 *
	 * @param int   $wp_user_id Current WP user.
	 * @param array $filters    Filters.
	 * @return array|WP_Error { rows, total, partner_id }
	 */
	public static function list_for_partner( $wp_user_id, $filters = array() ) {
		$partner = HNC_Partner_Model::get_by_wp_user( (int) $wp_user_id );
		if ( null === $partner ) {
			return new WP_Error( self::ERR_UNAUTHORIZED, __( 'You are not an onboarded partner.', 'helpnagaland-core' ) );
		}
		if ( (int) $partner->active !== 1 ) {
			return new WP_Error( self::ERR_NOT_ACTIVE, __( 'Your partner access has been deactivated.', 'helpnagaland-core' ) );
		}

		$state    = isset( $filters['state'] ) ? (string) $filters['state'] : 'all';
		$page     = isset( $filters['page'] ) ? max( 1, (int) $filters['page'] ) : 1;
		$per_page = isset( $filters['per_page'] ) ? max( 1, min( 100, (int) $filters['per_page'] ) ) : 20;

		global $wpdb;
		$table = HNC_Schema::table_partner_forwards();

		$where = array( 'partner_id = %d' );
		$args  = array( (int) $partner->id );

		switch ( $state ) {
			case 'unseen':
				$where[] = 'acknowledged_at IS NULL';
				break;
			case 'open':
				$where[] = 'acknowledged_at IS NOT NULL';
				$where[] = 'closed_at IS NULL';
				break;
			case 'acted':
				$where[] = 'acted_at IS NOT NULL';
				$where[] = 'closed_at IS NULL';
				break;
			case 'closed':
				$where[] = 'closed_at IS NOT NULL';
				break;
			case 'all':
			default:
				break;
		}

		$where_sql = implode( ' AND ', $where );

		$total_sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM {$table} WHERE {$where_sql}",
			$args
		);
		$total = (int) $wpdb->get_var( $total_sql );

		$offset = ( $page - 1 ) * $per_page;
		$list_sql = $wpdb->prepare(
			"SELECT * FROM {$table} WHERE {$where_sql} ORDER BY forwarded_at DESC LIMIT %d OFFSET %d",
			array_merge( $args, array( $per_page, $offset ) )
		);
		$rows = $wpdb->get_results( $list_sql );
		if ( ! is_array( $rows ) ) {
			$rows = array();
		}

		// Hydrate each row with a narrow view of the drug report (no phone,
		// no vehicle, no media URL). Full details come from get_for_partner.
		$report_table = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
		$hydrated     = array();
		foreach ( $rows as $r ) {
			$rep = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, public_code, district, category, submitted_at, status, severity_flag FROM {$report_table} WHERE id = %d LIMIT 1",
					(int) $r->report_id
				)
			);
			$hydrated[] = array(
				'forward_id'      => (int) $r->id,
				'report_id'       => (int) $r->report_id,
				'forwarded_at'    => (string) $r->forwarded_at,
				'acknowledged_at' => isset( $r->acknowledged_at ) && $r->acknowledged_at ? (string) $r->acknowledged_at : null,
				'acted_at'        => isset( $r->acted_at ) && $r->acted_at ? (string) $r->acted_at : null,
				'closed_at'       => isset( $r->closed_at ) && $r->closed_at ? (string) $r->closed_at : null,
				'report'          => $rep ? array(
					'public_code'   => (string) $rep->public_code,
					'district'      => (string) $rep->district,
					'category'      => (string) $rep->category,
					'submitted_at'  => (string) $rep->submitted_at,
					'status'        => (string) $rep->status,
					'severity_flag' => is_null( $rep->severity_flag ) ? null : (int) $rep->severity_flag,
				) : null,
			);
		}

		return array(
			'rows'       => $hydrated,
			'total'      => $total,
			'page'       => $page,
			'per_page'   => $per_page,
			'partner_id' => (int) $partner->id,
		);
	}

	/**
	 * Fetch a single forwarded case with the full drug-report context
	 * the partner is allowed to see.
	 *
	 * Included for partner view:
	 *   - All drug report fields EXCEPT device_hash
	 *   - Moderator's note from the forward event
	 *   - Whether a phone is available (boolean only; reveal requires a
	 *     separate call that goes through the vault)
	 *
	 * Excluded from partner view:
	 *   - The decrypted phone number itself (vault reveal is not partner-accessible)
	 *   - Any fields from other pipelines
	 *   - Other partners' forward activity
	 *
	 * @param int $wp_user_id Current WP user.
	 * @param int $forward_id Junction row ID.
	 * @return array|WP_Error
	 */
	public static function get_for_partner( $wp_user_id, $forward_id ) {
		$partner = HNC_Partner_Model::get_by_wp_user( (int) $wp_user_id );
		if ( null === $partner ) {
			return new WP_Error( self::ERR_UNAUTHORIZED, __( 'You are not an onboarded partner.', 'helpnagaland-core' ) );
		}
		if ( (int) $partner->active !== 1 ) {
			return new WP_Error( self::ERR_NOT_ACTIVE, __( 'Your partner access has been deactivated.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$table = HNC_Schema::table_partner_forwards();
		$fwd   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE id = %d AND partner_id = %d LIMIT 1",
				(int) $forward_id,
				(int) $partner->id
			)
		);
		if ( ! $fwd ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Forwarded case not found.', 'helpnagaland-core' ) );
		}

		$report_table = $wpdb->prefix . HNC_TABLE_PREFIX . 'drug_reports';
		$rep = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, public_code, district, area_desc, category, pattern, vehicle_info, submission_mode, phone_vault_id, status, severity_flag, submitted_at FROM {$report_table} WHERE id = %d LIMIT 1",
				(int) $fwd->report_id
			)
		);

		return array(
			'forward' => array(
				'id'              => (int) $fwd->id,
				'forwarded_at'    => (string) $fwd->forwarded_at,
				'acknowledged_at' => isset( $fwd->acknowledged_at ) && $fwd->acknowledged_at ? (string) $fwd->acknowledged_at : null,
				'acted_at'        => isset( $fwd->acted_at ) && $fwd->acted_at ? (string) $fwd->acted_at : null,
				'closed_at'       => isset( $fwd->closed_at ) && $fwd->closed_at ? (string) $fwd->closed_at : null,
				'moderator_note'  => isset( $fwd->moderator_note ) ? (string) $fwd->moderator_note : '',
				'partner_note'    => isset( $fwd->partner_note ) ? (string) $fwd->partner_note : '',
			),
			'report'  => $rep ? array(
				'id'              => (int) $rep->id,
				'public_code'     => (string) $rep->public_code,
				'district'        => (string) $rep->district,
				'area_desc'       => (string) $rep->area_desc,
				'category'        => (string) $rep->category,
				'pattern'         => (string) $rep->pattern,
				'vehicle_info'    => is_null( $rep->vehicle_info ) ? '' : (string) $rep->vehicle_info,
				'submission_mode' => (string) $rep->submission_mode,
				'phone_available' => ! empty( $rep->phone_vault_id ),
				'status'          => (string) $rep->status,
				'severity_flag'   => is_null( $rep->severity_flag ) ? null : (int) $rep->severity_flag,
				'submitted_at'    => (string) $rep->submitted_at,
			) : null,
		);
	}


	/* ------------------------------------------------------------------
	 * STATE TRANSITIONS
	 * ------------------------------------------------------------------ */

	/**
	 * Mark a forwarded case as acknowledged. First transition.
	 *
	 * @param int    $wp_user_id Partner's WP user.
	 * @param int    $forward_id Junction row.
	 * @param string $note       Optional partner note.
	 * @return true|WP_Error
	 */
	public static function acknowledge( $wp_user_id, $forward_id, $note = '' ) {
		return self::transition( $wp_user_id, $forward_id, 'acknowledged_at', 'acknowledge', $note );
	}

	/**
	 * Mark a forwarded case as acted on. Requires prior acknowledgment.
	 *
	 * @param int    $wp_user_id Partner's WP user.
	 * @param int    $forward_id Junction row.
	 * @param string $note       Optional partner note.
	 * @return true|WP_Error
	 */
	public static function mark_acted( $wp_user_id, $forward_id, $note = '' ) {
		return self::transition( $wp_user_id, $forward_id, 'acted_at', 'mark_acted', $note, true );
	}

	/**
	 * Mark a forwarded case as closed. Requires prior acknowledgment.
	 *
	 * @param int    $wp_user_id Partner's WP user.
	 * @param int    $forward_id Junction row.
	 * @param string $note       Optional partner note.
	 * @return true|WP_Error
	 */
	public static function mark_closed( $wp_user_id, $forward_id, $note = '' ) {
		return self::transition( $wp_user_id, $forward_id, 'closed_at', 'mark_closed', $note, true );
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Shared state transition writer. Used by acknowledge/mark_acted/mark_closed.
	 *
	 * @param int    $wp_user_id           Partner's WP user.
	 * @param int    $forward_id           Junction row ID.
	 * @param string $column               DB column to stamp now().
	 * @param string $action               Audit action label.
	 * @param string $note                 Partner note (appended).
	 * @param bool   $require_acknowledged Whether prior acknowledgment required.
	 * @return true|WP_Error
	 */
	private static function transition( $wp_user_id, $forward_id, $column, $action, $note, $require_acknowledged = false ) {
		$partner = HNC_Partner_Model::get_by_wp_user( (int) $wp_user_id );
		if ( null === $partner ) {
			return new WP_Error( self::ERR_UNAUTHORIZED, __( 'You are not an onboarded partner.', 'helpnagaland-core' ) );
		}
		if ( (int) $partner->active !== 1 ) {
			return new WP_Error( self::ERR_NOT_ACTIVE, __( 'Your partner access has been deactivated.', 'helpnagaland-core' ) );
		}

		global $wpdb;
		$table = HNC_Schema::table_partner_forwards();
		$fwd   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE id = %d AND partner_id = %d LIMIT 1",
				(int) $forward_id,
				(int) $partner->id
			)
		);
		if ( ! $fwd ) {
			return new WP_Error( self::ERR_NOT_FOUND, __( 'Forwarded case not found.', 'helpnagaland-core' ) );
		}

		if ( $require_acknowledged && ( ! isset( $fwd->acknowledged_at ) || empty( $fwd->acknowledged_at ) ) ) {
			return new WP_Error(
				self::ERR_BAD_STATE,
				__( 'Please acknowledge this case before marking it as acted or closed.', 'helpnagaland-core' )
			);
		}

		if ( isset( $fwd->{$column} ) && ! empty( $fwd->{$column} ) ) {
			// Idempotent: transitioning twice is a no-op, not an error.
			return true;
		}

		$clean_note = class_exists( 'HNC_Sanitizer' )
			? HNC_Sanitizer::admin_note( (string) $note )
			: substr( (string) $note, 0, 1500 );

		$existing_note = isset( $fwd->partner_note ) ? (string) $fwd->partner_note : '';
		$appended_note = '' === $existing_note
			? $clean_note
			: trim( $existing_note . "\n---\n" . $clean_note );

		$ok = $wpdb->update(
			$table,
			array(
				$column        => current_time( 'mysql' ),
				'partner_note' => $appended_note,
			),
			array( 'id' => (int) $fwd->id ),
			array( '%s', '%s' ),
			array( '%d' )
		);
		if ( false === $ok ) {
			return new WP_Error( self::ERR_DB, __( 'Database update failed.', 'helpnagaland-core' ) );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_drug(
				'partner_' . $action,
				(int) $fwd->report_id,
				array(
					'partner_id' => (int) $partner->id,
					'forward_id' => (int) $fwd->id,
					'note'       => $clean_note,
				)
			);
		}

		return true;
	}
}
