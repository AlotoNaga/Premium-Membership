<?php
/**
 * Vault Session: REST endpoints for unlocking and locking the phone vault.
 *
 * This class is the narrow REST gateway to HNC_Encryption's session-based
 * vault key. It provides three admin-only endpoints:
 *
 *   POST /hnc/v1/vault/set-passphrase    (only callable the first time)
 *   POST /hnc/v1/vault/unlock             (moderators unlock by passphrase)
 *   POST /hnc/v1/vault/lock               (moderators lock on demand)
 *   GET  /hnc/v1/vault/status             (report whether vault is unlocked)
 *
 * All endpoints require the hnc_manage_vault capability and a valid
 * WordPress REST nonce. The passphrase and unlock endpoints deliberately
 * do NOT disclose whether the passphrase is right-but-the-session-could-
 * not-be-opened vs wrong-passphrase. They return a single "unauthorized"
 * error for any failure path so timing and message content reveal nothing.
 *
 * These endpoints are separate from the regular moderation REST surface
 * (Phase 6) because they are the trust root for the rest of the system
 * and deserve a dedicated review surface.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Vault_Session
 */
final class HNC_Vault_Session {


	const ERR_UNAUTHORIZED  = 'hnc_unauthorized';
	const ERR_BAD_INPUT     = 'hnc_bad_input';
	const ERR_ALREADY_SET   = 'hnc_passphrase_already_set';
	const ERR_UNLOCK_FAILED = 'hnc_unlock_failed';


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Wire REST routes on plugins_loaded.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register vault session endpoints.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/vault/set-passphrase',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_set_passphrase' ),
				'permission_callback' => array( __CLASS__, 'require_vault_cap' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/vault/unlock',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_unlock' ),
				'permission_callback' => array( __CLASS__, 'require_vault_cap' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/vault/lock',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_lock' ),
				'permission_callback' => array( __CLASS__, 'require_vault_cap' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/vault/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_status' ),
				'permission_callback' => array( __CLASS__, 'require_vault_cap' ),
			)
		);
	}


	/* ------------------------------------------------------------------
	 * REST CALLBACKS
	 * ------------------------------------------------------------------ */

	/**
	 * POST /vault/set-passphrase. Only allowed when a passphrase is not
	 * already set. Replacing a passphrase invalidates ALL existing vault
	 * entries (they cannot be decrypted under a new key), so resetting
	 * requires a separate destructive admin flow not exposed here.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_set_passphrase( $request ) {
		$pass = (string) $request->get_param( 'passphrase' );

		/*
		 * The vault passphrase is the sole protection for encrypted
		 * phone numbers. The spec's pre-launch checklist says the
		 * passphrase is stored in a sealed envelope in a safe and
		 * memorised by the admin — so it's a true human-generated
		 * secret, not a generated token. We require at least 16
		 * characters. Site owners can set a different floor via the
		 * `hnc_vault_min_passphrase_length` filter but are discouraged
		 * from going below 16.
		 */
		$min_len = (int) apply_filters( 'hnc_vault_min_passphrase_length', 16 );
		if ( $min_len < 12 ) {
			$min_len = 12;
		}
		if ( strlen( $pass ) < $min_len ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'code'    => self::ERR_BAD_INPUT,
					'message' => sprintf(
						/* translators: %d is the minimum required passphrase length. */
						__( 'Passphrase must be at least %d characters.', 'helpnagaland-core' ),
						$min_len
					),
				),
				400
			);
		}

		if ( ! class_exists( 'HNC_Encryption' ) ) {
			return self::unauthorized_response();
		}

		if ( HNC_Encryption::passphrase_is_set() ) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'code'    => self::ERR_ALREADY_SET,
					'message' => __( 'A vault passphrase is already set. Replacing it requires a separate reset flow.', 'helpnagaland-core' ),
				),
				409
			);
		}

		$ok = HNC_Encryption::set_passphrase( $pass );
		if ( ! $ok ) {
			return self::unauthorized_response();
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				HNC_Logger::ACTION_VAULT_PASSPHRASE,
				0,
				array(
					'moderator' => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
					'action'    => 'set_initial',
				)
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array( 'set' => true ),
			),
			200
		);
	}

	/**
	 * POST /vault/unlock. Accepts a passphrase, attempts to unlock the
	 * session. Failure is returned with a single generic error code so
	 * no information is leaked about whether the passphrase was partly
	 * correct.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_unlock( $request ) {
		$pass = (string) $request->get_param( 'passphrase' );

		if ( '' === $pass || ! class_exists( 'HNC_Encryption' ) ) {
			return self::unauthorized_response();
		}

		$unlocked = HNC_Encryption::unlock( $pass );
		if ( ! $unlocked ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				HNC_Logger::log_vault(
					HNC_Logger::ACTION_VAULT_FAIL,
					0,
					array(
						'moderator' => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0,
						'reason'    => 'unlock_failed',
					)
				);
			}
			return self::unauthorized_response();
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				HNC_Logger::ACTION_VAULT_UNLOCK,
				0,
				array( 'moderator' => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0 )
			);
		}

		$seconds = class_exists( 'HNC_Encryption' ) ? (int) HNC_Encryption::unlock_seconds_remaining() : 0;
		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'unlocked'           => true,
					'seconds_remaining'  => $seconds,
				),
			),
			200
		);
	}

	/**
	 * POST /vault/lock. Immediately zeros the session key.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_lock() {
		if ( class_exists( 'HNC_Encryption' ) ) {
			HNC_Encryption::lock();
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_vault(
				HNC_Logger::ACTION_VAULT_LOCK,
				0,
				array( 'moderator' => function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0 )
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array( 'locked' => true ),
			),
			200
		);
	}

	/**
	 * GET /vault/status. Report whether vault is unlocked and how much time
	 * remains before auto-lock.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_status() {
		$passphrase_set = false;
		$unlocked       = false;
		$seconds        = 0;
		if ( class_exists( 'HNC_Encryption' ) ) {
			$passphrase_set = HNC_Encryption::passphrase_is_set();
			$unlocked       = HNC_Encryption::is_unlocked();
			$seconds        = (int) HNC_Encryption::unlock_seconds_remaining();
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'passphrase_set'    => $passphrase_set,
					'unlocked'          => $unlocked,
					'seconds_remaining' => $seconds,
				),
			),
			200
		);
	}


	/* ------------------------------------------------------------------
	 * PERMISSION CALLBACK
	 * ------------------------------------------------------------------ */

	/**
	 * Callback used by register_rest_route. Returns true or a WP_Error.
	 *
	 * @return bool|WP_Error
	 */
	public static function require_vault_cap() {
		$cap = class_exists( 'HNC_Roles' ) ? HNC_Roles::CAP_MANAGE_VAULT : 'hnc_manage_vault';
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( $cap ) ) {
			return new WP_Error(
				self::ERR_UNAUTHORIZED,
				__( 'You do not have permission to manage the phone vault.', 'helpnagaland-core' ),
				array( 'status' => 403 )
			);
		}
		return true;
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Unified unauthorized response. Used for failed unlock and anything
	 * else that should not disclose details.
	 *
	 * @return WP_REST_Response
	 */
	private static function unauthorized_response() {
		return new WP_REST_Response(
			array(
				'success' => false,
				'code'    => self::ERR_UNAUTHORIZED,
				'message' => __( 'Vault access denied.', 'helpnagaland-core' ),
			),
			401
		);
	}
}
