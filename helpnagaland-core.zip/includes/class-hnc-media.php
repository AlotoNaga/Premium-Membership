<?php
/**
 * Media handling: uploads, EXIF stripping, UUID rename, protected serving.
 *
 * Every photo or video uploaded by a reporter passes through this class.
 * The guarantees this class provides are:
 *
 *   1. No EXIF metadata survives. GPS coordinates, camera model, timestamps,
 *      device serials, thumbnails embedded in EXIF, all gone. The file that
 *      lands on disk is a clean re-encoded image.
 *
 *   2. The original filename is discarded. The stored filename is a random
 *      UUID v4. The reporter's "IMG_20250414_173022.jpg" tells us nothing.
 *
 *   3. Files live in a directory not reachable by direct URL. They are
 *      served only through authenticated REST endpoints that check
 *      capabilities before streaming bytes.
 *
 *   4. A SHA-256 hash of the final file is recorded in the report row.
 *      After the file is auto-deleted at retention time, the hash remains
 *      as proof that moderation actually saw an artefact.
 *
 *   5. File freshness is enforced. If the EXIF DateTime shows the photo
 *      was taken more than 3 minutes before submission, the upload is
 *      rejected. This is the primary mechanism against gallery upload
 *      attempts on the alcohol pipeline. The check runs BEFORE the EXIF
 *      is stripped.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Media
 */
final class HNC_Media {


	/**
	 * Accepted image MIME types for alcohol submissions.
	 */
	const ALCOHOL_ALLOWED_MIMES = array(
		'image/jpeg',
		'image/png',
	);

	/**
	 * Accepted media MIME types for drug submissions (images + short video).
	 */
	const DRUG_ALLOWED_MIMES = array(
		'image/jpeg',
		'image/png',
		'image/webp',
		'video/mp4',
		'video/quicktime',
	);

	/**
	 * Max accepted file size in bytes.
	 */
	const MAX_FILE_SIZE = 15728640; // 15 MiB


	/* ------------------------------------------------------------------
	 * PUBLIC API
	 * ------------------------------------------------------------------ */

	/**
	 * Process an uploaded file for the alcohol pipeline.
	 *
	 *   - Verify size and MIME.
	 *   - Check EXIF freshness (photo taken within last N seconds).
	 *   - Strip EXIF by re-encoding.
	 *   - Save to hnc-private/alcohol/ with a UUID filename.
	 *   - Compute and return SHA-256 hash.
	 *
	 * On any failure the uploaded file is removed from the PHP upload temp
	 * location. The return value is an array on success, or a WP_Error on failure.
	 *
	 * @param array $file Single slot from $_FILES, e.g. $_FILES['photo'].
	 * @return array{uuid:string,hash:string,relative_path:string,absolute_path:string,mime:string}|WP_Error
	 */
	public static function handle_alcohol_upload( $file ) {
		return self::handle_upload( $file, 'alcohol', self::ALCOHOL_ALLOWED_MIMES, true );
	}

	/**
	 * Process an uploaded file for the drug pipeline.
	 *
	 * Differences from alcohol:
	 *   - Gallery upload is allowed. No freshness check.
	 *   - Videos are permitted.
	 *
	 * @param array $file Single slot from $_FILES.
	 * @return array{uuid:string,hash:string,relative_path:string,absolute_path:string,mime:string}|WP_Error
	 */
	public static function handle_drug_upload( $file ) {
		return self::handle_upload( $file, 'drug', self::DRUG_ALLOWED_MIMES, false );
	}


	/* ------------------------------------------------------------------
	 * UPLOAD PIPELINE
	 * ------------------------------------------------------------------ */

	/**
	 * Shared upload pipeline. Returns structured data on success or
	 * WP_Error on failure.
	 *
	 * @param array  $file            $_FILES entry.
	 * @param string $pipeline        'alcohol' | 'drug'.
	 * @param array  $allowed_mimes   List of allowed MIME strings.
	 * @param bool   $require_freshness Whether to enforce EXIF freshness.
	 * @return array|WP_Error
	 */
	private static function handle_upload( $file, $pipeline, $allowed_mimes, $require_freshness ) {

		// Basic structure check.
		if ( ! is_array( $file ) || empty( $file['tmp_name'] ) || ! isset( $file['error'] ) ) {
			return new WP_Error( 'hnc_upload_missing', __( 'No file received.', 'helpnagaland-core' ) );
		}
		if ( UPLOAD_ERR_OK !== (int) $file['error'] ) {
			return new WP_Error(
				'hnc_upload_error',
				self::php_upload_error_message( (int) $file['error'] )
			);
		}
		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			// Required for security; reject attempts to point at other filesystem paths.
			return new WP_Error( 'hnc_upload_invalid', __( 'Invalid upload source.', 'helpnagaland-core' ) );
		}

		// Size.
		$size = (int) ( $file['size'] ?? 0 );
		if ( $size <= 0 ) {
			return new WP_Error( 'hnc_upload_empty', __( 'Uploaded file is empty.', 'helpnagaland-core' ) );
		}
		if ( $size > self::MAX_FILE_SIZE ) {
			return new WP_Error( 'hnc_upload_too_large', __( 'Uploaded file exceeds the size limit.', 'helpnagaland-core' ) );
		}

		$tmp = (string) $file['tmp_name'];

		// Real MIME (do not trust $file['type'] from the client).
		$real_mime = self::detect_mime( $tmp );
		if ( '' === $real_mime ) {
			return new WP_Error( 'hnc_upload_mime', __( 'Could not determine file type.', 'helpnagaland-core' ) );
		}
		if ( ! in_array( $real_mime, $allowed_mimes, true ) ) {
			return new WP_Error( 'hnc_upload_mime_disallowed', __( 'File type not permitted.', 'helpnagaland-core' ) );
		}

		// Freshness check for alcohol: EXIF DateTime must be within the window.
		if ( $require_freshness && strpos( $real_mime, 'image/' ) === 0 ) {
			$max_age = (int) get_option( 'hnc_photo_freshness_max_seconds', 180 );
			if ( $max_age > 0 ) {
				$exif_ts = self::read_exif_timestamp( $tmp );
				if ( null !== $exif_ts ) {
					$delta = abs( time() - $exif_ts );
					if ( $delta > $max_age ) {
						return new WP_Error(
							'hnc_upload_stale',
							__( 'Photo does not look fresh. Please take a new photo at the location and submit again.', 'helpnagaland-core' )
						);
					}
				}
				// If EXIF is absent we DO NOT reject: many Android cameras strip
				// EXIF on certain quality settings. Live-camera enforcement is
				// primarily a client-side and server-side "capture" attribute,
				// not purely EXIF. Freshness is a defence in depth, not the only line.
			}
		}

		// Prepare destination.
		$base = self::uploads_base_dir();
		if ( '' === $base ) {
			return new WP_Error( 'hnc_upload_no_base', __( 'Upload directory is not available.', 'helpnagaland-core' ) );
		}
		$sub = trailingslashit( $base ) . $pipeline;
		if ( ! is_dir( $sub ) ) {
			wp_mkdir_p( $sub );
		}

		$uuid = self::generate_uuid_v4();
		$ext  = self::extension_for_mime( $real_mime );
		if ( '' === $ext ) {
			return new WP_Error( 'hnc_upload_no_ext', __( 'Unsupported file type.', 'helpnagaland-core' ) );
		}
		$destination = trailingslashit( $sub ) . $uuid . '.' . $ext;

		// Strip EXIF and move. For video we do not re-encode; we just move the file.
		if ( strpos( $real_mime, 'image/' ) === 0 ) {
			$ok = self::strip_exif_and_save( $tmp, $destination, $real_mime );
			if ( ! $ok ) {
				return new WP_Error( 'hnc_upload_exif_fail', __( 'Could not process the image.', 'helpnagaland-core' ) );
			}
			// Remove the temp original.
			@unlink( $tmp ); // phpcs:ignore
		} else {
			// Video: move as is. EXIF is not a meaningful concern for mp4/mov.
			$moved = @rename( $tmp, $destination ); // phpcs:ignore
			if ( ! $moved ) {
				// Fall back to copy if rename fails (cross-device moves, shared hosts).
				$copied = @copy( $tmp, $destination ); // phpcs:ignore
				if ( ! $copied ) {
					return new WP_Error( 'hnc_upload_move_fail', __( 'Could not save the file.', 'helpnagaland-core' ) );
				}
				@unlink( $tmp ); // phpcs:ignore
			}
		}

		if ( ! file_exists( $destination ) ) {
			return new WP_Error( 'hnc_upload_missing_final', __( 'File not saved.', 'helpnagaland-core' ) );
		}

		// Restrict file permissions defensively. 0600 so only the PHP user reads it.
		@chmod( $destination, 0600 ); // phpcs:ignore

		$hash = hash_file( 'sha256', $destination );
		if ( false === $hash ) {
			// Very unusual. Still return success but with empty hash.
			$hash = '';
		}

		$relative = $pipeline . '/' . $uuid . '.' . $ext;

		return array(
			'uuid'          => $uuid,
			'hash'          => $hash,
			'relative_path' => $relative,
			'absolute_path' => $destination,
			'mime'          => $real_mime,
		);
	}


	/* ------------------------------------------------------------------
	 * DELETE
	 * ------------------------------------------------------------------ */

	/**
	 * Delete a stored file when you only know its pipeline and UUID.
	 *
	 * This is the helper for moderation paths and cleanup routines that
	 * track uuid only (the uuid is what lives in the database column).
	 * Probes the allowed extensions for that pipeline until it finds the
	 * file and then deletes it.
	 *
	 * @param string $pipeline 'alcohol' or 'drug'.
	 * @param string $uuid     The UUID returned from handle_*_upload.
	 * @return bool True if deleted or not present. False on filesystem error.
	 */
	public static function delete_by_uuid( $pipeline, $uuid ) {
		$uuid = (string) $uuid;
		if ( '' === $uuid ) {
			return true;
		}
		$relative = self::find_relative_by_uuid( $pipeline, $uuid );
		if ( '' === $relative ) {
			return true; // nothing to delete.
		}
		return self::delete( $relative );
	}

	/**
	 * Find the stored relative path for a given pipeline and UUID by probing
	 * the allowed extensions for that pipeline. Returns the first match.
	 *
	 * @param string $pipeline 'alcohol' or 'drug'.
	 * @param string $uuid     UUID.
	 * @return string Relative path like 'alcohol/{uuid}.jpg', or '' if none.
	 */
	public static function find_relative_by_uuid( $pipeline, $uuid ) {
		$pipeline = (string) $pipeline;
		$uuid     = (string) $uuid;
		if ( '' === $pipeline || '' === $uuid ) {
			return '';
		}
		$base = self::uploads_base_dir();
		if ( '' === $base ) {
			return '';
		}
		$mimes = ( 'alcohol' === $pipeline ) ? self::ALCOHOL_ALLOWED_MIMES : self::DRUG_ALLOWED_MIMES;
		foreach ( $mimes as $mime ) {
			$ext = self::extension_for_mime( $mime );
			if ( '' === $ext ) {
				continue;
			}
			$relative = $pipeline . '/' . $uuid . '.' . $ext;
			$abs      = self::safe_join( $base, $relative );
			if ( '' !== $abs && file_exists( $abs ) ) {
				return $relative;
			}
		}
		return '';
	}

	/**
	 * Delete a file stored under the protected uploads directory by its
	 * relative path (as returned by handle_upload). Safe against path
	 * traversal.
	 *
	 * @param string $relative_path Stored relative path, e.g. 'alcohol/uuid.jpg'.
	 * @return bool True if the file did not exist OR was removed.
	 */
	public static function delete( $relative_path ) {
		$base = self::uploads_base_dir();
		if ( '' === $base ) {
			return false;
		}
		$abs = self::safe_join( $base, $relative_path );
		if ( '' === $abs ) {
			return false;
		}
		if ( ! file_exists( $abs ) ) {
			return true; // already gone; treat as success.
		}
		return @unlink( $abs ); // phpcs:ignore
	}

	/**
	 * Return the absolute path for a stored relative path, safely. Empty
	 * string if the path would escape the uploads directory.
	 *
	 * @param string $relative_path Relative path like 'alcohol/uuid.jpg'.
	 * @return string
	 */
	public static function absolute_path( $relative_path ) {
		$base = self::uploads_base_dir();
		if ( '' === $base ) {
			return '';
		}
		return self::safe_join( $base, $relative_path );
	}


	/* ------------------------------------------------------------------
	 * SERVING (authenticated stream)
	 * ------------------------------------------------------------------
	 *
	 * The REST handlers in Phase 6 will call this to stream the file
	 * content to an authorized admin or partner. It is here rather than
	 * in the API layer because the same streaming logic may be reused
	 * by future admin screens.
	 */

	/**
	 * Stream a file to the client with a safe content type and headers.
	 * Exits the script after streaming.
	 *
	 * Caller MUST have verified capability and ownership before calling this.
	 *
	 * @param string $relative_path Stored relative path.
	 * @return void
	 */
	public static function stream( $relative_path ) {
		$abs = self::absolute_path( $relative_path );
		if ( '' === $abs || ! file_exists( $abs ) ) {
			status_header( 404 );
			nocache_headers();
			exit;
		}

		$mime = self::detect_mime( $abs );
		if ( '' === $mime ) {
			$mime = 'application/octet-stream';
		}

		nocache_headers();
		header( 'Content-Type: ' . $mime );
		header( 'Content-Length: ' . (string) filesize( $abs ) );
		header( 'X-Content-Type-Options: nosniff' );
		header( 'Content-Disposition: inline; filename="' . basename( $abs ) . '"' );

		// Stream in chunks to avoid loading large files fully in memory.
		$fp = fopen( $abs, 'rb' );
		if ( $fp ) {
			while ( ! feof( $fp ) ) {
				echo fread( $fp, 8192 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				if ( connection_aborted() ) {
					break;
				}
			}
			fclose( $fp );
		}
		exit;
	}


	/* ------------------------------------------------------------------
	 * EXIF STRIP + RE-ENCODE
	 * ------------------------------------------------------------------ */

	/**
	 * Re-encode an image to strip EXIF metadata and save to destination.
	 * Prefers Imagick when available, falls back to GD.
	 *
	 * @param string $source Source path.
	 * @param string $dest   Destination path (extension must match MIME).
	 * @param string $mime   Real MIME type.
	 * @return bool
	 */
	private static function strip_exif_and_save( $source, $dest, $mime ) {
		// Imagick is preferred because it handles PNG and JPEG well and
		// the ->stripImage() call is explicit.
		if ( class_exists( 'Imagick' ) ) {
			try {
				$img = new Imagick( $source ); // phpcs:ignore
				$img->stripImage();
				// Re-encode to the target format to drop any hidden metadata.
				if ( 'image/jpeg' === $mime ) {
					$img->setImageFormat( 'jpeg' );
					$img->setImageCompressionQuality( 88 );
				} elseif ( 'image/png' === $mime ) {
					$img->setImageFormat( 'png' );
				} elseif ( 'image/webp' === $mime ) {
					$img->setImageFormat( 'webp' );
					$img->setImageCompressionQuality( 88 );
				}
				$ok = $img->writeImage( $dest );
				$img->clear();
				$img->destroy();
				return (bool) $ok;
			} catch ( Throwable $t ) {
				// Fall through to GD.
			}
		}

		// GD fallback. No native EXIF handling; re-encoding via imagecreatefrom*
		// drops metadata by design.
		if ( function_exists( 'imagecreatefromjpeg' ) && 'image/jpeg' === $mime ) {
			$im = @imagecreatefromjpeg( $source ); // phpcs:ignore
			if ( ! $im ) {
				return false;
			}
			$ok = imagejpeg( $im, $dest, 88 );
			imagedestroy( $im );
			return (bool) $ok;
		}
		if ( function_exists( 'imagecreatefrompng' ) && 'image/png' === $mime ) {
			$im = @imagecreatefrompng( $source ); // phpcs:ignore
			if ( ! $im ) {
				return false;
			}
			// Preserve alpha.
			imagealphablending( $im, false );
			imagesavealpha( $im, true );
			$ok = imagepng( $im, $dest, 5 );
			imagedestroy( $im );
			return (bool) $ok;
		}
		if ( function_exists( 'imagecreatefromwebp' ) && 'image/webp' === $mime ) {
			$im = @imagecreatefromwebp( $source ); // phpcs:ignore
			if ( ! $im ) {
				return false;
			}
			$ok = imagewebp( $im, $dest, 88 );
			imagedestroy( $im );
			return (bool) $ok;
		}

		return false;
	}


	/* ------------------------------------------------------------------
	 * EXIF TIMESTAMP READ (freshness check)
	 * ------------------------------------------------------------------ */

	/**
	 * Try to read the DateTimeOriginal EXIF field as a unix timestamp.
	 * Returns null if the file has no readable EXIF timestamp.
	 *
	 * @param string $path Source file path.
	 * @return int|null Unix timestamp or null.
	 */
	private static function read_exif_timestamp( $path ) {
		if ( ! function_exists( 'exif_read_data' ) ) {
			return null;
		}
		// @ to swallow warnings on files without EXIF blocks.
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$exif = @exif_read_data( $path, 'EXIF', true, false );
		if ( ! is_array( $exif ) ) {
			return null;
		}
		$candidates = array();
		if ( isset( $exif['EXIF']['DateTimeOriginal'] ) ) {
			$candidates[] = $exif['EXIF']['DateTimeOriginal'];
		}
		if ( isset( $exif['EXIF']['DateTimeDigitized'] ) ) {
			$candidates[] = $exif['EXIF']['DateTimeDigitized'];
		}
		if ( isset( $exif['IFD0']['DateTime'] ) ) {
			$candidates[] = $exif['IFD0']['DateTime'];
		}
		foreach ( $candidates as $c ) {
			// EXIF datetime format is "YYYY:MM:DD HH:MM:SS".
			$ts = strtotime( str_replace( ':', '-', substr( $c, 0, 10 ) ) . substr( $c, 10 ) );
			if ( false !== $ts ) {
				return (int) $ts;
			}
		}
		return null;
	}


	/* ------------------------------------------------------------------
	 * HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Absolute base directory for HNC private uploads.
	 *
	 * @return string
	 */
	public static function uploads_base_dir() {
		$upload = wp_upload_dir();
		if ( ! empty( $upload['error'] ) ) {
			return '';
		}
		$base = trailingslashit( $upload['basedir'] ) . HNC_UPLOADS_DIR;
		return $base;
	}

	/**
	 * Detect MIME of a file. Prefers finfo, falls back to getimagesize and
	 * wp_check_filetype.
	 *
	 * @param string $path Path to file.
	 * @return string MIME or empty string.
	 */
	public static function detect_mime( $path ) {
		if ( ! file_exists( $path ) ) {
			return '';
		}
		if ( function_exists( 'finfo_open' ) ) {
			$finfo = finfo_open( FILEINFO_MIME_TYPE );
			if ( $finfo ) {
				$m = finfo_file( $finfo, $path );
				finfo_close( $finfo );
				if ( is_string( $m ) && '' !== $m ) {
					return strtolower( $m );
				}
			}
		}
		if ( function_exists( 'mime_content_type' ) ) {
			$m = mime_content_type( $path );
			if ( is_string( $m ) && '' !== $m ) {
				return strtolower( $m );
			}
		}
		// Last resort: getimagesize.
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$info = @getimagesize( $path );
		if ( is_array( $info ) && isset( $info['mime'] ) ) {
			return strtolower( (string) $info['mime'] );
		}
		return '';
	}

	/**
	 * Get the canonical extension for a MIME.
	 *
	 * @param string $mime MIME.
	 * @return string
	 */
	public static function extension_for_mime( $mime ) {
		$map = array(
			'image/jpeg'      => 'jpg',
			'image/png'       => 'png',
			'image/webp'      => 'webp',
			'video/mp4'       => 'mp4',
			'video/quicktime' => 'mov',
		);
		return isset( $map[ $mime ] ) ? $map[ $mime ] : '';
	}

	/**
	 * Generate a random UUID v4 string.
	 *
	 * @return string
	 */
	public static function generate_uuid_v4() {
		try {
			$data = random_bytes( 16 );
		} catch ( Throwable $t ) {
			// Fallback. Not cryptographically ideal but still unique enough
			// when combined with a uniqid prefix.
			$data = openssl_random_pseudo_bytes( 16 );
			if ( false === $data ) {
				$data = hex2bin( md5( uniqid( (string) mt_rand(), true ) ) );
			}
		}
		$data[6] = chr( ( ord( $data[6] ) & 0x0f ) | 0x40 ); // version 4
		$data[8] = chr( ( ord( $data[8] ) & 0x3f ) | 0x80 ); // variant
		return vsprintf( '%s%s-%s-%s-%s-%s%s%s', str_split( bin2hex( $data ), 4 ) );
	}

	/**
	 * Safely join a relative path onto a base directory. Returns empty
	 * string if the resolved path escapes the base.
	 *
	 * @param string $base          Absolute base directory.
	 * @param string $relative_path Trusted but validated relative path.
	 * @return string
	 */
	private static function safe_join( $base, $relative_path ) {
		$relative_path = (string) $relative_path;
		// Disallow absolute components and traversal.
		if ( '' === $relative_path || $relative_path[0] === '/' || strpos( $relative_path, '..' ) !== false ) {
			return '';
		}
		$candidate = trailingslashit( $base ) . ltrim( $relative_path, '/' );

		$real_base      = @realpath( $base ); // phpcs:ignore
		$real_candidate = @realpath( $candidate ); // phpcs:ignore

		if ( false === $real_base || false === $real_candidate ) {
			// File may not exist yet (e.g. on delete of already-gone file). Fall back
			// to basic string containment.
			if ( strpos( $candidate, $base ) !== 0 ) {
				return '';
			}
			return $candidate;
		}
		if ( strpos( $real_candidate, $real_base ) !== 0 ) {
			return '';
		}
		return $real_candidate;
	}

	/**
	 * Map a PHP UPLOAD_ERR_* code to a human message.
	 *
	 * @param int $code UPLOAD_ERR_* constant.
	 * @return string
	 */
	private static function php_upload_error_message( $code ) {
		switch ( $code ) {
			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
				return __( 'File is larger than the server allows.', 'helpnagaland-core' );
			case UPLOAD_ERR_PARTIAL:
				return __( 'File was only partially uploaded.', 'helpnagaland-core' );
			case UPLOAD_ERR_NO_FILE:
				return __( 'No file was uploaded.', 'helpnagaland-core' );
			case UPLOAD_ERR_NO_TMP_DIR:
				return __( 'Server upload directory is missing.', 'helpnagaland-core' );
			case UPLOAD_ERR_CANT_WRITE:
				return __( 'Server could not write the uploaded file.', 'helpnagaland-core' );
			case UPLOAD_ERR_EXTENSION:
				return __( 'An extension blocked the upload.', 'helpnagaland-core' );
			default:
				return __( 'Unknown upload error.', 'helpnagaland-core' );
		}
	}
}
