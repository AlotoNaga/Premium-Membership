<?php
/**
 * Geographic utilities.
 *
 * Provides the geographic primitives used throughout the plugin:
 *
 *   - Nagaland state boundary check
 *   - District detection from lat/lng
 *   - Snap-to-grid for public map privacy
 *   - Haversine distance between two points
 *   - Nearest-existing-pin lookup for auto-merge
 *
 * Coordinate conventions:
 *
 *   - lat (decimal degrees, range -90 to 90)
 *   - lng (decimal degrees, range -180 to 180)
 *   - distances are in meters
 *
 * Nagaland sits between approximately 25.2 to 27.05 degrees North, and
 * 93.3 to 95.85 degrees East. At that latitude, 1 degree of latitude is
 * roughly 111,000 meters, and 1 degree of longitude is roughly 100,000
 * meters. We use these constants in the grid snap math below.
 *
 * The district centroids used here are approximate. They are derived
 * from the `indian-states-cities-geolocation` 2026 reference dataset
 * (MIT) and are accurate enough to pick the correct district for most
 * interior points. Nagaland's northeastern districts have irregular
 * shapes, so a point near a boundary can still be mis-assigned by a
 * centroid-nearest classifier.
 *
 * For higher accuracy, drop a real district polygon file at
 * `lib/nagaland-districts.geojson` (FeatureCollection). This class
 * picks it up automatically, uses point-in-polygon, and falls back to
 * centroids when the file is missing, invalid, or does not contain a
 * match. See `lib/nagaland-districts.README.md` for the exact format,
 * recommended sources and licensing notes. The pre-launch checklist
 * in the spec still requires validating detection against 20 sample
 * points across all 16 districts, whichever classifier is active.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Geo
 */
final class HNC_Geo {


	/**
	 * Earth mean radius in meters (used by haversine).
	 */
	const EARTH_RADIUS_M = 6371000.0;

	/**
	 * Meters per degree of latitude. A good constant across mid-latitudes.
	 */
	const M_PER_DEG_LAT = 110574.0;

	/**
	 * Approximate meters per degree of longitude at Nagaland's mean latitude
	 * (~26°). Used for snap grid math. Actual value varies with cos(lat).
	 */
	const M_PER_DEG_LNG_NAGALAND = 99800.0;


	/* ------------------------------------------------------------------
	 * BOUNDARY CHECK
	 * ------------------------------------------------------------------ */

	/**
	 * Return true if the given point is within the configured Nagaland bounds.
	 *
	 * Phase 2 uses a bounding box stored in the 'hnc_nagaland_bounds' option.
	 * A future phase will replace this with a point-in-polygon check against
	 * a real Nagaland boundary GeoJSON.
	 *
	 * @param float $lat Latitude.
	 * @param float $lng Longitude.
	 * @return bool
	 */
	public static function is_in_nagaland( $lat, $lng ) {
		$bounds = self::load_bounds();
		// load_bounds() always returns a valid array via the built-in
		// fallback, but keep the defensive check in case a filter ever
		// intercepts and mangles it.
		if ( ! is_array( $bounds ) || empty( $bounds['lat_min'] ) ) {
			$bounds = self::default_bounds();
		}
		$lat = (float) $lat;
		$lng = (float) $lng;

		// Basic sanity.
		if ( $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180 ) {
			return false;
		}

		$in_lat = ( $lat >= $bounds['lat_min'] && $lat <= $bounds['lat_max'] );
		$in_lng = ( $lng >= $bounds['lng_min'] && $lng <= $bounds['lng_max'] );
		return $in_lat && $in_lng;
	}

	/**
	 * Built-in Nagaland bounding box. Used as a safe fallback when the
	 * `hnc_nagaland_bounds` option is missing or malformed, so a fresh
	 * install or a broken admin edit never silently disables district
	 * detection.
	 *
	 * Values are the conservative outer envelope of the 16 districts.
	 *
	 * @return array{lat_min:float,lat_max:float,lng_min:float,lng_max:float}
	 */
	public static function default_bounds() {
		return array(
			'lat_min' => 25.20,
			'lat_max' => 27.04,
			'lng_min' => 93.32,
			'lng_max' => 95.25,
		);
	}

	/**
	 * Load the configured Nagaland bounds from options, falling back to
	 * the built-in default if the option is missing or malformed.
	 *
	 * @return array{lat_min:float,lat_max:float,lng_min:float,lng_max:float}
	 */
	private static function load_bounds() {
		$raw = get_option( 'hnc_nagaland_bounds', '' );
		if ( is_string( $raw ) ) {
			$decoded = json_decode( $raw, true );
		} else {
			$decoded = $raw;
		}
		if ( is_array( $decoded ) ) {
			$ok = true;
			foreach ( array( 'lat_min', 'lat_max', 'lng_min', 'lng_max' ) as $k ) {
				if ( ! isset( $decoded[ $k ] ) || ! is_numeric( $decoded[ $k ] ) ) {
					$ok = false;
					break;
				}
				$decoded[ $k ] = (float) $decoded[ $k ];
			}
			if ( $ok ) {
				return $decoded;
			}
		}
		return self::default_bounds();
	}


	/* ------------------------------------------------------------------
	 * DISTRICT DETECTION
	 * ------------------------------------------------------------------
	 *
	 * Given lat/lng inside Nagaland, return the nearest district by
	 * centroid distance. This is an approximation. True district
	 * detection requires polygon intersection, deferred to a launch
	 * readiness milestone.
	 *
	 * The district list and centroids are defined in this class as the
	 * source of truth for the approximation. If the option 'hnc_districts'
	 * diverges from this list, the option list is authoritative for UI
	 * display while this list is used for mapping GPS to name.
	 */

	/**
	 * District centroids in decimal degrees.
	 *
	 * Source: `indian-states-cities-geolocation` 1.0.5 (MIT license),
	 * cross-checked against Survey of India published district
	 * headquarters. Values were refreshed in v1.1.1 after several
	 * districts were off by 20+ km in the v1.0.0 data (Noklak, Shamator,
	 * Tseminyü, Chümoukedima). Still approximate — they are single
	 * points meant to anchor a nearest-neighbour classifier, not to
	 * represent the shape of the district.
	 *
	 * The list is filterable via `hnc_district_centroids` so site
	 * owners can override individual values without patching this file.
	 *
	 * @return array<int,array{name:string,lat:float,lng:float}>
	 */
	public static function district_centroids() {
		$data = array(
			array( 'name' => 'Chümoukedima', 'lat' => 25.7950, 'lng' => 93.7656 ),
			array( 'name' => 'Dimapur',      'lat' => 25.9060, 'lng' => 93.7277 ),
			array( 'name' => 'Kiphire',      'lat' => 25.8677, 'lng' => 94.7788 ),
			array( 'name' => 'Kohima',       'lat' => 25.6701, 'lng' => 94.1077 ),
			array( 'name' => 'Longleng',     'lat' => 26.4719, 'lng' => 94.8083 ),
			array( 'name' => 'Mokokchung',   'lat' => 26.3323, 'lng' => 94.5262 ),
			array( 'name' => 'Mon',          'lat' => 26.7441, 'lng' => 95.0560 ),
			array( 'name' => 'Niuland',      'lat' => 25.9329, 'lng' => 93.9926 ),
			array( 'name' => 'Noklak',       'lat' => 26.1993, 'lng' => 94.9912 ),
			array( 'name' => 'Peren',        'lat' => 25.5126, 'lng' => 93.7381 ),
			array( 'name' => 'Phek',         'lat' => 25.7001, 'lng' => 94.4607 ),
			array( 'name' => 'Shamator',     'lat' => 26.0142, 'lng' => 94.8727 ),
			array( 'name' => 'Tseminyü',     'lat' => 25.8569, 'lng' => 94.2494 ),
			array( 'name' => 'Tuensang',     'lat' => 26.2796, 'lng' => 94.8267 ),
			array( 'name' => 'Wokha',        'lat' => 26.1044, 'lng' => 94.2625 ),
			array( 'name' => 'Zunheboto',    'lat' => 25.9654, 'lng' => 94.5233 ),
		);
		return apply_filters( 'hnc_district_centroids', $data );
	}

	/**
	 * Determine the district for a given coordinate.
	 *
	 * Resolution order:
	 *   1. Point-in-polygon against `lib/nagaland-districts.geojson`
	 *      when that file exists and parses as a FeatureCollection.
	 *   2. Nearest-centroid fallback using {@see district_centroids()}.
	 *
	 * Returns the district name or empty string if the point is outside
	 * Nagaland.
	 *
	 * @param float $lat Latitude.
	 * @param float $lng Longitude.
	 * @return string
	 */
	public static function detect_district( $lat, $lng ) {
		if ( ! self::is_in_nagaland( $lat, $lng ) ) {
			return '';
		}
		$lat = (float) $lat;
		$lng = (float) $lng;

		$polygon_match = self::detect_district_by_polygon( $lat, $lng );
		if ( '' !== $polygon_match ) {
			return $polygon_match;
		}

		return self::detect_district_by_centroid( $lat, $lng );
	}

	/**
	 * Nearest-centroid classifier. Used as fallback when polygon data
	 * is absent, invalid, or does not contain the point.
	 *
	 * @param float $lat Latitude.
	 * @param float $lng Longitude.
	 * @return string
	 */
	public static function detect_district_by_centroid( $lat, $lng ) {
		$best_district = '';
		$best_distance = PHP_FLOAT_MAX;

		foreach ( self::district_centroids() as $d ) {
			$dist = self::haversine_meters( $lat, $lng, $d['lat'], $d['lng'] );
			if ( $dist < $best_distance ) {
				$best_distance = $dist;
				$best_district = (string) $d['name'];
			}
		}

		return $best_district;
	}

	/**
	 * Polygon-based classifier. Returns the matched district name, or
	 * empty string if polygon data is not available or no polygon
	 * contains the point.
	 *
	 * @param float $lat Latitude.
	 * @param float $lng Longitude.
	 * @return string
	 */
	public static function detect_district_by_polygon( $lat, $lng ) {
		$polygons = self::load_district_polygons();
		if ( empty( $polygons ) ) {
			return '';
		}
		foreach ( $polygons as $entry ) {
			$name = isset( $entry['name'] ) ? (string) $entry['name'] : '';
			if ( '' === $name || empty( $entry['rings'] ) || ! is_array( $entry['rings'] ) ) {
				continue;
			}
			// Multi-polygon: each `ring` element is itself an array of
			// rings (outer + holes). A point counts as inside the
			// feature if it is inside any outer ring AND NOT inside
			// any hole of that same outer ring.
			foreach ( $entry['rings'] as $polygon ) {
				if ( ! is_array( $polygon ) || empty( $polygon ) ) {
					continue;
				}
				$outer = $polygon[0];
				if ( ! self::point_in_ring( $lat, $lng, $outer ) ) {
					continue;
				}
				$inside_hole = false;
				for ( $i = 1; $i < count( $polygon ); $i++ ) {
					if ( self::point_in_ring( $lat, $lng, $polygon[ $i ] ) ) {
						$inside_hole = true;
						break;
					}
				}
				if ( ! $inside_hole ) {
					return $name;
				}
			}
		}
		return '';
	}

	/**
	 * Load district polygons from `lib/nagaland-districts.geojson` and
	 * return a normalised in-memory structure. Cached in a static so
	 * repeat calls in the same request do not re-parse.
	 *
	 * The file must be a GeoJSON FeatureCollection where each feature
	 * has either a `district` or `shapeName` property identifying the
	 * district, and a Polygon or MultiPolygon geometry. GeoJSON's own
	 * axis order is [longitude, latitude], which this loader converts
	 * to the plugin's internal [lat, lng] convention.
	 *
	 * Returns an empty array on any error — detect_district() treats an
	 * empty result as "polygon data not available" and falls through.
	 *
	 * @return array<int,array{name:string,rings:array}>
	 */
	public static function load_district_polygons() {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}

		$path = defined( 'HNC_PATH' ) ? HNC_PATH . 'lib/nagaland-districts.geojson' : '';
		$path = (string) apply_filters( 'hnc_district_polygons_path', $path );

		if ( '' === $path || ! is_readable( $path ) ) {
			$cache = array();
			return $cache;
		}
		$size = @filesize( $path );
		// Sane upper bound: a simplified Nagaland district file should
		// be well under 10 MB. Anything larger is probably wrong and
		// would blow PHP memory when decoded.
		if ( false === $size || $size <= 0 || $size > 10 * 1024 * 1024 ) {
			$cache = array();
			return $cache;
		}
		$raw = @file_get_contents( $path );
		if ( false === $raw || '' === $raw ) {
			$cache = array();
			return $cache;
		}
		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || ! isset( $data['type'] ) || 'FeatureCollection' !== $data['type']
			|| empty( $data['features'] ) || ! is_array( $data['features'] ) ) {
			$cache = array();
			return $cache;
		}

		$out = array();
		foreach ( $data['features'] as $feature ) {
			if ( ! is_array( $feature ) ) {
				continue;
			}
			$props = isset( $feature['properties'] ) && is_array( $feature['properties'] )
				? $feature['properties']
				: array();
			$name  = '';
			foreach ( array( 'district', 'DISTRICT', 'shapeName', 'NAME_2', 'dtname', 'Dist_Name' ) as $key ) {
				if ( isset( $props[ $key ] ) && '' !== $props[ $key ] ) {
					$name = (string) $props[ $key ];
					break;
				}
			}
			if ( '' === $name || empty( $feature['geometry'] ) || ! is_array( $feature['geometry'] ) ) {
				continue;
			}
			$geom = $feature['geometry'];
			$type = isset( $geom['type'] ) ? (string) $geom['type'] : '';
			$coords = isset( $geom['coordinates'] ) ? $geom['coordinates'] : null;
			if ( ! is_array( $coords ) ) {
				continue;
			}

			$rings = array();
			if ( 'Polygon' === $type ) {
				$rings[] = self::normalise_polygon_rings( $coords );
			} elseif ( 'MultiPolygon' === $type ) {
				foreach ( $coords as $polygon ) {
					if ( is_array( $polygon ) ) {
						$rings[] = self::normalise_polygon_rings( $polygon );
					}
				}
			} else {
				continue;
			}

			$out[] = array(
				'name'  => $name,
				'rings' => $rings,
			);
		}

		$cache = $out;
		return $cache;
	}

	/**
	 * Convert a GeoJSON polygon ring array (array of [lng,lat] pairs)
	 * to the plugin's internal [lat,lng] convention. Also drops
	 * malformed points.
	 *
	 * @param array $rings GeoJSON polygon rings.
	 * @return array<int,array<int,array{0:float,1:float}>>
	 */
	private static function normalise_polygon_rings( $rings ) {
		$out = array();
		if ( ! is_array( $rings ) ) {
			return $out;
		}
		foreach ( $rings as $ring ) {
			if ( ! is_array( $ring ) ) {
				continue;
			}
			$norm = array();
			foreach ( $ring as $pt ) {
				if ( ! is_array( $pt ) || count( $pt ) < 2 ) {
					continue;
				}
				$lng = (float) $pt[0];
				$lat = (float) $pt[1];
				$norm[] = array( $lat, $lng );
			}
			if ( count( $norm ) >= 3 ) {
				$out[] = $norm;
			}
		}
		return $out;
	}

	/**
	 * Ray-casting point-in-polygon test on a single ring.
	 * Ring is an array of [lat,lng] pairs. First and last point may or
	 * may not be identical — both forms are handled.
	 *
	 * @param float $lat Point latitude.
	 * @param float $lng Point longitude.
	 * @param array $ring Array of [lat,lng] pairs.
	 * @return bool
	 */
	private static function point_in_ring( $lat, $lng, $ring ) {
		$n = is_array( $ring ) ? count( $ring ) : 0;
		if ( $n < 3 ) {
			return false;
		}
		$inside = false;
		$j      = $n - 1;
		for ( $i = 0; $i < $n; $i++ ) {
			$lat_i = $ring[ $i ][0];
			$lng_i = $ring[ $i ][1];
			$lat_j = $ring[ $j ][0];
			$lng_j = $ring[ $j ][1];

			$intersect = ( ( $lat_i > $lat ) !== ( $lat_j > $lat ) )
				&& ( $lng < ( $lng_j - $lng_i ) * ( $lat - $lat_i ) / ( ( $lat_j - $lat_i ) ?: 1e-12 ) + $lng_i );
			if ( $intersect ) {
				$inside = ! $inside;
			}
			$j = $i;
		}
		return $inside;
	}


	/* ------------------------------------------------------------------
	 * DISTANCE CALCULATIONS
	 * ------------------------------------------------------------------ */

	/**
	 * Haversine great-circle distance in meters.
	 *
	 * @param float $lat1 Point 1 latitude.
	 * @param float $lng1 Point 1 longitude.
	 * @param float $lat2 Point 2 latitude.
	 * @param float $lng2 Point 2 longitude.
	 * @return float Distance in meters.
	 */
	public static function haversine_meters( $lat1, $lng1, $lat2, $lng2 ) {
		$lat1 = (float) $lat1;
		$lng1 = (float) $lng1;
		$lat2 = (float) $lat2;
		$lng2 = (float) $lng2;

		$phi1 = deg2rad( $lat1 );
		$phi2 = deg2rad( $lat2 );

		$delta_phi    = deg2rad( $lat2 - $lat1 );
		$delta_lambda = deg2rad( $lng2 - $lng1 );

		$a = sin( $delta_phi / 2 ) ** 2
			+ cos( $phi1 ) * cos( $phi2 ) * ( sin( $delta_lambda / 2 ) ** 2 );

		$c = 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );

		return self::EARTH_RADIUS_M * $c;
	}

	/**
	 * True if two points are within the given radius (in meters).
	 * Convenience wrapper for auto-merge logic.
	 *
	 * @param float $lat1       P1 lat.
	 * @param float $lng1       P1 lng.
	 * @param float $lat2       P2 lat.
	 * @param float $lng2       P2 lng.
	 * @param float $radius_m   Radius in meters.
	 * @return bool
	 */
	public static function within_radius( $lat1, $lng1, $lat2, $lng2, $radius_m ) {
		return self::haversine_meters( $lat1, $lng1, $lat2, $lng2 ) <= (float) $radius_m;
	}


	/* ------------------------------------------------------------------
	 * GRID SNAP
	 * ------------------------------------------------------------------
	 *
	 * For public-map privacy, we snap pin coordinates to a fixed grid.
	 * Two reports within the grid share a pin. The default grid is 50
	 * meters, configurable via the 'hnc_snap_grid_meters' option.
	 *
	 * The snap works by:
	 *   1. Convert the grid size in meters to a degree step (different
	 *      for lat and lng due to longitude varying with latitude).
	 *   2. Round each coordinate to the nearest multiple of that step.
	 *
	 * Result is deterministic: the same raw coordinate always produces
	 * the same snapped coordinate.
	 */

	/**
	 * Snap a coordinate to the configured grid. Returns snapped [lat, lng].
	 *
	 * @param float $lat       Raw latitude.
	 * @param float $lng       Raw longitude.
	 * @param int   $grid_m    Grid size in meters. Default from options.
	 * @return array{lat:float,lng:float}
	 */
	public static function snap_to_grid( $lat, $lng, $grid_m = null ) {
		if ( null === $grid_m ) {
			$grid_m = (int) get_option( 'hnc_snap_grid_meters', 50 );
		}
		$grid_m = max( 1, (int) $grid_m );

		$lat_step = $grid_m / self::M_PER_DEG_LAT;
		$lng_step = $grid_m / self::M_PER_DEG_LNG_NAGALAND;

		$snapped_lat = round( $lat / $lat_step ) * $lat_step;
		$snapped_lng = round( $lng / $lng_step ) * $lng_step;

		// Round to 7 decimal places to avoid floating point noise in storage.
		return array(
			'lat' => round( $snapped_lat, 7 ),
			'lng' => round( $snapped_lng, 7 ),
		);
	}


	/* ------------------------------------------------------------------
	 * MERGE CANDIDATE LOOKUP
	 * ------------------------------------------------------------------ */

	/**
	 * Find existing approved alcohol reports in the same category within
	 * the given radius of the supplied point. Used by moderation auto-merge.
	 *
	 * Returns rows ordered by distance ascending, nearest first.
	 *
	 * @param float  $lat         Latitude.
	 * @param float  $lng         Longitude.
	 * @param string $category    Category key.
	 * @param float  $radius_m    Search radius in meters (default 100).
	 * @return array Rows from hnc_alcohol_reports with an extra 'distance_m' field.
	 */
	public static function find_alcohol_merge_candidates( $lat, $lng, $category, $radius_m = 100.0 ) {
		if ( ! class_exists( 'HNC_Schema' ) ) {
			return array();
		}

		global $wpdb;
		$table = HNC_Schema::table_alcohol_reports();

		// Rough bounding box prefilter so we do not Haversine the whole table.
		$lat_pad = ( $radius_m * 1.5 ) / self::M_PER_DEG_LAT;
		$lng_pad = ( $radius_m * 1.5 ) / self::M_PER_DEG_LNG_NAGALAND;

		$lat_min = (float) $lat - $lat_pad;
		$lat_max = (float) $lat + $lat_pad;
		$lng_min = (float) $lng - $lng_pad;
		$lng_max = (float) $lng + $lng_pad;

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = "SELECT id, lat, lng, lat_raw, lng_raw, category, report_count, merged_into, verified_by_operator
			FROM {$table}
			WHERE status = %s
			  AND category = %s
			  AND merged_into IS NULL
			  AND lat BETWEEN %f AND %f
			  AND lng BETWEEN %f AND %f";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare( $sql, 'approved', $category, $lat_min, $lat_max, $lng_min, $lng_max )
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		// Compute exact haversine distance and filter by radius.
		$out = array();
		foreach ( $rows as $row ) {
			$dist = self::haversine_meters( $lat, $lng, (float) $row->lat_raw, (float) $row->lng_raw );
			if ( $dist <= $radius_m ) {
				$row->distance_m = $dist;
				$out[]           = $row;
			}
		}

		// Sort by distance ascending.
		usort(
			$out,
			function ( $a, $b ) {
				return ( $a->distance_m <=> $b->distance_m );
			}
		);

		return $out;
	}


	/* ------------------------------------------------------------------
	 * VALIDATION HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Validate that two lat/lng readings (raw and user-adjusted) are within
	 * the allowed tolerance. Used by the alcohol submit flow: a reporter
	 * may nudge their pin slightly but not more than 100m from the GPS reading.
	 *
	 * @param float $gps_lat    GPS reading lat.
	 * @param float $gps_lng    GPS reading lng.
	 * @param float $pin_lat    User-placed pin lat.
	 * @param float $pin_lng    User-placed pin lng.
	 * @param float $tolerance_m Default from options.
	 * @return bool True if within tolerance.
	 */
	public static function gps_pin_within_tolerance( $gps_lat, $gps_lng, $pin_lat, $pin_lng, $tolerance_m = null ) {
		if ( null === $tolerance_m ) {
			$tolerance_m = (float) get_option( 'hnc_gps_tolerance_meters', 100 );
		}
		$dist = self::haversine_meters( $gps_lat, $gps_lng, $pin_lat, $pin_lng );
		return $dist <= $tolerance_m;
	}
}
