<?php
/**
 * Custom roles and capabilities.
 *
 * The plugin uses WordPress capabilities to gate every sensitive operation.
 * Capabilities are checked at:
 *
 *   - REST API endpoint registration (permission_callback)
 *   - Admin menu registration (menu capability)
 *   - Individual action handlers (current_user_can)
 *
 * Capability list:
 *
 *   hnc_admin                 Full access. Granted to the administrator role.
 *   hnc_moderate_alcohol      Approve, reject, hold alcohol reports.
 *   hnc_moderate_drug         Approve, reject drug reports.
 *   hnc_view_audit            Read the audit log.
 *   hnc_manage_vault          Unlock the phone vault.
 *   hnc_reveal_phone          Reveal a specific phone number (requires vault unlock).
 *   hnc_forward_drug          Forward a drug report to a partner.
 *   hnc_manage_partners       Add, edit, suspend partner organizations.
 *   hnc_manage_settings       Edit plugin settings.
 *   hnc_operate_killswitch    Toggle the emergency kill switch.
 *   hnc_publish_transparency  Publish monthly transparency snapshots.
 *   hnc_partner_access        Read forwarded drug reports (partner role only).
 *
 * Roles:
 *
 *   Administrator (native)    Gets all capabilities except hnc_partner_access.
 *   hnc_moderator             Can moderate both pipelines and view audit.
 *                             Cannot manage settings, reveal phones, or
 *                             operate the kill switch. Designed for future
 *                             team expansion.
 *   hnc_partner               Read only access to forwarded drug reports.
 *                             No admin UI access. API only.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Roles
 */
final class HNC_Roles {


	/* --------------------------------------------------------------
	 * CAPABILITY CONSTANTS
	 * -------------------------------------------------------------- */

	const CAP_ADMIN                = 'hnc_admin';
	const CAP_MODERATE_ALCOHOL     = 'hnc_moderate_alcohol';
	const CAP_MODERATE_DRUG        = 'hnc_moderate_drug';
	const CAP_VIEW_AUDIT           = 'hnc_view_audit';
	const CAP_MANAGE_VAULT         = 'hnc_manage_vault';
	const CAP_REVEAL_PHONE         = 'hnc_reveal_phone';
	const CAP_FORWARD_DRUG         = 'hnc_forward_drug';
	const CAP_MANAGE_PARTNERS      = 'hnc_manage_partners';
	const CAP_MANAGE_SETTINGS      = 'hnc_manage_settings';
	const CAP_OPERATE_KILLSWITCH   = 'hnc_operate_killswitch';
	const CAP_PUBLISH_TRANSPARENCY = 'hnc_publish_transparency';
	const CAP_PARTNER_ACCESS       = 'hnc_partner_access';


	/* --------------------------------------------------------------
	 * ROLE CONSTANTS
	 * -------------------------------------------------------------- */

	const ROLE_MODERATOR = 'hnc_moderator';
	const ROLE_PARTNER   = 'hnc_partner';


	/* --------------------------------------------------------------
	 * INITIALIZATION
	 * --------------------------------------------------------------
	 *
	 * Called from the main bootstrap on every plugins_loaded. Safe to call
	 * many times. Designed to self heal if another plugin removes our caps.
	 */

	/**
	 * Ensure all HNC roles and capabilities exist. Idempotent.
	 *
	 * @return void
	 */
	public static function init() {
		self::ensure_admin_capabilities();
		self::ensure_moderator_role();
		self::ensure_partner_role();
	}


	/* --------------------------------------------------------------
	 * CAPABILITY GROUPS
	 * -------------------------------------------------------------- */

	/**
	 * All capabilities granted to the WordPress administrator role.
	 *
	 * Note: hnc_partner_access is intentionally excluded from the admin set.
	 * It belongs only to the partner role. A single WP user should never
	 * hold both admin and partner capabilities simultaneously.
	 *
	 * @return string[]
	 */
	public static function admin_capabilities() {
		return array(
			self::CAP_ADMIN,
			self::CAP_MODERATE_ALCOHOL,
			self::CAP_MODERATE_DRUG,
			self::CAP_VIEW_AUDIT,
			self::CAP_MANAGE_VAULT,
			self::CAP_REVEAL_PHONE,
			self::CAP_FORWARD_DRUG,
			self::CAP_MANAGE_PARTNERS,
			self::CAP_MANAGE_SETTINGS,
			self::CAP_OPERATE_KILLSWITCH,
			self::CAP_PUBLISH_TRANSPARENCY,
		);
	}

	/**
	 * Capabilities granted to the HNC Moderator role.
	 *
	 * Moderators can review and decide on submissions, but cannot:
	 *   - Reveal phone numbers
	 *   - Forward reports to partners
	 *   - Manage partners
	 *   - Change settings
	 *   - Operate the kill switch
	 *   - Publish transparency snapshots
	 *
	 * This reflects the editorial separation between a reviewer and the
	 * editor in chief (the admin).
	 *
	 * @return string[]
	 */
	public static function moderator_capabilities() {
		return array(
			self::CAP_MODERATE_ALCOHOL,
			self::CAP_MODERATE_DRUG,
			self::CAP_VIEW_AUDIT,
		);
	}

	/**
	 * Capabilities granted to the HNC Partner role.
	 *
	 * Partners can only read forwarded drug reports via the partner REST
	 * endpoints. They have no WP admin screen access.
	 *
	 * @return string[]
	 */
	public static function partner_capabilities() {
		return array(
			self::CAP_PARTNER_ACCESS,
		);
	}

	/**
	 * Every capability ever used by the plugin. Useful for removal on
	 * uninstall.
	 *
	 * @return string[]
	 */
	public static function all_capabilities() {
		return array_unique(
			array_merge(
				self::admin_capabilities(),
				self::moderator_capabilities(),
				self::partner_capabilities()
			)
		);
	}


	/* --------------------------------------------------------------
	 * ENSURE ROLES AND CAPS
	 * -------------------------------------------------------------- */

	/**
	 * Make sure every HNC admin capability is present on the WordPress
	 * administrator role. If another plugin or a manual action removed one,
	 * this re-adds it.
	 *
	 * @return void
	 */
	private static function ensure_admin_capabilities() {
		$admin_role = get_role( 'administrator' );
		if ( ! $admin_role ) {
			// No administrator role present. This is extremely unusual but
			// can happen on damaged installations. Nothing sensible to do here.
			return;
		}
		foreach ( self::admin_capabilities() as $cap ) {
			if ( ! $admin_role->has_cap( $cap ) ) {
				$admin_role->add_cap( $cap );
			}
		}
	}

	/**
	 * Create the HNC Moderator role if it does not exist, otherwise make
	 * sure its capability set matches what we expect.
	 *
	 * @return void
	 */
	private static function ensure_moderator_role() {
		$role = get_role( self::ROLE_MODERATOR );

		if ( ! $role ) {
			$caps = array_merge(
				array( 'read' => true ),
				array_fill_keys( self::moderator_capabilities(), true )
			);
			add_role(
				self::ROLE_MODERATOR,
				__( 'HNC Moderator', 'helpnagaland-core' ),
				$caps
			);
			return;
		}

		// Role exists. Ensure expected caps are present.
		foreach ( self::moderator_capabilities() as $cap ) {
			if ( ! $role->has_cap( $cap ) ) {
				$role->add_cap( $cap );
			}
		}
	}

	/**
	 * Create the HNC Partner role if it does not exist, otherwise make
	 * sure its capability set matches what we expect.
	 *
	 * @return void
	 */
	private static function ensure_partner_role() {
		$role = get_role( self::ROLE_PARTNER );

		if ( ! $role ) {
			$caps = array_merge(
				array( 'read' => true ),
				array_fill_keys( self::partner_capabilities(), true )
			);
			add_role(
				self::ROLE_PARTNER,
				__( 'HNC Partner', 'helpnagaland-core' ),
				$caps
			);
			return;
		}

		foreach ( self::partner_capabilities() as $cap ) {
			if ( ! $role->has_cap( $cap ) ) {
				$role->add_cap( $cap );
			}
		}
	}


	/* --------------------------------------------------------------
	 * REMOVAL (called only from uninstall.php)
	 * -------------------------------------------------------------- */

	/**
	 * Remove all HNC capabilities from the administrator role and delete
	 * the HNC custom roles entirely. Used by uninstall.php when the admin
	 * has explicitly opted in to data deletion.
	 *
	 * @return void
	 */
	public static function remove_all() {

		// Remove capabilities from administrator role.
		$admin_role = get_role( 'administrator' );
		if ( $admin_role ) {
			foreach ( self::all_capabilities() as $cap ) {
				$admin_role->remove_cap( $cap );
			}
		}

		// Also remove capabilities from the HNC roles before removing the roles
		// themselves. Not strictly necessary since remove_role is destructive,
		// but defensive.
		$moderator = get_role( self::ROLE_MODERATOR );
		if ( $moderator ) {
			foreach ( self::moderator_capabilities() as $cap ) {
				$moderator->remove_cap( $cap );
			}
		}

		$partner = get_role( self::ROLE_PARTNER );
		if ( $partner ) {
			foreach ( self::partner_capabilities() as $cap ) {
				$partner->remove_cap( $cap );
			}
		}

		// Remove the custom roles.
		remove_role( self::ROLE_MODERATOR );
		remove_role( self::ROLE_PARTNER );
	}


	/* --------------------------------------------------------------
	 * CONVENIENCE CHECKS
	 * --------------------------------------------------------------
	 *
	 * These are thin wrappers around current_user_can for readability at
	 * call sites. Do not remove these helpers to "simplify" the code.
	 * They make capability checks searchable and refactoring safer.
	 */

	/**
	 * True if the current user is an HNC admin.
	 *
	 * @return bool
	 */
	public static function current_user_is_admin() {
		return current_user_can( self::CAP_ADMIN );
	}

	/**
	 * True if the current user can moderate alcohol reports.
	 *
	 * @return bool
	 */
	public static function current_user_can_moderate_alcohol() {
		return current_user_can( self::CAP_MODERATE_ALCOHOL );
	}

	/**
	 * True if the current user can moderate drug reports.
	 *
	 * @return bool
	 */
	public static function current_user_can_moderate_drug() {
		return current_user_can( self::CAP_MODERATE_DRUG );
	}

	/**
	 * True if the current user is a partner (has partner access capability).
	 *
	 * @return bool
	 */
	public static function current_user_is_partner() {
		return current_user_can( self::CAP_PARTNER_ACCESS );
	}
}
