<?php
/**
 * Alcohol pipeline: public submission handler.
 *
 * This class is the single entry point for turning a raw public submission
 * into a row in the hnc_alcohol_reports table. It composes the Phase 2
 * utilities (HNC_Device, HNC_Geo, HNC_Media, HNC_Sanitizer, HNC_Codes,
 * HNC_Logger, HNC_Killswitch) into one end-to-end flow.
 *
 * The flow, in order:
 *
 *   1. Kill switch check. If active, return 503 style error.
 *   2. Device fingerprint validity and per-device rate limit.
 *   3. Per-IP rate limit.
 *   4. Honeypot and minimum form time check (cheap bot filter).
 *   5. Required field presence.
 *   6. GPS validity and bounding box (must be inside Nagaland).
 *   7. Photo validation: MIME, size, EXIF freshness. Strips EXIF and saves
 *      to the protected uploads directory with chmod 0600.
 *   8. Text sanitization: description, vehicle info (not used here but the
 *      sanitizer is shared across pipelines).
 *   9. Category and time pattern validation against the configured lists.
 *  10. District detection from GPS, with grid snap (50m by default) for
 *      public display coordinates.
 *  11. Auto merge: if an approved or pending pin with the same category
 *      already exists within the merge tolerance (100m by default), bump
 *      report_count on that pin instead of creating a new row. The uploaded
 *      photo is discarded since the existing pin is what the public sees.
 *  12. Insert the new row as status=pending with a unique public_code.
 *  13. Touch the device fingerprint and log the submission.
 *
 * All write operations are transactional only in the loose sense. WordPress
 * does not expose real DB transactions to plugins reliably, so we use a
 * save then cleanup approach: if an insert fails after a photo has been
 * saved, the photo is removed before returning.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Alcohol_Submit
 *
 * Stateless. All methods are static. Callers are:
 *   - The public REST endpoint /hnc/v1/alcohol/submit (wired by this class).
 *   - Internal test harnesses.
 *
 * Never call this class directly from admin code. The admin uses
 * HNC_Alcohol_Moderation instead.
 */
final class HNC_Alcohol_Submit {


	/* ------------------------------------------------------------------
	 * CONSTANTS
	 * ------------------------------------------------------------------ */

	/** Report status values. These are the authoritative strings stored in the status column. */
	const STATUS_PENDING  = 'pending';
	const STATUS_APPROVED = 'approved';
	const STATUS_REJECTED = 'rejected';
	const STATUS_HOLD     = 'hold';
	const STATUS_ARCHIVED = 'archived';

	/** Minimum seconds between form load and submit. Anything faster is a bot. */
	const MIN_FORM_SECONDS_DEFAULT = 8;

	/** Error codes returned via WP_Error. Stable strings for API consumers. */
	const ERR_PLATFORM_PAUSED   = 'hnc_platform_paused';
	const ERR_RATE_LIMIT        = 'hnc_rate_limit';
	const ERR_BAD_FINGERPRINT   = 'hnc_bad_fingerprint';
	const ERR_HONEYPOT          = 'hnc_honeypot_triggered';
	const ERR_TOO_FAST          = 'hnc_form_too_fast';
	const ERR_MISSING_FIELD     = 'hnc_missing_field';
	const ERR_BAD_GPS           = 'hnc_bad_gps';
	const ERR_OUTSIDE_NAGALAND  = 'hnc_outside_nagaland';
	const ERR_BAD_CATEGORY      = 'hnc_bad_category';
	const ERR_BAD_TIME_PATTERN  = 'hnc_bad_time_pattern';
	const ERR_NO_PHOTO          = 'hnc_no_photo';
	const ERR_PHOTO_INVALID     = 'hnc_photo_invalid';
	const ERR_PHOTO_STALE       = 'hnc_photo_stale';
	const ERR_INSERT_FAILED     = 'hnc_insert_failed';
	const ERR_CODE_ALLOC_FAILED = 'hnc_code_allocation_failed';


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register REST routes. Called from the main plugin file on plugins_loaded.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register the public REST endpoints this class exposes.
	 *
	 * The surface here is deliberately small. The full REST API with nonce
	 * handling and layered rate limiting arrives in Phase 6. What we need
	 * now is enough for the public submission form to work end to end.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/alcohol/submit',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_handle_submit' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/alcohol/categories',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_handle_categories' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/alcohol/time-patterns',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_handle_time_patterns' ),
				'permission_callback' => '__return_true',
			)
		);
	}


	/* ------------------------------------------------------------------
	 * REST CALLBACKS
	 * ------------------------------------------------------------------ */

	/**
	 * REST callback for POST /alcohol/submit.
	 *
	 * Expects a multipart form with fields: lat, lng, category, time_pattern,
	 * description, phone (optional), submission_mode, device_fingerprint,
	 * time_on_form_seconds, hnc_hp (honeypot). The photo comes in via
	 * $_FILES['photo'].
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function rest_handle_submit( $request ) {
		// Respect the kill switch. The utility does the work and returns a
		// proper 503 response when appropriate.
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}

		$params = $request->get_params();
		$files  = $request->get_file_params();

		$input = array(
			'lat'                   => isset( $params['lat'] ) ? $params['lat'] : '',
			'lng'                   => isset( $params['lng'] ) ? $params['lng'] : '',
			'category'              => isset( $params['category'] ) ? $params['category'] : '',
			'time_pattern'          => isset( $params['time_pattern'] ) ? $params['time_pattern'] : '',
			'description'           => isset( $params['description'] ) ? $params['description'] : '',
			'phone'                 => isset( $params['phone'] ) ? $params['phone'] : '',
			'submission_mode'       => isset( $params['submission_mode'] ) ? $params['submission_mode'] : 'anonymous',
			'member_code'           => isset( $params['member_code'] ) ? $params['member_code'] : '',
			'device_fingerprint'    => isset( $params['device_fingerprint'] ) ? $params['device_fingerprint'] : '',
			'time_on_form_seconds'  => isset( $params['time_on_form_seconds'] ) ? $params['time_on_form_seconds'] : 0,
			'hnc_hp'                => isset( $params['hnc_hp'] ) ? $params['hnc_hp'] : '',
		);

		$photo_file = isset( $files['photo'] ) ? $files['photo'] : null;

		$context = array(
			'ip'         => self::client_ip(),
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] )
				? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 )
				: '',
		);

		$result = self::create_report( $input, $photo_file, $context );

		if ( is_wp_error( $result ) ) {
			$status_map = array(
				self::ERR_PLATFORM_PAUSED   => 503,
				self::ERR_RATE_LIMIT        => 429,
				self::ERR_BAD_FINGERPRINT   => 400,
				self::ERR_HONEYPOT          => 400,
				self::ERR_TOO_FAST          => 400,
				self::ERR_MISSING_FIELD     => 400,
				self::ERR_BAD_GPS           => 400,
				self::ERR_OUTSIDE_NAGALAND  => 400,
				self::ERR_BAD_CATEGORY      => 400,
				self::ERR_BAD_TIME_PATTERN  => 400,
				self::ERR_NO_PHOTO          => 400,
				self::ERR_PHOTO_INVALID     => 400,
				self::ERR_PHOTO_STALE       => 400,
				self::ERR_INSERT_FAILED     => 500,
				self::ERR_CODE_ALLOC_FAILED => 500,
			);
			$code   = $result->get_error_code();
			$status = isset( $status_map[ $code ] ) ? $status_map[ $code ] : 400;
			return new WP_REST_Response(
				array(
					'success' => false,
					'code'    => $code,
					'message' => $result->get_error_message(),
				),
				$status
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $result,
			),
			200
		);
	}

	/**
	 * REST callback: list alcohol categories.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_handle_categories() {
		$raw  = get_option( 'hnc_alcohol_categories', '{}' );
		$list = json_decode( (string) $raw, true );
		if ( ! is_array( $list ) ) {
			$list = array();
		}
		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $list,
			),
			200
		);
	}

	/**
	 * REST callback: list configured time patterns.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_handle_time_patterns() {
		$raw  = get_option( 'hnc_time_patterns', '{}' );
		$list = json_decode( (string) $raw, true );
		if ( ! is_array( $list ) ) {
			$list = array();
		}
		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $list,
			),
			200
		);
	}


	/* ------------------------------------------------------------------
	 * MAIN FLOW
	 * ------------------------------------------------------------------ */

	/**
	 * Create a new alcohol report from raw inputs.
	 *
	 * This is the internal API. Callers pass in a cleaned-ish array of fields
	 * plus a file descriptor. Returns an array on success or a WP_Error on
	 * failure. Never throws.
	 *
	 * Success array shape:
	 * [
	 *     'code'           => 'ABCD-EFGH',
	 *     'status'         => 'pending',
	 *     'merged'         => false,
	 *     'merged_into_id' => null,
	 *     'district'       => 'Dimapur',
	 * ]
	 *
	 * Merge case shape:
	 * [
	 *     'code'           => '',           // No new code issued.
	 *     'status'         => 'merged',
	 *     'merged'         => true,
	 *     'merged_into_id' => 42,
	 *     'district'       => 'Dimapur',
	 * ]
	 *
	 * @param array      $input      Raw form fields.
	 * @param array|null $photo_file $_FILES style array for the photo, or null.
	 * @param array      $context    Context metadata (ip, user_agent).
	 * @return array|WP_Error
	 */
	public static function create_report( $input, $photo_file, $context = array() ) {
		global $wpdb;

		$input   = is_array( $input ) ? $input : array();
		$context = is_array( $context ) ? $context : array();

		/* ---- STEP 1: Bot filter (honeypot and form timing) ---- */

		$honeypot = isset( $input['hnc_hp'] ) ? (string) $input['hnc_hp'] : '';
		if ( '' !== trim( $honeypot ) ) {
			self::log_reject(
				self::ERR_HONEYPOT,
				array( 'honeypot_value' => substr( $honeypot, 0, 50 ) ),
				$context
			);
			return new WP_Error( self::ERR_HONEYPOT, __( 'Submission blocked.', 'helpnagaland-core' ) );
		}

		$min_seconds = (int) get_option( 'hnc_min_submit_seconds', self::MIN_FORM_SECONDS_DEFAULT );
		$form_time   = isset( $input['time_on_form_seconds'] ) ? (int) $input['time_on_form_seconds'] : 0;
		if ( $form_time < $min_seconds ) {
			self::log_reject(
				self::ERR_TOO_FAST,
				array(
					'form_seconds' => $form_time,
					'min_required' => $min_seconds,
				),
				$context
			);
			return new WP_Error(
				self::ERR_TOO_FAST,
				__( 'Please take a moment to review your report before submitting.', 'helpnagaland-core' )
			);
		}

		/* ---- STEP 2: Device fingerprint ---- */

		$fp_client = isset( $input['device_fingerprint'] ) ? (string) $input['device_fingerprint'] : '';
		if ( ! class_exists( 'HNC_Device' ) || ! HNC_Device::is_valid_client_fingerprint( $fp_client ) ) {
			self::log_reject( self::ERR_BAD_FINGERPRINT, array(), $context );
			return new WP_Error(
				self::ERR_BAD_FINGERPRINT,
				__( 'Your browser did not provide a valid session token. Please reload and try again.', 'helpnagaland-core' )
			);
		}
		$device_hash = HNC_Device::server_hash( $fp_client );

		/* ---- STEP 3: Rate limits ---- */

		if ( ! HNC_Device::may_submit( $device_hash ) ) {
			self::log_reject(
				self::ERR_RATE_LIMIT,
				array( 'scope' => 'device' ),
				$context
			);
			return new WP_Error(
				self::ERR_RATE_LIMIT,
				__( 'You have reached the submission limit for today. Please try again tomorrow.', 'helpnagaland-core' )
			);
		}

		$ip = isset( $context['ip'] ) ? (string) $context['ip'] : '';
		if ( '' !== $ip && ! HNC_Device::ip_may_request( $ip ) ) {
			self::log_reject(
				self::ERR_RATE_LIMIT,
				array( 'scope' => 'ip' ),
				$context
			);
			return new WP_Error(
				self::ERR_RATE_LIMIT,
				__( 'Too many requests from your network. Please wait a few minutes.', 'helpnagaland-core' )
			);
		}

		/* ---- STEP 4: Required field presence ---- */

		foreach ( array( 'lat', 'lng', 'category', 'time_pattern' ) as $req ) {
			if ( ! isset( $input[ $req ] ) || '' === trim( (string) $input[ $req ] ) ) {
				self::log_reject(
					self::ERR_MISSING_FIELD,
					array( 'field' => $req ),
					$context
				);
				return new WP_Error(
					self::ERR_MISSING_FIELD,
					sprintf(
						/* translators: %s: field name */
						__( 'Missing required field: %s', 'helpnagaland-core' ),
						$req
					)
				);
			}
		}

		/* ---- STEP 5: GPS validity and bounding box ---- */

		$lat_raw = (float) $input['lat'];
		$lng_raw = (float) $input['lng'];

		if ( $lat_raw <= -90 || $lat_raw >= 90 || $lng_raw <= -180 || $lng_raw >= 180 ) {
			self::log_reject( self::ERR_BAD_GPS, array( 'lat' => $lat_raw, 'lng' => $lng_raw ), $context );
			return new WP_Error( self::ERR_BAD_GPS, __( 'Invalid GPS coordinates.', 'helpnagaland-core' ) );
		}

		if ( ! class_exists( 'HNC_Geo' ) || ! HNC_Geo::is_in_nagaland( $lat_raw, $lng_raw ) ) {
			self::log_reject( self::ERR_OUTSIDE_NAGALAND, array( 'lat' => $lat_raw, 'lng' => $lng_raw ), $context );
			return new WP_Error(
				self::ERR_OUTSIDE_NAGALAND,
				__( 'This platform only accepts reports from inside Nagaland.', 'helpnagaland-core' )
			);
		}

		/* ---- STEP 6: Photo validation and storage (ALCOHOL REQUIRES LIVE PHOTO) ---- */

		if ( ! is_array( $photo_file ) || empty( $photo_file['tmp_name'] ) ) {
			self::log_reject( self::ERR_NO_PHOTO, array(), $context );
			return new WP_Error(
				self::ERR_NO_PHOTO,
				__( 'A photo is required. Please take a photo with your camera before submitting.', 'helpnagaland-core' )
			);
		}

		if ( ! class_exists( 'HNC_Media' ) ) {
			return new WP_Error( self::ERR_PHOTO_INVALID, __( 'Photo subsystem unavailable.', 'helpnagaland-core' ) );
		}

		$photo_result = HNC_Media::handle_alcohol_upload( $photo_file );
		if ( is_wp_error( $photo_result ) ) {
			$map = array(
				'hnc_media_freshness' => self::ERR_PHOTO_STALE,
			);
			$err_code = $photo_result->get_error_code();
			$mapped   = isset( $map[ $err_code ] ) ? $map[ $err_code ] : self::ERR_PHOTO_INVALID;
			self::log_reject(
				$mapped,
				array( 'media_error' => $err_code, 'media_message' => $photo_result->get_error_message() ),
				$context
			);
			return new WP_Error( $mapped, $photo_result->get_error_message() );
		}

		// photo_result is expected to be array with keys: uuid, hash, path, mime
		$photo_uuid = isset( $photo_result['uuid'] ) ? (string) $photo_result['uuid'] : '';
		$photo_hash = isset( $photo_result['hash'] ) ? (string) $photo_result['hash'] : '';

		/* ---- STEP 7: Category and time pattern ---- */

		$category = '';
		if ( class_exists( 'HNC_Sanitizer' ) ) {
			$category = HNC_Sanitizer::category_key( $input['category'], 'alcohol' );
		}
		if ( '' === $category ) {
			self::cleanup_photo( $photo_uuid, 'alcohol' );
			self::log_reject( self::ERR_BAD_CATEGORY, array( 'raw' => substr( (string) $input['category'], 0, 40 ) ), $context );
			return new WP_Error( self::ERR_BAD_CATEGORY, __( 'Please select a valid category.', 'helpnagaland-core' ) );
		}

		$time_pattern = HNC_Sanitizer::time_pattern( $input['time_pattern'] );
		if ( '' === $time_pattern ) {
			self::cleanup_photo( $photo_uuid, 'alcohol' );
			self::log_reject( self::ERR_BAD_TIME_PATTERN, array( 'raw' => substr( (string) $input['time_pattern'], 0, 40 ) ), $context );
			return new WP_Error( self::ERR_BAD_TIME_PATTERN, __( 'Please select a valid time pattern.', 'helpnagaland-core' ) );
		}

		/* ---- STEP 8: Description sanitize ---- */

		$description_clean = HNC_Sanitizer::alcohol_description( isset( $input['description'] ) ? $input['description'] : '' );

		/* ---- STEP 9: Grid snap and district detection ---- */

		$snapped = HNC_Geo::snap_to_grid( $lat_raw, $lng_raw );
		$lat     = isset( $snapped['lat'] ) ? (float) $snapped['lat'] : $lat_raw;
		$lng     = isset( $snapped['lng'] ) ? (float) $snapped['lng'] : $lng_raw;

		$district = (string) HNC_Geo::detect_district( $lat_raw, $lng_raw );

		/* ---- STEP 10: Auto merge ---- */

		$merge_target = self::find_merge_target( $lat, $lng, $category );
		if ( null !== $merge_target ) {
			// Bump the existing pin. Discard the photo since we do not store
			// duplicate photos and the existing pin already has one (or had one
			// before photo retention). This preserves the single authoritative
			// public location and counts the new report.
			self::cleanup_photo( $photo_uuid, 'alcohol' );

			/*
			 * Atomic merge-count increment. MySQL/InnoDB row-locks on
			 * the UPDATE, so two concurrent merges into the same pin
			 * will both increment correctly. The stale
			 * $merge_target->report_count read before the UPDATE must
			 * NOT be trusted for the audit entry — we re-read the
			 * canonical value after the write so the log reflects what
			 * the database actually holds.
			 */
			$table   = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
			$updated = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table} SET report_count = report_count + 1 WHERE id = %d",
					$merge_target->id
				)
			);

			// Touch device either way so limits still count.
			HNC_Device::touch( $device_hash );

			if ( class_exists( 'HNC_Logger' ) ) {
				$canonical_count = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT report_count FROM {$table} WHERE id = %d",
						$merge_target->id
					)
				);
				HNC_Logger::log_alcohol(
					HNC_Logger::ACTION_MERGE,
					(int) $merge_target->id,
					array(
						'new_count' => $canonical_count,
						'lat'       => $lat,
						'lng'       => $lng,
						'category'  => $category,
						'district'  => $district,
					)
				);
			}

			return array(
				'code'           => '',
				'status'         => 'merged',
				'merged'         => true,
				'merged_into_id' => (int) $merge_target->id,
				'district'       => $district,
			);
		}

		/* ---- STEP 11: Allocate unique public code ---- */

		$public_code = '';
		if ( class_exists( 'HNC_Codes' ) ) {
			$public_code = HNC_Codes::generate();
		}
		if ( '' === $public_code ) {
			self::cleanup_photo( $photo_uuid, 'alcohol' );
			self::log_reject( self::ERR_CODE_ALLOC_FAILED, array(), $context );
			return new WP_Error( self::ERR_CODE_ALLOC_FAILED, __( 'Could not allocate a tracking code. Please try again.', 'helpnagaland-core' ) );
		}

		/* ---- STEP 12: Insert row ---- */

		// Optional Premium Member Code: no gate, just a flag for the public map.
		$member_code_norm = isset( $input['member_code'] ) ? trim( (string) $input['member_code'] ) : '';
		$is_member        = ( '' !== $member_code_norm && class_exists( 'HNC_Payment' )
			&& is_callable( array( 'HNC_Payment', 'is_active_member_code' ) )
			&& HNC_Payment::is_active_member_code( $member_code_norm ) );

		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		$row   = array(
			'public_code'          => $public_code,
			'lat'                  => $lat,
			'lng'                  => $lng,
			'lat_raw'              => $lat_raw,
			'lng_raw'              => $lng_raw,
			'district'             => $district,
			'category'             => $category,
			'description'          => $description_clean,
			'time_pattern'         => $time_pattern,
			'photo_uuid'           => '' !== $photo_uuid ? $photo_uuid : null,
			'photo_hash'           => '' !== $photo_hash ? $photo_hash : null,
			'device_hash'          => $device_hash,
			'status'               => self::STATUS_PENDING,
			'verified_by_operator' => 0,
			'merged_into'          => null,
			'report_count'         => 1,
			'phone_vault_id'       => null,
			'submitted_by_member'  => $is_member ? 1 : 0,
			'submitted_at'         => current_time( 'mysql' ),
		);

		$formats = array(
			'%s', // public_code
			'%f', // lat
			'%f', // lng
			'%f', // lat_raw
			'%f', // lng_raw
			'%s', // district
			'%s', // category
			'%s', // description
			'%s', // time_pattern
			'%s', // photo_uuid
			'%s', // photo_hash
			'%s', // device_hash
			'%s', // status
			'%d', // verified_by_operator
			'%d', // merged_into (null acceptable with %d)
			'%d', // report_count
			'%d', // phone_vault_id (null acceptable with %d)
			'%d', // submitted_by_member
			'%s', // submitted_at
		);

		$ok = $wpdb->insert( $table, $row, $formats );
		if ( ! $ok ) {
			self::cleanup_photo( $photo_uuid, 'alcohol' );
			self::log_reject(
				self::ERR_INSERT_FAILED,
				array( 'db_error' => $wpdb->last_error ),
				$context
			);
			return new WP_Error( self::ERR_INSERT_FAILED, __( 'Could not save your report. Please try again.', 'helpnagaland-core' ) );
		}

		$new_id = (int) $wpdb->insert_id;

		/* ---- STEP 13: Touch device and log success ---- */

		HNC_Device::touch( $device_hash );

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_alcohol(
				HNC_Logger::ACTION_SUBMIT,
				$new_id,
				array(
					'code'     => $public_code,
					'lat'      => $lat,
					'lng'      => $lng,
					'district' => $district,
					'category' => $category,
				)
			);
		}

		return array(
			'code'           => $public_code,
			'status'         => self::STATUS_PENDING,
			'merged'         => false,
			'merged_into_id' => null,
			'district'       => $district,
		);
	}


	/* ------------------------------------------------------------------
	 * HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Find an existing pin within merge tolerance of the given coordinates
	 * that shares the same category. Only pins with status approved or pending
	 * are eligible for merge. Rejected, hold, and archived are skipped.
	 *
	 * Returns the candidate row object, or null.
	 *
	 * @param float  $lat      Grid-snapped latitude.
	 * @param float  $lng      Grid-snapped longitude.
	 * @param string $category Category key.
	 * @return object|null
	 */
	private static function find_merge_target( $lat, $lng, $category ) {
		global $wpdb;

		if ( ! class_exists( 'HNC_Geo' ) ) {
			return null;
		}

		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		// Prefilter with a bounding box so we do not haversine the whole table.
		// A generous 0.01 degree window (roughly 1.1km) captures anything the
		// 100m tolerance could possibly match.
		$sql = $wpdb->prepare(
			"SELECT id, lat, lng, category, status, report_count
			 FROM {$table}
			 WHERE category = %s
			   AND status IN ('pending', 'approved')
			   AND lat BETWEEN %f AND %f
			   AND lng BETWEEN %f AND %f
			 LIMIT 50",
			$category,
			$lat - 0.01,
			$lat + 0.01,
			$lng - 0.01,
			$lng + 0.01
		);
		$candidates = $wpdb->get_results( $sql );
		if ( empty( $candidates ) ) {
			return null;
		}

		// Among candidates, pick the closest one that is within merge tolerance.
		$best      = null;
		$best_dist = PHP_FLOAT_MAX;
		foreach ( $candidates as $row ) {
			$d = HNC_Geo::haversine_meters( $lat, $lng, (float) $row->lat, (float) $row->lng );
			if ( HNC_Geo::gps_pin_within_tolerance( $lat, $lng, (float) $row->lat, (float) $row->lng ) && $d < $best_dist ) {
				$best      = $row;
				$best_dist = $d;
			}
		}

		return $best;
	}

	/**
	 * Safely delete a stored alcohol photo file. Called on error paths and
	 * when a submission is merged (the uploaded photo becomes unused).
	 *
	 * @param string $uuid     The stored UUID. Empty is a no-op.
	 * @param string $pipeline 'alcohol' or 'drug'.
	 * @return void
	 */
	private static function cleanup_photo( $uuid, $pipeline ) {
		if ( '' === (string) $uuid || ! class_exists( 'HNC_Media' ) ) {
			return;
		}
		HNC_Media::delete_by_uuid( $pipeline, $uuid );
	}

	/**
	 * Extract a client IP safely. Honors one common proxy header but only
	 * when the server is behind a trusted proxy. In ambiguous cases we
	 * return REMOTE_ADDR.
	 *
	 * @return string
	 */
	private static function client_ip() {
		if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
			return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
		}
		return '';
	}

	/**
	 * Short helper: log a rejection with the standard fields.
	 *
	 * @param string $code    Error code.
	 * @param array  $meta    Extra fields.
	 * @param array  $context Context (ip, user_agent).
	 * @return void
	 */
	private static function log_reject( $code, $meta, $context ) {
		if ( ! class_exists( 'HNC_Logger' ) ) {
			return;
		}
		$payload = array_merge( array( 'reject_code' => $code ), is_array( $meta ) ? $meta : array() );
		HNC_Logger::log_alcohol( 'submit_reject', $payload, is_array( $context ) ? $context : array() );
	}
}
