<?php
/**
 * Alcohol pipeline: public map data provider.
 *
 * Read-only class that exposes the approved alcohol pins for public
 * consumption. Every caller of this class must assume the output is
 * shown to anyone on the internet, including hostile actors.
 *
 * What this class DOES expose publicly:
 *   - Grid-snapped lat/lng (50m precision, never raw GPS).
 *   - District.
 *   - Category key (with label via categories endpoint).
 *   - Time pattern key.
 *   - Report count (aggregated merge count).
 *   - verified_by_operator flag.
 *   - first_reported_date (day precision, not timestamp).
 *
 * What this class NEVER exposes publicly:
 *   - Photo URL or UUID.
 *   - Free-text description (moderator-only).
 *   - Raw GPS coordinates.
 *   - Submitter device hash or phone.
 *   - Exact submission timestamp.
 *   - Moderator ID, rejection reason, or any status other than approved.
 *   - Any rejected, pending, held, merged, or archived records.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Alcohol_Map
 */
final class HNC_Alcohol_Map {


	/* ------------------------------------------------------------------
	 * CONSTANTS
	 * ------------------------------------------------------------------ */

	/** Max results per pin query (hard ceiling). */
	const MAX_PIN_LIMIT = 5000;

	/** Default pin query limit. */
	const DEFAULT_PIN_LIMIT = 2000;

	/** REST response cache duration in seconds. */
	const CACHE_TTL_SECONDS = 300;


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register REST routes.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register public map endpoints.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/alcohol/pins',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_handle_pins' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'district' => array(
						'required' => false,
						'type'     => 'string',
					),
					'category' => array(
						'required' => false,
						'type'     => 'string',
					),
					'limit' => array(
						'required' => false,
						'type'     => 'integer',
					),
				),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/alcohol/district-stats',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_handle_district_stats' ),
				'permission_callback' => '__return_true',
			)
		);
	}


	/* ------------------------------------------------------------------
	 * REST CALLBACKS
	 * ------------------------------------------------------------------ */

	/**
	 * GET /alcohol/pins.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_handle_pins( $request ) {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}

		$filters = array(
			'district' => (string) $request->get_param( 'district' ),
			'category' => (string) $request->get_param( 'category' ),
			'limit'    => (int) $request->get_param( 'limit' ),
		);

		$pins = self::public_pins( $filters );

		$response = new WP_REST_Response(
			array(
				'success' => true,
				'count'   => count( $pins ),
				'data'    => $pins,
			),
			200
		);
		$response->header( 'Cache-Control', 'public, max-age=' . self::CACHE_TTL_SECONDS );
		return $response;
	}

	/**
	 * GET /alcohol/district-stats.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_handle_district_stats() {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}

		$stats = self::district_stats();
		$response = new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $stats,
			),
			200
		);
		$response->header( 'Cache-Control', 'public, max-age=' . self::CACHE_TTL_SECONDS );
		return $response;
	}


	/* ------------------------------------------------------------------
	 * PUBLIC QUERIES
	 * ------------------------------------------------------------------ */

	/**
	 * Return the public list of approved, unmerged alcohol pins.
	 *
	 * Output fields per pin (public-safe only):
	 *   id, lat, lng, district, category, time_pattern, report_count,
	 *   verified_by_operator, first_reported_date (YYYY-MM-DD).
	 *
	 * @param array $filters Optional district, category, limit.
	 * @return array Array of associative arrays.
	 */
	public static function public_pins( $filters = array() ) {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$district = isset( $filters['district'] ) ? trim( (string) $filters['district'] ) : '';
		$category = isset( $filters['category'] ) ? trim( (string) $filters['category'] ) : '';
		$limit    = isset( $filters['limit'] ) ? (int) $filters['limit'] : 0;

		if ( $limit <= 0 ) {
			$limit = self::DEFAULT_PIN_LIMIT;
		}
		$limit = min( self::MAX_PIN_LIMIT, max( 1, $limit ) );

		$where  = array( 'status = %s', '(merged_into IS NULL OR merged_into = 0)' );
		$params = array( HNC_Alcohol_Submit::STATUS_APPROVED );

		if ( '' !== $district ) {
			$where[]  = 'district = %s';
			$params[] = $district;
		}
		if ( '' !== $category ) {
			$where[]  = 'category = %s';
			$params[] = $category;
		}

		$where_sql = ' WHERE ' . implode( ' AND ', $where );

		$sql = "SELECT id, lat, lng, district, category, time_pattern,
				report_count, verified_by_operator, submitted_by_member, submitted_at
			FROM {$table}
			{$where_sql}
			ORDER BY submitted_at DESC
			LIMIT %d";

		$params[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );
		if ( ! is_array( $rows ) ) {
			return array();
		}

		// Map to public-safe shape. Strip exact timestamp, keep date only.
		$out = array();
		foreach ( $rows as $r ) {
			$date = substr( (string) $r->submitted_at, 0, 10 );
			$out[] = array(
				'id'                   => (int) $r->id,
				'lat'                  => round( (float) $r->lat, 7 ),
				'lng'                  => round( (float) $r->lng, 7 ),
				'district'             => (string) $r->district,
				'category'             => (string) $r->category,
				'time_pattern'         => (string) $r->time_pattern,
				'report_count'         => (int) $r->report_count,
				'verified_by_operator' => ( 1 === (int) $r->verified_by_operator ),
				'submitted_by_member'  => ( isset( $r->submitted_by_member ) && 1 === (int) $r->submitted_by_member ),
				'first_reported_date'  => $date,
			);
		}
		return $out;
	}

	/**
	 * Aggregate counts of approved pins per district. Safe for public.
	 *
	 * @return array District name => count map.
	 */
	public static function district_stats() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT district, COUNT(*) AS cnt
				FROM {$table}
				WHERE status = %s
				  AND (merged_into IS NULL OR merged_into = 0)
				GROUP BY district
				ORDER BY cnt DESC",
				HNC_Alcohol_Submit::STATUS_APPROVED
			)
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $r ) {
			$out[] = array(
				'district' => (string) $r->district,
				'count'    => (int) $r->cnt,
			);
		}
		return $out;
	}

	/**
	 * Count of approved, unmerged pins in total. Used by transparency page
	 * and home banners.
	 *
	 * @return int
	 */
	public static function total_visible_count() {
		global $wpdb;
		$table = $wpdb->prefix . HNC_TABLE_PREFIX . 'alcohol_reports';
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table}
				WHERE status = %s
				  AND (merged_into IS NULL OR merged_into = 0)",
				HNC_Alcohol_Submit::STATUS_APPROVED
			)
		);
	}
}
