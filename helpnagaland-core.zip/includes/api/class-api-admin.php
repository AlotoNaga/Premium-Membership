<?php
/**
 * API Admin: authenticated REST endpoints for moderation and operations.
 *
 * This class registers every admin-only endpoint the Phase 7 admin UI
 * (and external tooling) will consume. Each endpoint is a thin wrapper
 * around the static methods in the Phase 3, 4, and 5 domain classes.
 * The wrappers add:
 *
 *   - Nonce verification via HNC_Api_Nonce::cap().
 *   - Capability check per action.
 *   - Admin rate-limit via HNC_Api_Ratelimit::admin_user().
 *   - Uniform JSON response shape.
 *   - HTTP status code translation from domain error codes.
 *
 * The endpoint layout mirrors the domain layout: /admin/alcohol/*,
 * /admin/drug/*, /admin/vault/*, /admin/transparency/*,
 * /admin/killswitch/*, /admin/audit/*.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Api_Admin
 */
final class HNC_Api_Admin {


	/* ------------------------------------------------------------------
	 * BOOTSTRAP
	 * ------------------------------------------------------------------ */

	/**
	 * Register REST routes on rest_api_init.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register every admin endpoint.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		self::register_alcohol_routes();
		self::register_drug_routes();
		self::register_vault_routes();
		self::register_transparency_routes();
		self::register_killswitch_routes();
		self::register_audit_routes();
	}


	/* ------------------------------------------------------------------
	 * ALCOHOL ROUTES
	 * ------------------------------------------------------------------ */

	/**
	 * Register alcohol moderation endpoints.
	 *
	 * @return void
	 */
	private static function register_alcohol_routes() {
		$cap = 'hnc_moderate_alcohol';

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/alcohol/queue',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_alcohol_queue' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
				'args'                => self::queue_args( array(
					'pending', 'approved', 'rejected', 'hold', 'archived', 'all',
				) ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/alcohol/report/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_alcohol_report' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/alcohol/photo/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_alcohol_photo' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		foreach ( array( 'approve', 'reject', 'hold', 'unhold', 'archive', 'verify' ) as $action ) {
			register_rest_route(
				HNC_API_NAMESPACE,
				'/admin/alcohol/' . $action . '/(?P<id>\d+)',
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'rest_alcohol_' . $action ),
					'permission_callback' => HNC_Api_Nonce::cap( $cap ),
				)
			);
		}

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/alcohol/merge',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_alcohol_merge' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/alcohol/unmerge/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_alcohol_unmerge' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);
	}

	/**
	 * GET /admin/alcohol/queue
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_alcohol_queue( $request ) {
		$rl = HNC_Api_Ratelimit::admin_user( 'alcohol_queue' );
		if ( null !== $rl ) { return self::err( $rl ); }

		$filters = array(
			'status'   => (string) $request->get_param( 'status' ),
			'district' => (string) $request->get_param( 'district' ),
			'category' => (string) $request->get_param( 'category' ),
			'page'     => (int) $request->get_param( 'page' ),
			'per_page' => (int) $request->get_param( 'per_page' ),
			'sort'     => (string) $request->get_param( 'sort' ),
		);

		$result = HNC_Alcohol_Moderation::get_queue( $filters );
		return self::ok( $result );
	}

	/**
	 * GET /admin/alcohol/report/{id}
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_alcohol_report( $request ) {
		$id  = (int) $request->get_param( 'id' );
		$row = HNC_Alcohol_Moderation::get_report( $id );
		if ( null === $row ) {
			return self::err_404( 'Report not found.' );
		}
		return self::ok( array( 'report' => $row ) );
	}

	/**
	 * GET /admin/alcohol/photo/{id}
	 *
	 * Streams the live photo for an alcohol report inline so the
	 * moderation modal can render it in an <img>. Capability-gated,
	 * rate-limited, and audit-logged so every view is traceable.
	 *
	 * Does NOT return — HNC_Media::stream() sets binary headers and
	 * exits. If the photo is missing (already retention-purged) a 404
	 * is sent and the method exits.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|void
	 */
	public static function rest_alcohol_photo( $request ) {
		if ( class_exists( 'HNC_Api_Ratelimit' ) ) {
			$rl = HNC_Api_Ratelimit::admin_user( 'alcohol_photo', 120, 60 );
			if ( null !== $rl ) {
				return self::err( $rl );
			}
		}

		$id = (int) $request->get_param( 'id' );
		if ( $id <= 0 ) {
			return self::err_404( 'Photo not available.' );
		}

		$row = HNC_Alcohol_Moderation::get_report( $id );
		if ( null === $row || empty( $row->photo_uuid ) ) {
			return self::err_404( 'Photo not available.' );
		}

		$relative = HNC_Media::find_relative_by_uuid( 'alcohol', (string) $row->photo_uuid );
		if ( '' === $relative ) {
			return self::err_404( 'Photo not available.' );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_alcohol(
				HNC_Logger::ACTION_MEDIA_VIEW,
				$id,
				array( 'kind' => 'photo' )
			);
		}

		HNC_Media::stream( $relative );
		// stream() calls exit; this return is unreachable but keeps
		// static analysers happy.
		exit;
	}

	/** POST /admin/alcohol/approve/{id} */
	public static function rest_alcohol_approve( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$note   = (string) $request->get_param( 'note' );
		$result = HNC_Alcohol_Moderation::approve( $id, $note );
		return self::result_response( $result, array( 'id' => $id, 'status' => 'approved' ) );
	}

	/** POST /admin/alcohol/reject/{id} */
	public static function rest_alcohol_reject( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$reason = (string) $request->get_param( 'reason' );
		$result = HNC_Alcohol_Moderation::reject( $id, $reason );
		return self::result_response( $result, array( 'id' => $id, 'status' => 'rejected' ) );
	}

	/** POST /admin/alcohol/hold/{id} */
	public static function rest_alcohol_hold( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$note   = (string) $request->get_param( 'note' );
		$result = HNC_Alcohol_Moderation::hold( $id, $note );
		return self::result_response( $result, array( 'id' => $id, 'status' => 'hold' ) );
	}

	/** POST /admin/alcohol/unhold/{id} */
	public static function rest_alcohol_unhold( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = HNC_Alcohol_Moderation::unhold( $id );
		return self::result_response( $result, array( 'id' => $id, 'status' => 'pending' ) );
	}

	/** POST /admin/alcohol/archive/{id} */
	public static function rest_alcohol_archive( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = HNC_Alcohol_Moderation::archive( $id );
		return self::result_response( $result, array( 'id' => $id, 'status' => 'archived' ) );
	}

	/** POST /admin/alcohol/verify/{id} */
	public static function rest_alcohol_verify( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = HNC_Alcohol_Moderation::verify_operator( $id );
		return self::result_response( $result, array( 'id' => $id, 'verified_by_operator' => true ) );
	}

	/** POST /admin/alcohol/merge (body: source, target) */
	public static function rest_alcohol_merge( $request ) {
		$source = (int) $request->get_param( 'source' );
		$target = (int) $request->get_param( 'target' );
		$result = HNC_Alcohol_Moderation::merge( $source, $target );
		return self::result_response( $result, array( 'source' => $source, 'target' => $target ) );
	}

	/** POST /admin/alcohol/unmerge/{id} */
	public static function rest_alcohol_unmerge( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = HNC_Alcohol_Moderation::unmerge( $id );
		return self::result_response( $result, array( 'id' => $id ) );
	}


	/* ------------------------------------------------------------------
	 * DRUG ROUTES
	 * ------------------------------------------------------------------ */

	/**
	 * Register drug moderation endpoints.
	 *
	 * @return void
	 */
	private static function register_drug_routes() {
		$cap = 'hnc_moderate_drug';

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/drug/queue',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_drug_queue' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
				'args'                => self::queue_args( array(
					'pending', 'approved', 'rejected', 'hold', 'resolved', 'archived', 'all',
				) ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/drug/report/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_drug_report' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/drug/media/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_drug_media' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		foreach ( array( 'approve', 'reject', 'hold', 'unhold', 'resolve', 'archive' ) as $action ) {
			register_rest_route(
				HNC_API_NAMESPACE,
				'/admin/drug/' . $action . '/(?P<id>\d+)',
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'rest_drug_' . $action ),
					'permission_callback' => HNC_Api_Nonce::cap( $cap ),
				)
			);
		}

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/drug/severity/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_drug_severity' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/drug/forward/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_drug_forward' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_forward_drug' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/drug/forward-history/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_drug_forward_history' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_forward_drug' ),
			)
		);
	}

	/** GET /admin/drug/queue */
	public static function rest_drug_queue( $request ) {
		$rl = HNC_Api_Ratelimit::admin_user( 'drug_queue' );
		if ( null !== $rl ) { return self::err( $rl ); }

		$filters = array(
			'status'       => (string) $request->get_param( 'status' ),
			'district'     => (string) $request->get_param( 'district' ),
			'category'     => (string) $request->get_param( 'category' ),
			'severity_min' => (int) $request->get_param( 'severity_min' ),
			'page'         => (int) $request->get_param( 'page' ),
			'per_page'     => (int) $request->get_param( 'per_page' ),
		);
		$result = HNC_Drug_Moderation::get_queue( $filters );
		if ( is_wp_error( $result ) ) { return self::err( $result ); }
		return self::ok( $result );
	}

	/** GET /admin/drug/report/{id} */
	public static function rest_drug_report( $request ) {
		$id  = (int) $request->get_param( 'id' );
		$row = HNC_Drug_Moderation::get_report( $id );
		if ( is_wp_error( $row ) ) { return self::err( $row ); }
		return self::ok( array( 'report' => $row ) );
	}

	/**
	 * GET /admin/drug/media/{id}
	 *
	 * Streams the optional photo or video attached to a drug report
	 * inline so the moderation modal can render it. Drug reports
	 * allow both images and videos (see HNC_Media::DRUG_ALLOWED_MIMES);
	 * the detected MIME type is used as-is in Content-Type so the
	 * browser picks <img> vs <video> correctly.
	 *
	 * Capability-gated, rate-limited, audit-logged. Does not return —
	 * HNC_Media::stream() exits.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|void
	 */
	public static function rest_drug_media( $request ) {
		if ( class_exists( 'HNC_Api_Ratelimit' ) ) {
			$rl = HNC_Api_Ratelimit::admin_user( 'drug_media', 120, 60 );
			if ( null !== $rl ) {
				return self::err( $rl );
			}
		}

		$id = (int) $request->get_param( 'id' );
		if ( $id <= 0 ) {
			return self::err_404( 'Media not available.' );
		}

		$row = HNC_Drug_Moderation::get_report( $id );
		if ( is_wp_error( $row ) || null === $row || empty( $row->media_uuid ) ) {
			return self::err_404( 'Media not available.' );
		}

		$relative = HNC_Media::find_relative_by_uuid( 'drug', (string) $row->media_uuid );
		if ( '' === $relative ) {
			return self::err_404( 'Media not available.' );
		}

		if ( class_exists( 'HNC_Logger' ) ) {
			HNC_Logger::log_drug(
				HNC_Logger::ACTION_MEDIA_VIEW,
				$id,
				array( 'kind' => ( isset( $row->media_type ) && '' !== (string) $row->media_type ) ? (string) $row->media_type : 'media' )
			);
		}

		HNC_Media::stream( $relative );
		exit;
	}

	/** POST /admin/drug/approve/{id} */
	public static function rest_drug_approve( $request ) {
		$id   = (int) $request->get_param( 'id' );
		$note = (string) $request->get_param( 'note' );
		$r    = HNC_Drug_Moderation::approve( $id, $note );
		return self::result_response( $r, array( 'id' => $id, 'status' => 'approved' ) );
	}

	/** POST /admin/drug/reject/{id} */
	public static function rest_drug_reject( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$reason = (string) $request->get_param( 'reason' );
		$r      = HNC_Drug_Moderation::reject( $id, $reason );
		return self::result_response( $r, array( 'id' => $id, 'status' => 'rejected' ) );
	}

	/** POST /admin/drug/hold/{id} */
	public static function rest_drug_hold( $request ) {
		$id   = (int) $request->get_param( 'id' );
		$note = (string) $request->get_param( 'note' );
		$r    = HNC_Drug_Moderation::hold( $id, $note );
		return self::result_response( $r, array( 'id' => $id, 'status' => 'hold' ) );
	}

	/** POST /admin/drug/unhold/{id} */
	public static function rest_drug_unhold( $request ) {
		$id = (int) $request->get_param( 'id' );
		$r  = HNC_Drug_Moderation::unhold( $id );
		return self::result_response( $r, array( 'id' => $id, 'status' => 'pending' ) );
	}

	/** POST /admin/drug/resolve/{id} */
	public static function rest_drug_resolve( $request ) {
		$id   = (int) $request->get_param( 'id' );
		$note = (string) $request->get_param( 'note' );
		$r    = HNC_Drug_Moderation::resolve( $id, $note );
		return self::result_response( $r, array( 'id' => $id, 'status' => 'resolved' ) );
	}

	/** POST /admin/drug/archive/{id} */
	public static function rest_drug_archive( $request ) {
		$id = (int) $request->get_param( 'id' );
		$r  = HNC_Drug_Moderation::archive( $id );
		return self::result_response( $r, array( 'id' => $id, 'status' => 'archived' ) );
	}

	/** POST /admin/drug/severity/{id} (body: severity=1..5) */
	public static function rest_drug_severity( $request ) {
		$id       = (int) $request->get_param( 'id' );
		$severity = (int) $request->get_param( 'severity' );
		$r        = HNC_Drug_Moderation::set_severity( $id, $severity );
		return self::result_response( $r, array( 'id' => $id, 'severity' => $severity ) );
	}

	/** POST /admin/drug/forward/{id} (body: partner, note) */
	public static function rest_drug_forward( $request ) {
		$id      = (int) $request->get_param( 'id' );
		$partner = (string) $request->get_param( 'partner' );
		$note    = (string) $request->get_param( 'note' );
		$r       = HNC_Drug_Forward::forward( $id, $partner, $note );
		return self::result_response( $r, array( 'id' => $id, 'partner' => $partner ) );
	}

	/** GET /admin/drug/forward-history/{id} */
	public static function rest_drug_forward_history( $request ) {
		$id      = (int) $request->get_param( 'id' );
		$history = HNC_Drug_Forward::get_history( $id );
		return self::ok( array( 'history' => $history ) );
	}


	/* ------------------------------------------------------------------
	 * VAULT ROUTES
	 * ------------------------------------------------------------------ */

	/**
	 * Register phone-vault moderation endpoints.
	 *
	 * @return void
	 */
	private static function register_vault_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/vault/reveal/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_vault_reveal' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_reveal_phone' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/vault/consent/(?P<id>\d+)',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_vault_consent' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_manage_vault' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/vault/delete/(?P<id>\d+)',
			array(
				'methods'             => 'DELETE',
				'callback'            => array( __CLASS__, 'rest_vault_delete' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_manage_vault' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/vault/counts',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_vault_counts' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_manage_vault' ),
			)
		);
	}

	/** POST /admin/vault/reveal/{id} (body: second_consent=true, reason) */
	public static function rest_vault_reveal( $request ) {
		// Tight per-user rate limit. Reveal should be a deliberate,
		// infrequent action.
		$rl = HNC_Api_Ratelimit::admin_user( 'vault_reveal', 30, 60 );
		if ( null !== $rl ) { return self::err( $rl ); }

		$id             = (int) $request->get_param( 'id' );
		$second_consent = (bool) $request->get_param( 'second_consent' );

		if ( ! $second_consent ) {
			return self::err(
				new WP_Error(
					'hnc_second_consent_required',
					__( 'Confirm that second consent was captured from the reporter.', 'helpnagaland-core' ),
					array( 'status' => 400 )
				)
			);
		}

		$plain = HNC_Phone_Vault::reveal( $id, true );
		if ( is_wp_error( $plain ) ) {
			return self::err( $plain );
		}

		// Never allow the phone to be cached anywhere between the app
		// server and the browser.
		$response = new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'phone' => (string) $plain,
				),
			),
			200
		);
		$response->header( 'Cache-Control', 'no-store, no-cache, private, max-age=0' );
		$response->header( 'Pragma', 'no-cache' );
		return $response;
	}

	/** POST /admin/vault/consent/{id} (body: partner) */
	public static function rest_vault_consent( $request ) {
		$id      = (int) $request->get_param( 'id' );
		$partner = (string) $request->get_param( 'partner' );
		$r       = HNC_Phone_Vault::set_partner_consent( $id, $partner );
		return self::result_response( $r, array( 'id' => $id, 'partner' => $partner ) );
	}

	/** DELETE /admin/vault/delete/{id} */
	public static function rest_vault_delete( $request ) {
		$id = (int) $request->get_param( 'id' );
		$r  = HNC_Phone_Vault::delete( $id );
		return self::result_response( $r, array( 'id' => $id, 'deleted' => true ) );
	}

	/** GET /admin/vault/counts — live row counts for the vault card. */
	public static function rest_vault_counts( $request ) {
		$rl = HNC_Api_Ratelimit::admin_user( 'vault_counts', 60, 60 );
		if ( null !== $rl ) { return self::err( $rl ); }
		return self::ok( HNC_Phone_Vault::counts() );
	}


	/* ------------------------------------------------------------------
	 * TRANSPARENCY ROUTES
	 * ------------------------------------------------------------------ */

	/**
	 * Register admin transparency endpoints.
	 *
	 * @return void
	 */
	private static function register_transparency_routes() {
		$cap = 'hnc_publish_transparency';

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/transparency/build',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_transparency_build' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/transparency/publish',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_transparency_publish' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/transparency/unpublish',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_transparency_unpublish' ),
				'permission_callback' => HNC_Api_Nonce::cap( $cap ),
			)
		);
	}

	/** POST /admin/transparency/build (body: year, month) */
	public static function rest_transparency_build( $request ) {
		$year  = (int) $request->get_param( 'year' );
		$month = (int) $request->get_param( 'month' );
		$r     = HNC_Transparency_Snapshot::build( $year, $month );
		if ( is_wp_error( $r ) ) { return self::err( $r ); }
		return self::ok( array( 'row_id' => (int) $r, 'year' => $year, 'month' => $month ) );
	}

	/** POST /admin/transparency/publish (body: year, month, note) */
	public static function rest_transparency_publish( $request ) {
		$year  = (int) $request->get_param( 'year' );
		$month = (int) $request->get_param( 'month' );
		$note  = (string) $request->get_param( 'note' );
		$r     = HNC_Transparency_Publish::publish( $year, $month, $note );
		return self::result_response( $r, array( 'year' => $year, 'month' => $month, 'published' => true ) );
	}

	/** POST /admin/transparency/unpublish (body: year, month) */
	public static function rest_transparency_unpublish( $request ) {
		$year  = (int) $request->get_param( 'year' );
		$month = (int) $request->get_param( 'month' );
		$r     = HNC_Transparency_Publish::unpublish( $year, $month );
		return self::result_response( $r, array( 'year' => $year, 'month' => $month, 'published' => false ) );
	}


	/* ------------------------------------------------------------------
	 * KILLSWITCH ROUTES
	 * ------------------------------------------------------------------ */

	/**
	 * Register killswitch endpoints.
	 *
	 * @return void
	 */
	private static function register_killswitch_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/killswitch/status',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_killswitch_status' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_operate_killswitch' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/killswitch/activate',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_killswitch_activate' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_operate_killswitch' ),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/killswitch/deactivate',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'rest_killswitch_deactivate' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_operate_killswitch' ),
			)
		);
	}

	/** GET /admin/killswitch/status */
	public static function rest_killswitch_status() {
		return self::ok(
			array(
				'active'          => HNC_Killswitch::is_active(),
				'activated_at'    => HNC_Killswitch::activated_at(),
				'public_message'  => HNC_Killswitch::public_message(),
			)
		);
	}

	/** POST /admin/killswitch/activate (body: internal_reason, public_message) */
	public static function rest_killswitch_activate( $request ) {
		$reason  = (string) $request->get_param( 'internal_reason' );
		$public  = (string) $request->get_param( 'public_message' );
		$r       = HNC_Killswitch::activate( $reason, $public );
		if ( is_wp_error( $r ) ) { return self::err( $r ); }
		return self::ok( array( 'active' => true ) );
	}

	/** POST /admin/killswitch/deactivate (body: notes) */
	public static function rest_killswitch_deactivate( $request ) {
		$notes = (string) $request->get_param( 'notes' );
		$r     = HNC_Killswitch::deactivate( $notes );
		if ( is_wp_error( $r ) ) { return self::err( $r ); }
		return self::ok( array( 'active' => false ) );
	}


	/* ------------------------------------------------------------------
	 * AUDIT LOG ROUTES
	 * ------------------------------------------------------------------ */

	/**
	 * Register audit log endpoint.
	 *
	 * @return void
	 */
	private static function register_audit_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/admin/audit',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_audit_list' ),
				'permission_callback' => HNC_Api_Nonce::cap( 'hnc_view_audit' ),
			)
		);
	}

	/** GET /admin/audit with optional filters: event_type, action, report_type, report_id, page, per_page */
	public static function rest_audit_list( $request ) {
		$rl = HNC_Api_Ratelimit::admin_user( 'audit_list' );
		if ( null !== $rl ) { return self::err( $rl ); }

		$filters = array(
			'event_type'  => (string) $request->get_param( 'event_type' ),
			'action'      => (string) $request->get_param( 'action' ),
			'report_type' => (string) $request->get_param( 'report_type' ),
			'report_id'   => (int) $request->get_param( 'report_id' ),
			'page'        => max( 1, (int) $request->get_param( 'page' ) ),
			'per_page'    => min( 200, max( 1, (int) $request->get_param( 'per_page' ) ) ),
		);

		if ( class_exists( 'HNC_Logger' ) && is_callable( array( 'HNC_Logger', 'query' ) ) ) {
			$result = HNC_Logger::query( $filters );
		} else {
			$result = array( 'rows' => array(), 'total' => 0 );
		}

		return self::ok( $result );
	}


	/* ------------------------------------------------------------------
	 * RESPONSE HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Standard success response.
	 *
	 * @param mixed $data Data payload.
	 * @param int   $code HTTP status.
	 * @return WP_REST_Response
	 */
	private static function ok( $data, $code = 200 ) {
		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $data,
			),
			$code
		);
	}

	/**
	 * Standard error response translated from a WP_Error.
	 *
	 * @param WP_Error $err          Error.
	 * @param int      $fallback_http Fallback HTTP status.
	 * @return WP_REST_Response
	 */
	private static function err( $err, $fallback_http = 400 ) {
		$data = $err instanceof WP_Error ? $err->get_error_data() : null;
		$http = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : (int) $fallback_http;

		// Known code -> HTTP mapping for nicer API ergonomics.
		$map = array(
			'hnc_unauthorized'                 => 403,
			'hnc_forbidden'                    => 403,
			'hnc_invalid_nonce'                => 401,
			'hnc_missing_nonce'                => 401,
			'hnc_not_found'                    => 404,
			'hnc_report_not_found'             => 404,
			'hnc_vault_entry_not_found'        => 404,
			'hnc_snapshot_not_found'           => 404,
			'hnc_bad_status_transition'        => 409,
			'hnc_merge_same_id'                => 409,
			'hnc_already_forwarded_same_partner' => 409,
			'hnc_rate_limit'                   => 429,
			'hnc_platform_paused'              => 503,
		);
		$code_str = $err instanceof WP_Error ? $err->get_error_code() : 'hnc_error';
		if ( isset( $map[ $code_str ] ) && $http === (int) $fallback_http ) {
			$http = $map[ $code_str ];
		}

		$response = new WP_REST_Response(
			array(
				'success' => false,
				'code'    => $code_str,
				'message' => $err instanceof WP_Error ? $err->get_error_message() : (string) $err,
			),
			$http
		);
		if ( is_array( $data ) && isset( $data['retry_after'] ) ) {
			$response->header( 'Retry-After', (int) $data['retry_after'] );
		}
		return $response;
	}

	/**
	 * Build a 404 response quickly.
	 *
	 * @param string $msg Message.
	 * @return WP_REST_Response
	 */
	private static function err_404( $msg = 'Not found.' ) {
		return new WP_REST_Response(
			array(
				'success' => false,
				'code'    => 'hnc_not_found',
				'message' => (string) $msg,
			),
			404
		);
	}

	/**
	 * Standard queue-endpoint argument schema. Applies to the alcohol
	 * and drug queue listers which all accept the same shape.
	 *
	 * @param array $status_enum Allowed values for `status`.
	 * @return array
	 */
	private static function queue_args( array $status_enum ) {
		return array(
			'status'   => array(
				'type'              => 'string',
				'default'           => 'pending',
				'enum'              => $status_enum,
				'sanitize_callback' => 'sanitize_key',
				'validate_callback' => 'rest_validate_request_arg',
			),
			'district' => array(
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
			),
			'category' => array(
				'type'              => 'string',
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
			),
			'page'     => array(
				'type'              => 'integer',
				'default'           => 1,
				'minimum'           => 1,
				'maximum'           => 10000,
				'sanitize_callback' => 'absint',
			),
			'per_page' => array(
				'type'              => 'integer',
				'default'           => 20,
				'minimum'           => 1,
				'maximum'           => 100,
				'sanitize_callback' => 'absint',
			),
			'sort'     => array(
				'type'              => 'string',
				'default'           => '',
				'enum'              => array( '', 'newest', 'oldest', 'district', 'category' ),
				'sanitize_callback' => 'sanitize_key',
			),
		);
	}

	/**
	 * Result adapter: domain methods return true or WP_Error. Normalise
	 * both into proper REST responses. On success, the provided success
	 * payload is returned.
	 *
	 * @param mixed $result         Return value from the domain call.
	 * @param array $success_payload Data to echo back on success.
	 * @return WP_REST_Response
	 */
	private static function result_response( $result, $success_payload ) {
		if ( is_wp_error( $result ) ) {
			return self::err( $result );
		}
		return self::ok( $success_payload );
	}
}
