<?php
/**
 * API Rate Limit: middleware-style helpers for REST endpoints.
 *
 * Four flavours:
 *
 *   - public_ip($action_key, $max, $window) for public endpoints.
 *     Keyed on namespaced action + IP. Values live in transients so
 *     they survive across PHP requests but not longer than the window.
 *
 *   - admin_user($action_key, $max, $window) for authenticated admin
 *     endpoints. Keyed on user ID. Loose by default since admin
 *     actions are already capability-gated.
 *
 *   - partner_user($action_key, $max, $window) for authenticated
 *     partner endpoints. Stricter than admin since partner tokens
 *     are deployed onto third-party infrastructure we don't control.
 *
 *   - per_device($action_key, $device_hash, $max, $window) for public
 *     write endpoints that want device-scoped (not IP-scoped) limits.
 *     Useful when a reporter is behind a shared NAT — limiting by IP
 *     would punish everyone at that coffee shop.
 *
 * Each method returns null on success or a WP_Error on failure. The
 * error payload carries a "retry_after" value so the frontend can show
 * a meaningful wait time.
 *
 * IP extraction honours a trusted-proxy config. By default the
 * REMOTE_ADDR header is used. When the site is behind a reverse proxy
 * (Cloudflare, nginx, AWS ALB), the admin can opt in by filtering
 * `hnc_trust_forwarded_for` to true; we then read the first IP from
 * `X-Forwarded-For`. Opting in without a trusted proxy in front would
 * let clients spoof any IP, so the default is OFF.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Api_Ratelimit
 */
final class HNC_Api_Ratelimit {


	const ERR_RATE_LIMIT = 'hnc_rate_limit';

	const DEFAULT_PUBLIC_MAX_PER_MINUTE  = 60;
	const DEFAULT_ADMIN_MAX_PER_MINUTE   = 120;
	const DEFAULT_PARTNER_MAX_PER_MINUTE = 30;


	/* ------------------------------------------------------------------
	 * PUBLIC RATE LIMIT (per-IP)
	 * ------------------------------------------------------------------ */

	/**
	 * Enforce a per-IP rate limit on a public endpoint.
	 *
	 * @param string $action_key Short identifier. Used as part of the transient key.
	 * @param int    $max        Max requests allowed per window.
	 * @param int    $window_sec Window size in seconds. Default 60.
	 * @return WP_Error|null
	 */
	public static function public_ip( $action_key, $max = self::DEFAULT_PUBLIC_MAX_PER_MINUTE, $window_sec = 60 ) {
		$ip = self::client_ip();
		if ( '' === $ip ) {
			return null;
		}
		return self::tick( self::bucket( 'pip', $action_key, $ip ), (int) $max, (int) $window_sec );
	}


	/* ------------------------------------------------------------------
	 * ADMIN RATE LIMIT (per user ID)
	 * ------------------------------------------------------------------ */

	/**
	 * Enforce a per-user rate limit on an admin endpoint.
	 *
	 * @param string $action_key Short identifier.
	 * @param int    $max        Max requests allowed per window.
	 * @param int    $window_sec Window size in seconds. Default 60.
	 * @return WP_Error|null
	 */
	public static function admin_user( $action_key, $max = self::DEFAULT_ADMIN_MAX_PER_MINUTE, $window_sec = 60 ) {
		$uid = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		if ( $uid <= 0 ) {
			return null;
		}
		return self::tick( self::bucket( 'auid', $action_key, (string) $uid ), (int) $max, (int) $window_sec );
	}


	/* ------------------------------------------------------------------
	 * PARTNER RATE LIMIT (per partner user)
	 * ------------------------------------------------------------------ */

	/**
	 * Enforce a per-user rate limit on a partner endpoint. Same mechanism
	 * as admin_user() but scoped into a different bucket namespace so
	 * admin and partner quota don't pool, and with a much tighter
	 * default because partner tokens live on third-party systems.
	 *
	 * @param string $action_key Short identifier.
	 * @param int    $max        Max requests allowed per window.
	 * @param int    $window_sec Window size in seconds. Default 60.
	 * @return WP_Error|null
	 */
	public static function partner_user( $action_key, $max = self::DEFAULT_PARTNER_MAX_PER_MINUTE, $window_sec = 60 ) {
		$uid = function_exists( 'get_current_user_id' ) ? (int) get_current_user_id() : 0;
		if ( $uid <= 0 ) {
			return null;
		}
		return self::tick( self::bucket( 'puid', $action_key, (string) $uid ), (int) $max, (int) $window_sec );
	}


	/* ------------------------------------------------------------------
	 * DEVICE RATE LIMIT
	 * ------------------------------------------------------------------ */

	/**
	 * Enforce a per-device rate limit on a public endpoint.
	 *
	 * @param string $action_key   Short identifier.
	 * @param string $device_hash  Server-salted device hash (see HNC_Device).
	 * @param int    $max          Max requests allowed per window.
	 * @param int    $window_sec   Window size in seconds. Default 60.
	 * @return WP_Error|null
	 */
	public static function per_device( $action_key, $device_hash, $max = self::DEFAULT_PUBLIC_MAX_PER_MINUTE, $window_sec = 60 ) {
		$device_hash = (string) $device_hash;
		if ( '' === $device_hash ) {
			return null;
		}
		return self::tick(
			self::bucket( 'dev', $action_key, substr( $device_hash, 0, 32 ) ),
			(int) $max,
			(int) $window_sec
		);
	}


	/* ------------------------------------------------------------------
	 * INTERNAL
	 * ------------------------------------------------------------------ */

	/**
	 * Build a bucket string that keeps each rate-limit tier in its own
	 * keyspace. Collisions across tiers (eg admin quota eating into
	 * public quota) are impossible because the first segment differs.
	 *
	 * @param string $tier       Namespace prefix (pip, auid, puid, dev).
	 * @param string $action_key Per-endpoint identifier.
	 * @param string $subject    IP / user id / device hash.
	 * @return string
	 */
	private static function bucket( $tier, $action_key, $subject ) {
		return $tier . '|' . sanitize_key( $action_key ) . '|' . $subject;
	}

	/**
	 * Increment a counter in a transient. If it exceeds max, return a
	 * WP_Error with Retry-After.
	 *
	 * @param string $bucket_key Raw bucket key (namespaced).
	 * @param int    $max        Max count.
	 * @param int    $window     Window size seconds.
	 * @return WP_Error|null
	 */
	private static function tick( $bucket_key, $max, $window ) {
		// SHA-256 is overkill for a rate-limit key's collision resistance
		// but gives us a predictable short suffix and zero risk of
		// accidental collisions across tiers. The namespace is already
		// encoded in $bucket_key.
		$key = 'hnc_rl_' . substr( hash( 'sha256', (string) $bucket_key ), 0, 32 );

		$current = get_transient( $key );
		if ( false === $current ) {
			set_transient( $key, 1, max( 1, (int) $window ) );
			return null;
		}

		$current = (int) $current;
		if ( $current >= (int) $max ) {
			if ( class_exists( 'HNC_Logger' ) ) {
				// Log only the namespaced bucket prefix, never the full
				// subject (which may be an IP or user id).
				$prefix_end = strpos( $bucket_key, '|', strpos( $bucket_key, '|' ) + 1 );
				$bucket_for_log = false !== $prefix_end ? substr( $bucket_key, 0, $prefix_end ) : $bucket_key;
				HNC_Logger::log_security(
					HNC_Logger::ACTION_RATE_LIMIT,
					array(
						'bucket' => $bucket_for_log,
						'hits'   => $current,
						'max'    => (int) $max,
					)
				);
			}
			return new WP_Error(
				self::ERR_RATE_LIMIT,
				__( 'Too many requests. Please slow down and try again shortly.', 'helpnagaland-core' ),
				array(
					'status'      => 429,
					'retry_after' => (int) $window,
				)
			);
		}

		set_transient( $key, $current + 1, max( 1, (int) $window ) );
		return null;
	}

	/**
	 * Get the client IP. Honours a trusted-proxy config when opted in.
	 *
	 * @return string
	 */
	private static function client_ip() {
		$trust_forwarded = (bool) apply_filters( 'hnc_trust_forwarded_for', false );

		if ( $trust_forwarded && ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$raw = sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
			// First IP in the chain is the original client when the
			// proxy chain is trusted.
			$parts = array_map( 'trim', explode( ',', $raw ) );
			foreach ( $parts as $candidate ) {
				if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) {
					return $candidate;
				}
			}
		}

		if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
			return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
		}
		return '';
	}
}
