<?php
/**
 * API Public: public status lookup and health endpoints.
 *
 * Three public endpoints:
 *
 *   GET /hnc/v1/alcohol/status/{code}
 *       Reporter looks up their alcohol submission by tracking code.
 *       Returns status + district + category + timestamps.
 *
 *   GET /hnc/v1/drug/status/{code}
 *       Reporter looks up their drug submission by tracking code.
 *       Returns a coarse status bucket only. No district, no category.
 *       See HNC_Drug_Moderation::get_public_status_by_code for rationale.
 *
 *   GET /hnc/v1/health
 *       Returns a minimal payload that shows the plugin is loaded,
 *       the killswitch state, and the build version. Useful for uptime
 *       monitoring and for the frontend to detect a paused platform.
 *
 * All three are open (no auth) and are protected by per-IP rate limits
 * to avoid someone mass-probing tracking codes. The limit is deliberately
 * generous for legitimate reporters, but low enough to frustrate an
 * attacker looking to enumerate codes.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Api_Public
 */
final class HNC_Api_Public {


	/**
	 * Register REST routes on rest_api_init.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_rest_routes' ) );
	}

	/**
	 * Register the three public endpoints.
	 *
	 * @return void
	 */
	public static function register_rest_routes() {
		register_rest_route(
			HNC_API_NAMESPACE,
			'/alcohol/status/(?P<code>[A-Za-z0-9-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_alcohol_status' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'code' => array( 'type' => 'string', 'required' => true ),
				),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/drug/status/(?P<code>[A-Za-z0-9-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_drug_status' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'code' => array( 'type' => 'string', 'required' => true ),
				),
			)
		);

		register_rest_route(
			HNC_API_NAMESPACE,
			'/health',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'rest_health' ),
				'permission_callback' => '__return_true',
			)
		);
	}


	/* ------------------------------------------------------------------
	 * ALCOHOL STATUS
	 * ------------------------------------------------------------------ */

	/**
	 * GET /alcohol/status/{code}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_alcohol_status( $request ) {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}

		if ( class_exists( 'HNC_Api_Ratelimit' ) ) {
			$rl_err = HNC_Api_Ratelimit::public_ip( 'alcohol_status', 60, 60 );
			if ( null !== $rl_err ) {
				return self::err_response( $rl_err, 429 );
			}
		}

		$code = (string) $request->get_param( 'code' );

		if ( ! class_exists( 'HNC_Alcohol_Moderation' ) ) {
			return self::not_found( 'Alcohol subsystem not available.' );
		}

		$data = HNC_Alcohol_Moderation::get_public_status_by_code( $code );
		if ( null === $data ) {
			return self::not_found();
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $data,
			),
			200
		);
	}


	/* ------------------------------------------------------------------
	 * DRUG STATUS
	 * ------------------------------------------------------------------ */

	/**
	 * GET /drug/status/{code}.
	 *
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function rest_drug_status( $request ) {
		if ( class_exists( 'HNC_Killswitch' ) ) {
			$blocked = HNC_Killswitch::guard_public_endpoint();
			if ( null !== $blocked ) {
				return $blocked;
			}
		}

		if ( class_exists( 'HNC_Api_Ratelimit' ) ) {
			$rl_err = HNC_Api_Ratelimit::public_ip( 'drug_status', 60, 60 );
			if ( null !== $rl_err ) {
				return self::err_response( $rl_err, 429 );
			}
		}

		$code = (string) $request->get_param( 'code' );

		if ( ! class_exists( 'HNC_Drug_Moderation' ) ) {
			return self::not_found( 'Drug subsystem not available.' );
		}

		$data = HNC_Drug_Moderation::get_public_status_by_code( $code );
		if ( null === $data ) {
			return self::not_found();
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $data,
			),
			200
		);
	}


	/* ------------------------------------------------------------------
	 * HEALTH
	 * ------------------------------------------------------------------ */

	/**
	 * GET /health. No auth. Rate-limited per-IP so a single caller
	 * cannot probe kill-switch state indefinitely.
	 *
	 * @return WP_REST_Response
	 */
	public static function rest_health() {
		if ( class_exists( 'HNC_Api_Ratelimit' ) ) {
			// 120 calls per 60 seconds per IP is plenty for legit use
			// (browser poll every 30s = 2/min) and cheap for monitoring.
			$rl_err = HNC_Api_Ratelimit::public_ip( 'health', 120, 60 );
			if ( null !== $rl_err ) {
				return self::err_response( $rl_err, 429 );
			}
		}

		$killswitch_active = class_exists( 'HNC_Killswitch' )
			? (bool) HNC_Killswitch::is_active()
			: false;

		$public_message = class_exists( 'HNC_Killswitch' )
			? (string) HNC_Killswitch::public_message()
			: '';

		return new WP_REST_Response(
			array(
				'success'           => true,
				'status'            => $killswitch_active ? 'paused' : 'ok',
				'version'           => defined( 'HNC_VERSION' ) ? (string) HNC_VERSION : '0.0.0',
				'killswitch_active' => $killswitch_active,
				'public_message'    => $killswitch_active ? $public_message : '',
				'time'              => gmdate( 'c' ),
			),
			200
		);
	}


	/* ------------------------------------------------------------------
	 * HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Uniform 404 response that does not leak whether the code format
	 * was valid vs. the code did not exist. Keeps probing unprofitable.
	 *
	 * @param string $override_message Optional custom message.
	 * @return WP_REST_Response
	 */
	private static function not_found( $override_message = '' ) {
		return new WP_REST_Response(
			array(
				'success' => false,
				'code'    => 'hnc_not_found',
				'message' => '' !== $override_message
					? $override_message
					: __( 'No report was found for that code.', 'helpnagaland-core' ),
			),
			404
		);
	}

	/**
	 * Translate a WP_Error into a REST response.
	 *
	 * @param WP_Error $err    Error.
	 * @param int      $status HTTP status fallback.
	 * @return WP_REST_Response
	 */
	private static function err_response( $err, $status = 400 ) {
		$data       = $err->get_error_data();
		$status_out = is_array( $data ) && isset( $data['status'] ) ? (int) $data['status'] : (int) $status;
		$response   = new WP_REST_Response(
			array(
				'success' => false,
				'code'    => $err->get_error_code(),
				'message' => $err->get_error_message(),
			),
			$status_out
		);
		if ( is_array( $data ) && isset( $data['retry_after'] ) ) {
			$response->header( 'Retry-After', (int) $data['retry_after'] );
		}
		return $response;
	}
}
