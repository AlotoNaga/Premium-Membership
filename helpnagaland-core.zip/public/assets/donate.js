/**
 * Help Nagaland — Donation form + status page logic.
 *
 * Two flows handled in this single file:
 *   1. Donate page (.hnc-donate present) — full Razorpay Checkout flow.
 *   2. Status page (.hnc-status present) — render thank-you/error UI from URL params.
 *
 * Globals expected:
 *   HNCDonate.api_root       (string)  REST API base, e.g. /wp-json/hnc/v1
 *   HNCDonate.rest_nonce     (string)  WP REST nonce
 *   HNCDonate.thank_you_url  (string)  Permalink of thank-you page
 *   HNCDonate.donate_url     (string)  Permalink of donate page
 *   HNCDonate.manage_url     (string)  Permalink of manage page
 *   HNCDonate.site_name      (string)  For Razorpay Checkout title
 *   HNCDonate.i18n           (object)  Translatable strings
 *   Razorpay                 (global)  Loaded from checkout.razorpay.com
 *
 * @package HelpNagalandCore
 */

(function () {
	'use strict';

	// Wait for DOM ready.
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

	function init() {
		var donateRoot = document.querySelector('.hnc-donate');
		if (donateRoot) {
			initDonateForm(donateRoot);
		}
		var statusRoot = document.querySelector('.hnc-status');
		if (statusRoot) {
			initStatusPage(statusRoot);
		}
	}

	/* ============================================================
	 * DONATE FORM
	 * ============================================================ */

	function initDonateForm(root) {
		var state = {
			amount: parseInt(root.querySelector('.hnc-donate__submit').dataset.defaultAmount, 10) || 500,
			frequency: root.querySelector('.hnc-donate__submit').dataset.defaultFreq || 'once',
			minInr: parseInt(root.dataset.minInr, 10) || 1,
			maxInr: parseInt(root.dataset.maxInr, 10) || 1000000,
			intentToken: null,
			razorpayKeyId: null,
			submitting: false
		};

		var elements = {
			feedback: root.querySelector('.hnc-donate__feedback'),
			freqTabs: root.querySelectorAll('.hnc-donate__freq-tab'),
			freqHidden: root.querySelector('.hnc-donate__freq-hidden'),
			amountBtns: root.querySelectorAll('.hnc-donate__amount-btn'),
			customInput: root.querySelector('.hnc-donate__custom-input'),
			emailField: root.querySelector('.hnc-donate__field--email'),
			emailInput: root.querySelector('.hnc-donate__email-input'),
			submitBtn: root.querySelector('.hnc-donate__submit'),
			submitLabel: root.querySelector('.hnc-donate__submit-label'),
			submitSpinner: root.querySelector('.hnc-donate__submit-spinner')
		};

		// Frequency tab click handler.
		elements.freqTabs.forEach(function (tab) {
			tab.addEventListener('click', function () {
				selectFrequency(tab.dataset.freq);
			});
		});

		// If hidden input (single-frequency mode), set initial state.
		if (elements.freqHidden && !elements.freqTabs.length) {
			state.frequency = elements.freqHidden.value;
		}

		// Amount button click handler.
		elements.amountBtns.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var amount = parseInt(btn.dataset.amount, 10);
				if (amount > 0) {
					selectAmount(amount, false);
				}
			});
		});

		// Custom amount input handler.
		if (elements.customInput) {
			elements.customInput.addEventListener('input', function () {
				var val = parseInt(elements.customInput.value, 10);
				if (val > 0) {
					selectAmount(val, true);
				}
			});
		}

		// Submit click handler.
		elements.submitBtn.addEventListener('click', function () {
			submit();
		});

		// Initial render.
		updateSubmitLabel();
		toggleEmailField();

		// Pre-fetch config (key_id + intent token) in the background so
		// the first click on Donate is instant.
		fetchConfig();

		/* ---------------- Helpers ---------------- */

		function selectFrequency(freq) {
			state.frequency = freq;
			elements.freqTabs.forEach(function (tab) {
				var isActive = tab.dataset.freq === freq;
				tab.classList.toggle('is-selected', isActive);
				tab.setAttribute('aria-selected', isActive ? 'true' : 'false');
			});
			toggleEmailField();
			updateSubmitLabel();
			clearFeedback();
		}

		function selectAmount(amount, isCustom) {
			state.amount = amount;
			elements.amountBtns.forEach(function (btn) {
				btn.classList.toggle('is-selected', !isCustom && parseInt(btn.dataset.amount, 10) === amount);
			});
			if (!isCustom) {
				// Clear custom input if a preset was picked.
				if (elements.customInput) {
					elements.customInput.value = '';
				}
			}
			updateSubmitLabel();
			clearFeedback();
		}

		function toggleEmailField() {
			if (!elements.emailField) {
				return;
			}
			if (state.frequency === 'once') {
				elements.emailField.hidden = true;
				if (elements.emailInput) {
					elements.emailInput.required = false;
				}
			} else {
				elements.emailField.hidden = false;
				if (elements.emailInput) {
					elements.emailInput.required = true;
				}
			}
		}

		function updateSubmitLabel() {
			if (!elements.submitLabel) {
				return;
			}
			var i18n = HNCDonate.i18n || {};
			var amountText = 'Rs ' + new Intl.NumberFormat('en-IN').format(state.amount);

			if (state.frequency === 'once') {
				var template = i18n.donate_button_label_once || 'Donate %s';
				elements.submitLabel.textContent = template.replace('%s', amountText);
			} else {
				var template2 = i18n.donate_button_label_sub || 'Donate %s every %s';
				var word = i18n['freq_' + state.frequency + '_word'] || state.frequency;
				elements.submitLabel.textContent = template2.replace('%s', amountText).replace('%s', word);
			}
		}

		function showFeedback(message, kind) {
			elements.feedback.textContent = message;
			elements.feedback.className = 'hnc-donate__feedback hnc-donate__feedback--' + (kind || 'info');
		}

		function clearFeedback() {
			elements.feedback.textContent = '';
			elements.feedback.className = 'hnc-donate__feedback';
		}

		function setSubmitting(submitting) {
			state.submitting = submitting;
			elements.submitBtn.disabled = submitting;
			if (elements.submitSpinner) {
				elements.submitSpinner.hidden = !submitting;
			}
		}

		function fetchConfig() {
			fetch(HNCDonate.api_root + '/payment/config', {
				method: 'GET',
				credentials: 'same-origin',
				headers: { 'X-WP-Nonce': HNCDonate.rest_nonce }
			})
				.then(function (resp) { return resp.json(); })
				.then(function (data) {
					if (data && data.razorpay_key_id) {
						state.razorpayKeyId = data.razorpay_key_id;
						state.intentToken = data.intent_token;
						if (data.min_amount_paise) {
							state.minInr = Math.ceil(data.min_amount_paise / 100);
						}
						if (data.max_amount_paise) {
							state.maxInr = Math.floor(data.max_amount_paise / 100);
						}
					}
				})
				.catch(function () {
					// Silent. We'll re-fetch on submit if needed.
				});
		}

		function submit() {
			if (state.submitting) {
				return;
			}
			clearFeedback();

			var i18n = HNCDonate.i18n || {};

			// Validate amount.
			if (!state.amount || state.amount < 1) {
				showFeedback(i18n.select_amount, 'error');
				return;
			}
			if (state.amount < state.minInr) {
				showFeedback(i18n.amount_below_minimum + ' (Rs ' + state.minInr + ')', 'error');
				return;
			}
			if (state.amount > state.maxInr) {
				showFeedback(i18n.amount_above_maximum + ' (Rs ' + state.maxInr + ')', 'error');
				return;
			}

			// Validate email if recurring.
			var email = '';
			if (state.frequency !== 'once') {
				email = (elements.emailInput && elements.emailInput.value || '').trim();
				if (!email) {
					showFeedback(i18n.enter_email, 'error');
					if (elements.emailInput) elements.emailInput.focus();
					return;
				}
				if (!isValidEmail(email)) {
					showFeedback(i18n.invalid_email, 'error');
					if (elements.emailInput) elements.emailInput.focus();
					return;
				}
			}

			setSubmitting(true);

			// Refresh config if we don't have a key + token yet.
			var configReady = state.razorpayKeyId && state.intentToken
				? Promise.resolve()
				: fetch(HNCDonate.api_root + '/payment/config', {
						method: 'GET',
						credentials: 'same-origin',
						headers: { 'X-WP-Nonce': HNCDonate.rest_nonce }
					})
					.then(function (resp) { return resp.json(); })
					.then(function (data) {
						if (data && data.razorpay_key_id) {
							state.razorpayKeyId = data.razorpay_key_id;
							state.intentToken = data.intent_token;
						} else {
							throw new Error('config_fetch_failed');
						}
					});

			configReady
				.then(function () {
					if (state.frequency === 'once') {
						return createOrder();
					} else {
						return createSubscription(email);
					}
				})
				.catch(function (err) {
					setSubmitting(false);
					showFeedback(
						(err && err.message && err.message.length < 200) ? err.message : i18n.something_went_wrong,
						'error'
					);
				});
		}

		function createOrder() {
			// Note: we send paise (rupees * 100) and amount_unit: 'paise',
			// not rupees. The payment class's sanitize_amount_to_paise()
			// has an is_int short-circuit at the top that returns the raw
			// int regardless of $unit, so sending a JSON int with
			// amount_unit:'rupees' would be wrongly interpreted as paise.
			// Sending paise directly is unambiguous.
			var body = {
				intent_token: state.intentToken,
				amount: state.amount * 100,
				amount_unit: 'paise',
				donor_anonymous: true
			};
			return fetch(HNCDonate.api_root + '/payment/order', {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': HNCDonate.rest_nonce
				},
				body: JSON.stringify(body)
			})
				.then(function (resp) {
					return resp.json().then(function (data) {
						if (!resp.ok) throw new Error(extractError(data));
						return data;
					});
				})
				.then(function (data) {
					openRazorpayForOrder(data);
				});
		}

		function createSubscription(email) {
			// See note in createOrder() — paise integer is unambiguous,
			// works around the is_int short-circuit in the payment class.
			var body = {
				intent_token: state.intentToken,
				amount: state.amount * 100,
				amount_unit: 'paise',
				frequency: state.frequency,
				donor_email: email,
				donor_anonymous: true
			};
			return fetch(HNCDonate.api_root + '/payment/subscription', {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': HNCDonate.rest_nonce
				},
				body: JSON.stringify(body)
			})
				.then(function (resp) {
					return resp.json().then(function (data) {
						if (!resp.ok) throw new Error(extractError(data));
						return data;
					});
				})
				.then(function (data) {
					openRazorpayForSubscription(data, email);
				});
		}

		function openRazorpayForOrder(data) {
			var i18n = HNCDonate.i18n || {};
			var options = {
				key: data.razorpay_key_id || state.razorpayKeyId,
				order_id: data.razorpay_order_id,
				amount: data.amount_paise,
				currency: data.currency || 'INR',
				name: data.name || HNCDonate.site_name || 'Help Nagaland',
				description: data.description || 'Donation',
				theme: { color: '#0A7558' },
				handler: function (response) {
					verifyAndRedirect({
						razorpay_order_id: response.razorpay_order_id,
						razorpay_payment_id: response.razorpay_payment_id,
						razorpay_signature: response.razorpay_signature,
						public_code: data.public_code,
						type: 'order'
					});
				},
				modal: {
					ondismiss: function () {
						setSubmitting(false);
						showFeedback(i18n.payment_cancelled, 'info');
					}
				}
			};
			var rzp = new Razorpay(options);
			rzp.on('payment.failed', function (response) {
				setSubmitting(false);
				var msg = (response && response.error && response.error.description) || i18n.payment_failed;
				showFeedback(msg, 'error');
				redirectToStatus(data.public_code, 'failed');
			});
			rzp.open();
		}

		function openRazorpayForSubscription(data, email) {
			var i18n = HNCDonate.i18n || {};
			var options = {
				key: data.razorpay_key_id || state.razorpayKeyId,
				subscription_id: data.razorpay_subscription_id,
				name: data.name || HNCDonate.site_name || 'Help Nagaland',
				description: data.description || 'Recurring donation',
				theme: { color: '#0A7558' },
				prefill: { email: email },
				handler: function (response) {
					verifyAndRedirect({
						razorpay_subscription_id: response.razorpay_subscription_id,
						razorpay_payment_id: response.razorpay_payment_id,
						razorpay_signature: response.razorpay_signature,
						public_code: data.public_code,
						type: 'subscription'
					});
				},
				modal: {
					ondismiss: function () {
						setSubmitting(false);
						showFeedback(i18n.payment_cancelled, 'info');
					}
				}
			};
			var rzp = new Razorpay(options);
			rzp.on('payment.failed', function (response) {
				setSubmitting(false);
				var msg = (response && response.error && response.error.description) || i18n.payment_failed;
				showFeedback(msg, 'error');
				redirectToStatus(data.public_code, 'failed');
			});
			rzp.open();
		}

		function verifyAndRedirect(payload) {
			fetch(HNCDonate.api_root + '/payment/verify', {
				method: 'POST',
				credentials: 'same-origin',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': HNCDonate.rest_nonce
				},
				body: JSON.stringify(payload)
			})
				.then(function (resp) {
					return resp.json().then(function (data) {
						if (!resp.ok) throw new Error(extractError(data));
						return data;
					});
				})
				.then(function (data) {
					var status = (data && data.status) || (payload.type === 'subscription' ? 'authenticated' : 'captured');
					redirectToStatus(payload.public_code, status);
				})
				.catch(function () {
					// Verification failed — show as failed but include public_code
					// so admin can investigate from logs.
					redirectToStatus(payload.public_code, 'pending');
				});
		}

		function redirectToStatus(publicCode, status) {
			var url = HNCDonate.thank_you_url || '/';
			var sep = url.indexOf('?') >= 0 ? '&' : '?';
			window.location.href = url + sep + 'code=' + encodeURIComponent(publicCode || '') + '&status=' + encodeURIComponent(status || '');
		}

		function extractError(data) {
			if (!data) return '';
			if (typeof data.message === 'string') return data.message;
			if (typeof data.error === 'string') return data.error;
			if (data.data && typeof data.data.message === 'string') return data.data.message;
			return '';
		}

		function isValidEmail(s) {
			return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
		}
	}

	/* ============================================================
	 * STATUS / THANK-YOU PAGE
	 * ============================================================ */

	function initStatusPage(root) {
		var params = new URLSearchParams(window.location.search);
		var code = params.get('code') || '';
		var status = (params.get('status') || '').toLowerCase();

		// Friendly status copy.
		var titles = {
			captured:        'Thank you',
			authorized:      'Payment received',
			authenticated:   'Subscription confirmed',
			active:          'Subscription active',
			charged:         'Charge received',
			pending:         'Processing',
			failed:          'Payment not completed',
			cancelled:       'Cancelled',
			'':              'Thank you'
		};
		var messages = {
			captured:      'Your donation has been received. Help Nagaland is grateful for your support.',
			authorized:    'Your payment is confirmed and is being captured. This typically completes within a few seconds.',
			authenticated: 'Your recurring donation is set up. The first charge will happen shortly. Razorpay will email you a confirmation, and you can manage or cancel anytime from that email.',
			active:        'Your recurring donation is active. Thank you for supporting Help Nagaland month after month.',
			charged:       'Your scheduled charge has been received. Thank you for your continued support.',
			pending:       'Your payment is being processed. Please refresh this page in a moment.',
			failed:        'Your payment could not be processed. No money has been charged. You can try again from the donate page.',
			cancelled:     'You cancelled the payment. No money has been charged.',
			'':            'If you completed a payment, look for the Razorpay confirmation email. If something looks wrong, please contact us.'
		};
		var icons = {
			captured:      { glyph: '✓', cls: 'success' },
			authorized:    { glyph: '✓', cls: 'success' },
			authenticated: { glyph: '✓', cls: 'success' },
			active:        { glyph: '✓', cls: 'success' },
			charged:       { glyph: '✓', cls: 'success' },
			pending:       { glyph: '⏳', cls: 'pending' },
			failed:        { glyph: '✗', cls: 'error' },
			cancelled:     { glyph: '—', cls: 'pending' },
			'':            { glyph: '✓', cls: 'success' }
		};

		var icon = icons[status] || icons[''];
		var title = titles[status] || titles[''];
		var message = messages[status] || messages[''];

		var html = '';
		html += '<div class="hnc-status__icon hnc-status__icon--' + icon.cls + '">' + icon.glyph + '</div>';
		html += '<h1 class="hnc-status__title">' + escapeHtml(title) + '</h1>';
		html += '<p class="hnc-status__message">' + escapeHtml(message) + '</p>';

		if (code) {
			html += '<div class="hnc-status__details">';
			html += '<div class="hnc-status__details-row">';
			html += '<span class="hnc-status__details-label">Reference:</span>';
			html += '<span class="hnc-status__details-value">' + escapeHtml(code) + '</span>';
			html += '</div>';
			html += '</div>';
		}

		// CTA: failed → back to donate; success → home.
		if (status === 'failed' || status === 'cancelled') {
			html += '<a class="hnc-status__cta" href="' + escapeHtml(HNCDonate.donate_url || '/') + '">Try again</a>';
		} else {
			html += '<a class="hnc-status__cta" href="' + escapeHtml(HNCDonate.donate_url || '/') + '">Donate again</a>';
		}

		root.innerHTML = html;
	}

	function escapeHtml(s) {
		return String(s == null ? '' : s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}

})();