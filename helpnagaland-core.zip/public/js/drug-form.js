/**
 * drug-form.js — drug submission with optional media + optional phone.
 *
 * Simpler than alcohol: no GPS, no live camera. Gallery uploads are
 * allowed for media. Phone field toggles visible when submission_mode
 * is "phone", and the consent checkbox becomes required in that mode.
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var forms = document.querySelectorAll('[data-hnc-form="drug"]');
		forms.forEach(initForm);
	});

	function initForm(form) {
		var HNC = window.HNC_PUBLIC;
		if (!HNC) return;

		var root = form.closest('.hnc-public-wrap') || form;
		HNC.form.applyKillswitchBanner(root);
		HNC.form.wireFingerprint(form);
		HNC.form.startTimer(form);

		wireModeToggle(form);
		wireSubmit(form);
	}

	function wireModeToggle(form) {
		var modes     = form.querySelectorAll('[data-hnc-mode]');
		var phoneBlk  = form.querySelector('[data-hnc-phone-block]');
		var phoneIn   = form.querySelector('[name="phone"]');
		var consent   = form.querySelector('[data-hnc-phone-consent]');

		function update() {
			var selected = 'anonymous';
			for (var i = 0; i < modes.length; i++) {
				if (modes[i].checked) { selected = modes[i].value; }
			}
			if (selected === 'phone') {
				if (phoneBlk) { phoneBlk.hidden = false; }
				if (phoneIn) { phoneIn.required = true; }
				if (consent) { consent.required = true; }
			} else {
				if (phoneBlk) { phoneBlk.hidden = true; }
				if (phoneIn) { phoneIn.required = false; phoneIn.value = ''; }
				if (consent) { consent.required = false; consent.checked = false; }
			}
		}

		modes.forEach(function (m) { m.addEventListener('change', update); });
		update();
	}

	function wireSubmit(form) {
		var HNC       = window.HNC_PUBLIC;
		var submitBtn = form.querySelector('[data-hnc-submit]');
		var result    = form.querySelector('[data-hnc-result]');
		var fileInput = form.querySelector('[data-hnc-media-input]');

		// Client-side size check on the media input as soon as the user
		// picks a file. Server enforces the same limit, but bouncing big
		// files here saves the reporter an upload that would be rejected.
		if (fileInput) {
			fileInput.addEventListener('change', function () {
				if (!fileInput.files || fileInput.files.length === 0) { return; }
				var maxBytes = (HNC.config && HNC.config.max_upload_bytes) || (15 * 1024 * 1024);
				var file = fileInput.files[0];
				if (file && file.size > maxBytes) {
					fileInput.value = '';
					HNC.ui.showResult(
						result,
						'<p>' + HNC.ui.esc(HNC.i18n.file_too_large || 'File too large.') + '</p>',
						'error'
					);
				}
			});
		}

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (HNC.config.killswitch) {
				HNC.ui.showResult(result, '<p>' + HNC.ui.esc(HNC.i18n.platform_paused) + '</p>', 'error');
				return;
			}

			// Second guard: re-validate the file size at submit time in
			// case the input was changed without a 'change' event firing
			// (some browsers + accessibility tooling combinations).
			if (fileInput && fileInput.files && fileInput.files.length > 0) {
				var maxBytes = (HNC.config && HNC.config.max_upload_bytes) || (15 * 1024 * 1024);
				if (fileInput.files[0].size > maxBytes) {
					HNC.ui.showResult(
						result,
						'<p>' + HNC.ui.esc(HNC.i18n.file_too_large || 'File too large.') + '</p>',
						'error'
					);
					return;
				}
			}

			submitBtn.disabled = true;
			var origText = submitBtn.textContent;
			submitBtn.textContent = HNC.i18n.submitting || 'Submitting...';

			var fd = new FormData();
			var inputs = form.querySelectorAll('input[name], textarea[name], select[name]');
			for (var i = 0; i < inputs.length; i++) {
				var el = inputs[i];
				if (!el.name) continue;
				if (el.type === 'radio' && !el.checked) continue;
				if (el.type === 'checkbox') {
					if (el.checked) { fd.set(el.name, el.value || '1'); }
					continue;
				}
				if (el.type === 'file') continue;
				fd.set(el.name, el.value);
			}
			// Optional media file.
			if (fileInput && fileInput.files && fileInput.files.length > 0) {
				fd.set('media', fileInput.files[0]);
			}

			HNC.api.postForm('drug/submit', fd).then(function (resp) {
				submitBtn.textContent = origText;
				var d = (resp && resp.data) || {};
				var phoneNote = d.phone_saved
					? '<p class="hnc-field-hint">Your phone number was encrypted and stored. Moderators will not reveal it without your additional confirmation.</p>'
					: (d.submission_mode === 'phone'
						? '<p class="hnc-field-hint"><strong>Note:</strong> Your phone was not stored because no moderator session is currently open. Your report was still submitted.</p>'
						: '');
				var html =
					'<p><strong>' + HNC.ui.esc(HNC.i18n.submit_success) + '</strong></p>' +
					'<p>' + HNC.ui.esc(HNC.i18n.tracking_code_is) + ' <code class="hnc-code">' + HNC.ui.esc(d.code || '') + '</code></p>' +
					'<p class="hnc-field-hint">' + HNC.ui.esc(HNC.i18n.save_this_code) + '</p>' +
					phoneNote;
				HNC.ui.showResult(result, html, 'success');
				form.reset();
			}).catch(function (err) {
				submitBtn.textContent = origText;
				submitBtn.disabled = false;
				HNC.ui.showResult(result, '<p>' + HNC.ui.esc(HNC.ui.translateError(err)) + '</p>', 'error');
				if (err && err.code === 'hnc_rate_limit') {
					HNC.ui.applyCooldown(submitBtn, err, origText);
				}
			});
		});
	}
}());
