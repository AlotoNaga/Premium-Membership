/**
 * public-common.js — shared helpers for all HNC public shortcodes.
 *
 * Exposes a single global `window.HNC_PUBLIC` with:
 *
 *   api       Thin fetch wrapper. No nonce (public endpoints are nonce-free).
 *   fp        Device fingerprint generator.
 *   ui        DOM helpers: esc, toast, showResult.
 *   form      Form helpers: timer, honeypot validation, killswitch banner.
 *   config    Reference to HNC_PUBLIC_CONFIG for convenience.
 *
 * The per-screen modules (alcohol-form.js, drug-form.js, etc) import from
 * this global. There is no build step, no ES modules, no imports. Just
 * scripts that attach behaviour at DOMContentLoaded.
 */

(function () {
	'use strict';

	var CFG = window.HNC_PUBLIC_CONFIG || {};
	var I18N = CFG.i18n || {};

	// ---- api ------------------------------------------------------------

	function apiRequest(method, path, body, isFormData) {
		var url = (CFG.rest_url || '/wp-json/hnc/v1/') + path.replace(/^\//, '');
		var init = { method: method, credentials: 'same-origin', headers: {} };
		if (body) {
			if (isFormData) {
				init.body = body;
			} else {
				init.headers['Content-Type'] = 'application/json';
				init.body = JSON.stringify(body);
			}
		}
		return fetch(url, init).then(function (r) {
			return r.json().then(function (data) {
				if (!r.ok || (data && data.success === false)) {
					var err = new Error((data && data.message) || ('HTTP ' + r.status));
					err.code = (data && data.code) || 'hnc_http_error';
					err.status = r.status;
					err.data = data;
					throw err;
				}
				return data;
			});
		});
	}

	var api = {
		get:  function (p)          { return apiRequest('GET',  p, null, false); },
		post: function (p, body)    { return apiRequest('POST', p, body, false); },
		postForm: function (p, fd)  { return apiRequest('POST', p, fd,   true);  }
	};

	// ---- fp (device fingerprint) ---------------------------------------
	//
	// The server expects a hex string of at least 32 chars as the device
	// fingerprint. We derive it from stable-ish browser attributes plus
	// localStorage persistence so the same browser returns the same
	// fingerprint across sessions. The server then hashes this with its
	// own salt before any DB write, so our client value is never stored
	// directly.

	function stableBrowserString() {
		var parts = [
			navigator.userAgent || '',
			navigator.language || '',
			(navigator.languages || []).join(',') || '',
			(screen && screen.width) || '',
			(screen && screen.height) || '',
			(screen && screen.colorDepth) || '',
			new Date().getTimezoneOffset()
		];
		return parts.join('|');
	}

	function fnv1a64Hex(str) {
		// Deterministic, simple hash. Server never trusts this value
		// beyond "looks like a hex fingerprint". Collisions at the client
		// layer are fine because the server re-hashes with its own salt.
		var h1 = 0x811c9dc5 >>> 0;
		var h2 = 0x1b3 >>> 0;
		for (var i = 0; i < str.length; i++) {
			h1 ^= str.charCodeAt(i);
			h1 = (h1 * 0x01000193) >>> 0;
			h2 ^= (str.charCodeAt(i) + 17);
			h2 = (h2 * 0x01000193) >>> 0;
		}
		// Mix in a per-session random component. Using sessionStorage
		// (not localStorage) means the salt is scoped to the current
		// browser tab/session and is discarded on close — a reporter
		// cannot be tracked across sessions by this value. The server
		// re-hashes with its own secret salt anyway, so the purpose of
		// this component is only to de-duplicate submissions within
		// the same session, not to create a durable identifier.
		var rand = '';
		try {
			rand = window.sessionStorage.getItem('hnc_fp_salt') || '';
			if (!rand) {
				rand = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
				window.sessionStorage.setItem('hnc_fp_salt', rand);
			}
		} catch (e) {
			rand = 'nostorage' + Math.random().toString(36).slice(2);
		}

		// Best-effort cleanup of the legacy key from localStorage so
		// upgraded installs don't retain the old persistent identifier.
		try { window.localStorage.removeItem('hnc_fp_salt'); } catch (e) { /* noop */ }

		var out = h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0');
		for (var j = 0; j < rand.length; j++) { out += rand.charCodeAt(j).toString(16).padStart(2, '0'); }
		// Trim to 64 hex chars exactly.
		while (out.length < 64) { out += '0'; }
		return out.slice(0, 64);
	}

	function deviceFingerprint() {
		return fnv1a64Hex(stableBrowserString());
	}

	// ---- ui -------------------------------------------------------------

	function esc(s) {
		if (s === null || s === undefined) return '';
		return String(s)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;');
	}

	function toast(msg, type) {
		type = type || 'info';
		var t = document.createElement('div');
		t.className = 'hnc-public-toast hnc-public-toast-' + type;
		t.textContent = msg;
		document.body.appendChild(t);
		setTimeout(function () { t.classList.add('hnc-public-toast-in'); }, 10);
		setTimeout(function () {
			t.classList.remove('hnc-public-toast-in');
			setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 400);
		}, 4500);
	}

	// CONTRACT: htmlSafe MUST already be a safe HTML string. Every dynamic
	// substring inside it must come from HNC.ui.esc(...) or be a static
	// literal. This helper assigns it to innerHTML; any unescaped server
	// or user value passed in is XSS. If you have a plain text message,
	// wrap it: showResult(el, '<p>' + esc(msg) + '</p>', 'error').
	function showResult(container, htmlSafe, type) {
		if (!container) return;
		container.hidden = false;
		container.className = 'hnc-result hnc-result-' + (type || 'info');
		container.innerHTML = htmlSafe;
		container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
	}

	function translateError(err) {
		if (!err) return I18N.submit_failed || 'Submission failed.';
		switch (err.code) {
			case 'hnc_rate_limit': {
				var s = retryAfterSeconds(err);
				if (s > 0) {
					var tmpl = I18N.rate_limited_wait || 'Too many requests. Please wait %d seconds.';
					return tmpl.replace('%d', s);
				}
				return I18N.rate_limited || 'Too many requests.';
			}
			case 'hnc_platform_paused':    return I18N.platform_paused || 'Submissions are paused.';
			case 'hnc_missing_field':      return I18N.missing_field || 'Missing field.';
			case 'hnc_form_too_fast':      return I18N.please_wait || 'Please wait.';
			case 'hnc_photo_too_old':      return I18N.photo_too_old || 'Photo too old.';
			case 'hnc_gps_out_of_bounds':  return I18N.gps_out_of_bounds || 'Outside Nagaland.';
			default:                       return err.message || I18N.submit_failed || 'Failed.';
		}
	}

	// Server puts the wait window in err.data.retry_after on 429s.
	function retryAfterSeconds(err) {
		if (!err || !err.data) return 0;
		var s = parseInt(err.data.retry_after, 10);
		return (isFinite(s) && s > 0) ? s : 0;
	}

	// Disable a submit button for the rate-limit window with a live
	// "Wait N s" countdown, then restore its original text and re-enable.
	function applyCooldown(button, err, origText) {
		var seconds = retryAfterSeconds(err);
		if (!button || seconds <= 0) return 0;
		if (typeof origText !== 'string') origText = button.textContent;
		var label = I18N.wait_seconds || 'Wait %d s';
		var remaining = seconds;
		button.disabled = true;
		button.textContent = label.replace('%d', remaining);
		var iv = setInterval(function () {
			remaining--;
			if (remaining <= 0) {
				clearInterval(iv);
				button.textContent = origText;
				button.disabled = false;
			} else {
				button.textContent = label.replace('%d', remaining);
			}
		}, 1000);
		return seconds;
	}

	// ---- form helpers ---------------------------------------------------

	function startFormTimer(form) {
		var start = Date.now();
		var timerInput = form.querySelector('[data-hnc-timer]');
		if (!timerInput) return;
		setInterval(function () {
			timerInput.value = Math.floor((Date.now() - start) / 1000);
		}, 1000);
		timerInput.value = 0;
	}

	function wireFingerprint(form) {
		var fpInput = form.querySelector('[data-hnc-fp]');
		if (fpInput) { fpInput.value = deviceFingerprint(); }
	}

	function applyKillswitchBanner(root) {
		if (!CFG.killswitch) return;
		var banner = root.querySelector('[data-hnc-ks-banner]');
		if (!banner) return;
		banner.hidden = false;
		var msgEl = banner.querySelector('[data-hnc-ks-message]');
		if (msgEl && CFG.ks_message) { msgEl.textContent = CFG.ks_message; }
		var submitBtn = root.querySelector('[data-hnc-submit]');
		if (submitBtn) { submitBtn.disabled = true; }
	}

	// ---- export ---------------------------------------------------------

	window.HNC_PUBLIC = {
		config: CFG,
		i18n: I18N,
		api: api,
		fp: { generate: deviceFingerprint },
		ui: { esc: esc, toast: toast, showResult: showResult, translateError: translateError, applyCooldown: applyCooldown },
		form: {
			startTimer: startFormTimer,
			wireFingerprint: wireFingerprint,
			applyKillswitchBanner: applyKillswitchBanner
		}
	};
}());
