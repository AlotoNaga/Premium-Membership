/**
 * alcohol-form.js — live GPS + live camera alcohol submission.
 *
 * Hard rules enforced here:
 *   - No file input. Photo must come from getUserMedia, captured in the
 *     browser right now.
 *   - GPS must come from navigator.geolocation. No manual lat/lng entry.
 *   - GPS must fall inside the Nagaland bounding box before the submit
 *     button is enabled.
 *   - The terms checkbox must be ticked.
 *   - A timer value in seconds is submitted so the server can enforce
 *     the minimum fill time.
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var forms = document.querySelectorAll('[data-hnc-form="alcohol"]');
		forms.forEach(initForm);
	});

	function initForm(form) {
		var HNC = window.HNC_PUBLIC;
		if (!HNC) return;

		var root = form.closest('.hnc-public-wrap') || form;
		HNC.form.applyKillswitchBanner(root);
		HNC.form.wireFingerprint(form);
		HNC.form.startTimer(form);

		var state = {
			gps: null,      // { lat, lng, accuracy }
			photoBlob: null,
			photoTs: null,
			stream: null,
			facingMode: 'environment' // 'environment' (back) or 'user' (front)
		};

		wireGps(form, state);
		wireCamera(form, state);
		wireSubmitEnablement(form, state);
		wireSubmit(form, state);
	}

	// ---- GPS ------------------------------------------------------------

	function wireGps(form, state) {
		var btn    = form.querySelector('[data-hnc-gps-btn]');
		var status = form.querySelector('[data-hnc-gps-status]');
		var latIn  = form.querySelector('[data-hnc-lat]');
		var lngIn  = form.querySelector('[data-hnc-lng]');
		var accIn  = form.querySelector('[data-hnc-acc]');
		var HNC    = window.HNC_PUBLIC;
		var bbox   = (HNC.config && HNC.config.bbox) || {};

		if (!btn) return;

		/**
		 * Reset the GPS widget to its initial state. Exposed on
		 * `state.resetGps` so the submit handler can call it after
		 * a successful submission.
		 */
		state.resetGps = function () {
			state.gps = null;
			latIn.value = '';
			lngIn.value = '';
			accIn.value = '';
			status.textContent = '';
			btn.disabled = false;
		};

		btn.addEventListener('click', function () {
			if (!navigator.geolocation) {
				status.textContent = HNC.i18n.gps_unavailable;
				return;
			}
			btn.disabled = true;
			status.textContent = HNC.i18n.loading || 'Loading...';
			navigator.geolocation.getCurrentPosition(
				function (pos) {
					btn.disabled = false;
					var lat = pos.coords.latitude;
					var lng = pos.coords.longitude;
					var acc = pos.coords.accuracy;

					if (lat < bbox.min_lat || lat > bbox.max_lat || lng < bbox.min_lng || lng > bbox.max_lng) {
						status.textContent = HNC.i18n.gps_out_of_bounds;
						state.gps = null;
						latIn.value = ''; lngIn.value = ''; accIn.value = '';
						form.dispatchEvent(new Event('hnc:state'));
						return;
					}
					state.gps = { lat: lat, lng: lng, accuracy: acc };
					latIn.value = lat.toFixed(6);
					lngIn.value = lng.toFixed(6);
					accIn.value = Math.round(acc);
					status.textContent = 'GPS captured (accuracy ±' + Math.round(acc) + ' m).';
					form.dispatchEvent(new Event('hnc:state'));
				},
				function (err) {
					btn.disabled = false;
					status.textContent = HNC.i18n.gps_unavailable + ' (' + err.message + ')';
				},
				{ enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
			);
		});
	}

	// ---- Camera ---------------------------------------------------------

	function wireCamera(form, state) {
		var HNC    = window.HNC_PUBLIC;
		var startBtn = form.querySelector('[data-hnc-camera-start]');
		var flipBtn  = form.querySelector('[data-hnc-camera-flip]');
		var capBtn   = form.querySelector('[data-hnc-camera-capture]');
		var retryBtn = form.querySelector('[data-hnc-camera-retry]');
		var video    = form.querySelector('[data-hnc-camera-video]');
		var canvas   = form.querySelector('[data-hnc-camera-canvas]');
		var preview  = form.querySelector('[data-hnc-camera-preview]');
		var tsInput  = form.querySelector('[data-hnc-photo-ts]');

		if (!startBtn) return;

		// Detect whether the device has more than one camera. If it
		// does not, the flip button stays permanently hidden even
		// after the stream starts — there's nothing to flip to.
		var multiCamera = false;
		if (navigator.mediaDevices && typeof navigator.mediaDevices.enumerateDevices === 'function') {
			navigator.mediaDevices.enumerateDevices().then(function (devices) {
				var videoInputs = devices.filter(function (d) { return d.kind === 'videoinput'; });
				multiCamera = videoInputs.length > 1;
			}).catch(function () {
				// enumerateDevices failed — keep multiCamera = false, flip stays hidden.
			});
		}

		/**
		 * Start (or restart) the camera stream with the current
		 * facingMode. Stops any existing stream first so permissions
		 * and hardware release cleanly on mobile Safari.
		 */
		function openStream() {
			if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
				HNC.ui.toast(HNC.i18n.camera_unavailable, 'error');
				return;
			}
			stopStream(state, video);
			navigator.mediaDevices.getUserMedia({
				video: {
					facingMode: { ideal: state.facingMode },
					width:  { ideal: 1280 },
					height: { ideal: 720 }
				},
				audio: false
			}).then(function (stream) {
				state.stream = stream;
				video.srcObject = stream;
				video.play();
				video.hidden = false;
				canvas.hidden = true;
				preview.hidden = true;
				startBtn.hidden = true;
				capBtn.hidden = false;
				retryBtn.hidden = true;
				if (flipBtn) { flipBtn.hidden = !multiCamera; }
			}).catch(function () {
				HNC.ui.toast(HNC.i18n.camera_unavailable, 'error');
			});
		}

		startBtn.addEventListener('click', openStream);

		if (flipBtn) {
			flipBtn.addEventListener('click', function () {
				state.facingMode = (state.facingMode === 'environment') ? 'user' : 'environment';
				openStream();
			});
		}

		capBtn.addEventListener('click', function () {
			var w = video.videoWidth;
			var h = video.videoHeight;
			if (!w || !h) {
				HNC.ui.toast(HNC.i18n.camera_unavailable, 'error');
				return;
			}
			canvas.width = w;
			canvas.height = h;
			var ctx = canvas.getContext('2d');
			ctx.drawImage(video, 0, 0, w, h);
			canvas.toBlob(function (blob) {
				if (!blob) {
					HNC.ui.toast(HNC.i18n.camera_unavailable, 'error');
					return;
				}
				state.photoBlob = blob;
				state.photoTs = Math.floor(Date.now() / 1000);
				tsInput.value = String(state.photoTs);

				preview.src = URL.createObjectURL(blob);
				preview.hidden = false;
				video.hidden = true;
				canvas.hidden = true;
				capBtn.hidden = true;
				retryBtn.hidden = false;
				if (flipBtn) { flipBtn.hidden = true; }

				stopStream(state, video);
				form.dispatchEvent(new Event('hnc:state'));
			}, 'image/jpeg', 0.85);
		});

		retryBtn.addEventListener('click', function () {
			resetCamera();
			form.dispatchEvent(new Event('hnc:state'));
		});

		/**
		 * Full visual reset of the camera widget to its initial state.
		 * Used by the Retake button and by the submit-success handler.
		 */
		function resetCamera() {
			stopStream(state, video);
			state.photoBlob = null;
			state.photoTs = null;
			tsInput.value = '';
			if ( preview.src ) {
				try { URL.revokeObjectURL( preview.src ); } catch ( e ) { /* noop */ }
			}
			preview.src = '';
			preview.hidden = true;
			video.hidden = true;
			canvas.hidden = true;
			startBtn.hidden = false;
			capBtn.hidden = true;
			retryBtn.hidden = true;
			if ( flipBtn ) { flipBtn.hidden = true; }
		}

		// Expose the reset on state so the submit handler can call it.
		state.resetCamera = resetCamera;
	}

	function stopStream(state, video) {
		if (state.stream) {
			state.stream.getTracks().forEach(function (t) { t.stop(); });
			state.stream = null;
		}
		// On iOS Safari a stopped video element keeps rendering its
		// last frame until srcObject is explicitly nulled. Without
		// this the captured preview ends up stacked below a frozen
		// black/gray sliver from the video element.
		if (video) {
			try { video.srcObject = null; } catch ( e ) { /* noop */ }
		}
	}

	// ---- Submit enablement ---------------------------------------------

	function wireSubmitEnablement(form, state) {
		var submitBtn = form.querySelector('[data-hnc-submit]');
		var terms     = form.querySelector('[data-hnc-terms]');
		var district  = form.querySelector('[name="district"]');
		var category  = form.querySelector('[name="category"]');
		var pattern   = form.querySelector('[name="time_pattern"]');

		function update() {
			// Description is intentionally NOT in this guard. The
			// server only requires lat, lng, category, time_pattern;
			// the map never publishes the description text, and many
			// reporters just want to drop a pin. Keeping the
			// description optional matches the server and the UI.
			var ok =
				state.gps !== null &&
				state.photoBlob !== null &&
				terms && terms.checked &&
				district && district.value !== '' &&
				category && category.value !== '' &&
				pattern && pattern.value !== '' &&
				!window.HNC_PUBLIC.config.killswitch;
			submitBtn.disabled = !ok;
		}

		['change', 'input', 'hnc:state'].forEach(function (ev) {
			form.addEventListener(ev, update);
		});
		update();
	}

	// ---- Submit ---------------------------------------------------------

	function wireSubmit(form, state) {
		var HNC       = window.HNC_PUBLIC;
		var submitBtn = form.querySelector('[data-hnc-submit]');
		var result    = form.querySelector('[data-hnc-result]');

		form.addEventListener('submit', function (e) {
			e.preventDefault();
			if (submitBtn.disabled) return;
			submitBtn.disabled = true;
			var origText = submitBtn.textContent;
			submitBtn.textContent = HNC.i18n.submitting || 'Submitting...';

			var fd = new FormData();
			// Copy all form fields.
			var el;
			var inputs = form.querySelectorAll('input[name], textarea[name], select[name]');
			for (var i = 0; i < inputs.length; i++) {
				el = inputs[i];
				if (el.name && el.type !== 'file') {
					fd.set(el.name, el.value);
				}
			}
			// Attach the photo blob under the key the server expects.
			if (state.photoBlob) {
				fd.set('photo', state.photoBlob, 'capture.jpg');
			}

			HNC.api.postForm('alcohol/submit', fd).then(function (resp) {
				submitBtn.textContent = origText;
				var d = (resp && resp.data) || {};
				var html =
					'<p><strong>' + HNC.ui.esc(HNC.i18n.submit_success) + '</strong></p>' +
					'<p>' + HNC.ui.esc(HNC.i18n.tracking_code_is) + ' <code class="hnc-code">' + HNC.ui.esc(d.code || '') + '</code></p>' +
					'<p class="hnc-field-hint">' + HNC.ui.esc(HNC.i18n.save_this_code) + '</p>';
				HNC.ui.showResult(result, html, 'success');

				/*
				 * Full reset after a successful submit. form.reset()
				 * alone clears input values but not the camera / GPS
				 * widgets — the reporter would keep seeing their
				 * captured photo and "GPS captured (accuracy ...)"
				 * line as if the submit hadn't happened. Calling
				 * state.resetCamera() and state.resetGps() returns
				 * both widgets to the initial "open camera / capture
				 * GPS" state, which is the clearest signal that the
				 * submission is done.
				 */
				form.reset();
				if ( typeof state.resetCamera === 'function' ) { state.resetCamera(); }
				if ( typeof state.resetGps    === 'function' ) { state.resetGps(); }

				// Bring the tracking code into view so the reporter
				// can copy it without hunting for it below the fold.
				if ( result && typeof result.scrollIntoView === 'function' ) {
					try {
						result.scrollIntoView( { behavior: 'smooth', block: 'center' } );
					} catch ( e ) {
						result.scrollIntoView();
					}
				}

				// Trigger an enablement pass so the submit button
				// is redisabled until the reporter files another report.
				form.dispatchEvent( new Event( 'hnc:state' ) );
			}).catch(function (err) {
				submitBtn.textContent = origText;
				submitBtn.disabled = false;
				HNC.ui.showResult(result, '<p>' + HNC.ui.esc(HNC.ui.translateError(err)) + '</p>', 'error');
				if (err && err.code === 'hnc_rate_limit') {
					HNC.ui.applyCooldown(submitBtn, err, origText);
				}
			});
		});
	}
}());
