/**
 * public-map.js — Leaflet map of approved alcohol pins.
 *
 * Consumes GET /hnc/v1/alcohol/pins. Renders each pin as a marker.
 * Pins with verified_by_operator get a distinct style. Clicking a pin
 * opens a popup with district, category, report count, and a link to
 * check the status by tracking code.
 *
 * Leaflet is loaded by the enqueue layer before this script runs, so
 * `L` is a global by the time DOMContentLoaded fires.
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		var wraps = document.querySelectorAll('[data-hnc-screen="alcohol-map"]');
		wraps.forEach(initMap);
	});

	function debounce(fn, wait) {
		var t;
		return function () {
			var ctx = this, args = arguments;
			clearTimeout(t);
			t = setTimeout(function () { fn.apply(ctx, args); }, wait);
		};
	}

	function initMap(wrap) {
		var HNC = window.HNC_PUBLIC;
		if (!HNC || typeof L === 'undefined') return;

		// Defensive accessors: backend config changes shouldn't break the map.
		var esc = (HNC.ui && typeof HNC.ui.esc === 'function')
			? HNC.ui.esc
			: function (s) { return String(s == null ? '' : s); };
		var i18n = HNC.i18n || {};

		var mapEl    = wrap.querySelector('[data-hnc-map]');
		var loading  = wrap.querySelector('[data-hnc-map-loading]');
		var countEl  = wrap.querySelector('[data-hnc-map-count]');
		var district = wrap.querySelector('[data-hnc-map-filter="district"]');
		var category = wrap.querySelector('[data-hnc-map-filter="category"]');

		if (!mapEl) return;

		// Default center: Dimapur area. Close enough to the populated
		// regions of Nagaland that the default view always has some
		// markers in frame.
		var map = L.map(mapEl, { scrollWheelZoom: false }).setView([25.9, 93.8], 9);

		L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
			maxZoom: 18,
			attribution: '© OpenStreetMap contributors'
		}).addTo(map);

		var layerGroup = L.layerGroup().addTo(map);

		// Monotonic request counter — drops stale responses and keeps the
		// loading indicator tied to the latest request.
		var currentRequest = 0;

		function setLoading(requestId, isLoading) {
			if (!loading) return;
			if (requestId !== currentRequest) return;
			loading.hidden = !isLoading;
		}

		function load() {
			currentRequest++;
			var requestId = currentRequest;

			setLoading(requestId, true);

			var params = new URLSearchParams();
			if (district && district.value) params.set('district', district.value);
			if (category && category.value) params.set('category', category.value);
			var qs = params.toString();
			var path = 'alcohol/pins' + (qs ? ('?' + qs) : '');

			HNC.api.get(path).then(function (resp) {
				if (requestId !== currentRequest) return;

				layerGroup.clearLayers();
				// API contract: { success, count, data: [ ...pins ] }
				var pins = (resp && Array.isArray(resp.data)) ? resp.data : [];
				var bounds = [];

				pins.forEach(function (p) {
					var lat = Number(p.lat);
					var lng = Number(p.lng);
					if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
						if (window.console && console.warn) {
							console.warn('hnc-map: skipping pin with invalid coords', p && p.id, p && p.lat, p && p.lng);
						}
						return;
					}
					var verified = !!p.verified_by_operator;
					var marker = L.circleMarker([lat, lng], {
						radius: verified ? 10 : 7,
						color: verified ? '#F5C518' : '#10B981',
						weight: 2,
						fillColor: verified ? '#F5C518' : '#10B981',
						fillOpacity: 0.75
					});

					var popup =
						'<div class="hnc-popup">' +
						'<strong>' + esc(p.district || '') + '</strong><br>' +
						esc(p.category_label || p.category || '') + '<br>' +
						esc((p.report_count || 1) + ' ' + (i18n.total_reports || 'reports')) +
						(verified ? '<br><em>' + esc(i18n.reports_verified_by_operator || 'Verified') + '</em>' : '') +
						'</div>';
					marker.bindPopup(popup);
					marker.addTo(layerGroup);
					bounds.push([lat, lng]);
				});

				if (countEl) {
					countEl.textContent = (pins.length === 1)
						? '1 pin shown.'
						: (pins.length + ' pins shown.');
				}

				if (bounds.length === 1) {
					map.setView(bounds[0], 13);
				} else if (bounds.length > 1) {
					map.fitBounds(bounds, { padding: [40, 40], maxZoom: 13 });
				}

				setLoading(requestId, false);
			}).catch(function () {
				if (requestId !== currentRequest) return;
				setLoading(requestId, false);
				if (countEl) {
					countEl.textContent = i18n.error_loading || 'Failed to load pins.';
				}
			});
		}

		var debouncedLoad = debounce(load, 250);

		if (district) district.addEventListener('change', debouncedLoad);
		if (category) category.addEventListener('change', debouncedLoad);
		load();
	}
}());
