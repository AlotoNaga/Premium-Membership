<?php
/**
 * Donation form + status shortcodes (frontend).
 *
 * Provides two shortcodes:
 *   [hnc_donate]            — donation form. Place on /donate page.
 *   [hnc_donation_status]   — thank-you / status display. Place on /donate/thank-you.
 *
 * Donor flow:
 *   1. Donor lands on /donate, picks amount + frequency.
 *   2. Form calls our REST API to create an order (one-time) or
 *      subscription (recurring) on Razorpay's side.
 *   3. Razorpay Checkout opens as a popup — donor enters card / UPI.
 *   4. Razorpay's success handler fires; JS redirects to /donate/thank-you
 *      with the donation public_code in the URL.
 *   5. Thank-you page reads the URL and shows the appropriate message.
 *
 * Anonymous design:
 *   - One-time donations: form asks for nothing but amount. Email is not
 *     captured by us (Razorpay's popup will, but we don't store it on
 *     our donation row).
 *   - Recurring donations: Razorpay's platform requires email so the
 *     donor can later manage / cancel the subscription. We collect it
 *     on the form when frequency != "once" and pass it through to
 *     Razorpay, but we do NOT store it on the donation row.
 *
 * @package HelpNagalandCore
 * @since   1.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Public_Donate
 */
final class HNC_Public_Donate {

	const SHORTCODE_DONATE = 'hnc_membership';
	const SHORTCODE_STATUS = 'hnc_membership_status';

	const HANDLE_CSS         = 'hnc-donate';
	const HANDLE_JS          = 'hnc-donate-js';
	const HANDLE_RAZORPAY_JS = 'razorpay-checkout-js';

	/**
	 * Initialise hooks.
	 *
	 * @return void
	 */
	public static function init() {
		add_shortcode( self::SHORTCODE_DONATE, array( __CLASS__, 'shortcode_donate' ) );
		add_shortcode( self::SHORTCODE_STATUS, array( __CLASS__, 'shortcode_status' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Enqueue CSS and JS, but only on pages that contain our shortcodes.
	 * This keeps our assets off the rest of the site.
	 *
	 * @return void
	 */
	public static function enqueue_assets() {
		global $post;

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		$has_donate = has_shortcode( $post->post_content, self::SHORTCODE_DONATE );
		$has_status = has_shortcode( $post->post_content, self::SHORTCODE_STATUS );

		if ( ! $has_donate && ! $has_status ) {
			return;
		}

		// Razorpay Checkout JS — only on the donate page.
		if ( $has_donate ) {
			wp_enqueue_script(
				self::HANDLE_RAZORPAY_JS,
				'https://checkout.razorpay.com/v1/checkout.js',
				array(),
				null, // intentionally null — Razorpay manages its own versioning.
				true
			);
		}

		// Use file modification timestamp as the cache-busting version
		// for our CSS/JS. This means every time the operator uploads a
		// new donate.css or donate.js, browsers auto-fetch the new
		// version — no manual HNC_VERSION bump required for asset edits.
		$css_path = HNC_PATH . 'public/assets/donate.css';
		$js_path  = HNC_PATH . 'public/assets/donate.js';
		$css_ver  = file_exists( $css_path ) ? (string) filemtime( $css_path ) : HNC_VERSION;
		$js_ver   = file_exists( $js_path )  ? (string) filemtime( $js_path )  : HNC_VERSION;

		wp_enqueue_style(
			self::HANDLE_CSS,
			HNC_URL . 'public/assets/donate.css',
			array(),
			$css_ver
		);

		wp_enqueue_script(
			self::HANDLE_JS,
			HNC_URL . 'public/assets/donate.js',
			$has_donate ? array( self::HANDLE_RAZORPAY_JS ) : array(),
			$js_ver,
			true
		);

		wp_localize_script(
			self::HANDLE_JS,
			'HNCDonate',
			array(
				'api_root'      => esc_url_raw( rest_url( HNC_API_NAMESPACE ) ),
				'rest_nonce'    => wp_create_nonce( 'wp_rest' ),
				'thank_you_url' => self::resolve_url( array( 'premium-membership/thank-you', 'thank-you' ) ),
				'donate_url'    => self::resolve_url( array( 'premium-membership' ) ),
				'manage_url'    => self::resolve_url( array( 'premium-membership/manage', 'manage-membership' ) ),
				'site_name'     => get_bloginfo( 'name' ),
				'i18n'          => array(
					'select_amount'            => __( 'Please select or enter an amount.', 'helpnagaland-core' ),
					'enter_email'              => __( 'Please enter your email for recurring membership.', 'helpnagaland-core' ),
					'invalid_email'            => __( 'Please enter a valid email address.', 'helpnagaland-core' ),
					'invalid_amount'           => __( 'Please enter a valid amount.', 'helpnagaland-core' ),
					'amount_below_minimum'     => __( 'Amount is below the minimum allowed.', 'helpnagaland-core' ),
					'amount_above_maximum'     => __( 'Amount is above the maximum allowed.', 'helpnagaland-core' ),
					'something_went_wrong'     => __( 'Something went wrong. Please try again.', 'helpnagaland-core' ),
					'payment_cancelled'        => __( 'Payment cancelled. You have not been charged.', 'helpnagaland-core' ),
					'payment_failed'           => __( 'Payment could not be processed.', 'helpnagaland-core' ),
					'donate_button_label_once' => __( 'Pay %s', 'helpnagaland-core' ),
					'donate_button_label_sub'  => __( 'Pay %s every %s', 'helpnagaland-core' ),
					'freq_once_word'           => __( 'one-time', 'helpnagaland-core' ),
					'freq_weekly_word'         => __( 'week', 'helpnagaland-core' ),
					'freq_monthly_word'        => __( 'month', 'helpnagaland-core' ),
					'freq_halfyearly_word'     => __( '6 months', 'helpnagaland-core' ),
					'freq_yearly_word'         => __( 'year', 'helpnagaland-core' ),
				),
			)
		);
	}

	/**
	 * Resolve the first matching page slug to a URL. Falls back to home_url.
	 *
	 * @param string[] $slugs Page slugs to try in order.
	 * @return string Permalink, or home URL if none found.
	 */
	private static function resolve_url( $slugs ) {
		foreach ( $slugs as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page instanceof WP_Post ) {
				return get_permalink( $page );
			}
		}
		return home_url( '/' );
	}

	/* ==============================================================
	 * SHORTCODE: [hnc_donate]
	 * ============================================================== */

	/**
	 * Render the donation form. The form itself is static HTML; donate.js
	 * handles validation, the API call, and Razorpay Checkout.
	 *
	 * @param array $atts Shortcode attributes (currently unused).
	 * @return string Form HTML.
	 */
	public static function shortcode_donate( $atts ) {
		// Read operator-saved settings.
		$min_inr            = (int) get_option( 'hnc_payment_min_amount_inr', 99 );
		$max_inr            = (int) get_option( 'hnc_payment_max_amount_inr', 100000 );
		$default_inr        = (int) get_option( 'hnc_payment_default_amount_inr', 499 );
		$suggested_str      = (string) get_option( 'hnc_payment_suggested_amounts_inr', '99, 199, 499, 999, 2499' );
		$default_freq       = (string) get_option( 'hnc_payment_default_frequency', 'monthly' );
		$allowed_freqs      = get_option( 'hnc_payment_allowed_frequencies_v1', array( 'monthly', 'yearly' ) );
		if ( ! is_array( $allowed_freqs ) ) {
			$allowed_freqs = array( 'monthly', 'yearly' );
		}

		// Parse suggested amounts.
		$suggested = array();
		foreach ( preg_split( '/[\s,]+/', $suggested_str, -1, PREG_SPLIT_NO_EMPTY ) as $piece ) {
			$n = (int) preg_replace( '/[^0-9]/', '', $piece );
			if ( $n > 0 ) {
				$suggested[] = $n;
			}
		}
		if ( empty( $suggested ) ) {
			$suggested = array( 100, 500, 1000, 2500, 5000 );
		}

		// Frequency labels.
		$freq_labels = array(
			'monthly' => __( 'Monthly', 'helpnagaland-core' ),
			'yearly'  => __( 'Yearly', 'helpnagaland-core' ),
		);
		// Filter labels to only allowed.
		$display_freqs = array();
		foreach ( $allowed_freqs as $freq ) {
			if ( isset( $freq_labels[ $freq ] ) ) {
				$display_freqs[ $freq ] = $freq_labels[ $freq ];
			}
		}
		if ( empty( $display_freqs ) ) {
			$display_freqs = array( 'once' => $freq_labels['once'] );
		}

		// Sanity-check default frequency.
		if ( ! isset( $display_freqs[ $default_freq ] ) ) {
			$default_freq = array_key_first( $display_freqs );
		}

		ob_start();
		?>
		<div class="hnc-donate" data-min-inr="<?php echo esc_attr( $min_inr ); ?>" data-max-inr="<?php echo esc_attr( $max_inr ); ?>">

			<div class="hnc-donate__header">
				<h2 class="hnc-donate__title"><?php esc_html_e( 'Become a Premium Member', 'helpnagaland-core' ); ?></h2>
				<p class="hnc-donate__subtitle">
					<?php esc_html_e( 'Premium Membership unlocks priority review of your reports, the ability to attach a contact number for police reward eligibility on drug tips, and supports keeping this civic platform online.', 'helpnagaland-core' ); ?>
				</p>
			</div>

			<div class="hnc-donate__feedback" role="status" aria-live="polite"></div>

			<?php if ( count( $display_freqs ) > 1 ) : ?>
				<fieldset class="hnc-donate__field hnc-donate__field--frequency">
					<legend class="hnc-donate__label"><?php esc_html_e( 'Choose your plan', 'helpnagaland-core' ); ?></legend>
					<div class="hnc-donate__freq-tabs" role="tablist">
						<?php foreach ( $display_freqs as $freq_key => $freq_label ) : ?>
							<button
								type="button"
								class="hnc-donate__freq-tab<?php echo $default_freq === $freq_key ? ' is-selected' : ''; ?>"
								data-freq="<?php echo esc_attr( $freq_key ); ?>"
								role="tab"
								aria-selected="<?php echo $default_freq === $freq_key ? 'true' : 'false'; ?>"
							>
								<?php echo esc_html( $freq_label ); ?>
							</button>
						<?php endforeach; ?>
					</div>
				</fieldset>
			<?php else : ?>
				<input type="hidden" class="hnc-donate__freq-hidden" value="<?php echo esc_attr( array_key_first( $display_freqs ) ); ?>">
			<?php endif; ?>

			<fieldset class="hnc-donate__field hnc-donate__field--amount">
				<legend class="hnc-donate__label"><?php esc_html_e( 'Choose your contribution', 'helpnagaland-core' ); ?></legend>
				<div class="hnc-donate__amount-grid">
					<?php foreach ( $suggested as $amount ) :
						$is_default = ( $amount === $default_inr );
						?>
						<button
							type="button"
							class="hnc-donate__amount-btn<?php echo $is_default ? ' is-selected' : ''; ?>"
							data-amount="<?php echo esc_attr( $amount ); ?>"
						>
							Rs <?php echo esc_html( number_format_i18n( $amount ) ); ?>
						</button>
					<?php endforeach; ?>
				</div>
				<div class="hnc-donate__custom">
					<label for="hnc-donate-custom" class="hnc-donate__custom-label">
						<?php esc_html_e( 'Or enter a custom amount', 'helpnagaland-core' ); ?>
					</label>
					<div class="hnc-donate__custom-wrap">
						<input
							type="number"
							id="hnc-donate-custom"
							class="hnc-donate__custom-input"
							min="<?php echo esc_attr( $min_inr ); ?>"
							max="<?php echo esc_attr( $max_inr ); ?>"
							step="1"
							inputmode="numeric"
							placeholder="<?php esc_attr_e( 'Enter amount', 'helpnagaland-core' ); ?>"
						>
					</div>
				</div>
			</fieldset>

			<div class="hnc-donate__field hnc-donate__field--email" hidden>
				<label for="hnc-donate-email" class="hnc-donate__label">
					<?php esc_html_e( 'Email (for managing your membership)', 'helpnagaland-core' ); ?>
				</label>
				<input
					type="email"
					id="hnc-donate-email"
					class="hnc-donate__email-input"
					placeholder="you@example.com"
					autocomplete="email"
				>
				<p class="hnc-donate__hint">
					<?php esc_html_e( 'Used by Razorpay to send confirmations and a link to manage or cancel your membership. We do not store your email on our membership records.', 'helpnagaland-core' ); ?>
				</p>
			</div>

			<button
				type="button"
				class="hnc-donate__submit"
				data-default-freq="<?php echo esc_attr( $default_freq ); ?>"
				data-default-amount="<?php echo esc_attr( $default_inr ); ?>"
			>
				<span class="hnc-donate__submit-label"><?php esc_html_e( 'Become a Premium Member', 'helpnagaland-core' ); ?></span>
				<span class="hnc-donate__submit-spinner" hidden></span>
			</button>

			<p class="hnc-donate__legal">
				<?php
				printf(
					/* translators: %s: Razorpay link */
					esc_html__( 'Secure payment processing by %s. We support cards, UPI, netbanking, and wallets.', 'helpnagaland-core' ),
					'<a href="https://razorpay.com/" target="_blank" rel="noopener nofollow">Razorpay</a>'
				);
				?>
			</p>

		</div>
		<?php
		return (string) ob_get_clean();
	}

	/* ==============================================================
	 * SHORTCODE: [hnc_donation_status]
	 * ============================================================== */

	/**
	 * Render the thank-you / status page. The shortcode itself just
	 * outputs an empty container — donate.js reads URL params (?code=...
	 * &status=...) and injects the appropriate message client-side.
	 *
	 * Server-side rendering would require an API call here, which adds
	 * latency to every page load. Client-side rendering loads instantly
	 * and degrades gracefully if JS is disabled.
	 *
	 * @param array $atts Shortcode attributes (currently unused).
	 * @return string Container HTML.
	 */
	public static function shortcode_status( $atts ) {
		ob_start();
		?>
		<div class="hnc-status" role="status" aria-live="polite">
			<div class="hnc-status__loading">
				<p><?php esc_html_e( 'Loading your membership details…', 'helpnagaland-core' ); ?></p>
			</div>
			<noscript>
				<p>
					<?php esc_html_e( 'JavaScript is required to view your membership status. Please enable JavaScript and reload this page, or check your email for the Razorpay confirmation.', 'helpnagaland-core' ); ?>
				</p>
			</noscript>
		</div>
		<?php
		return (string) ob_get_clean();
	}
}