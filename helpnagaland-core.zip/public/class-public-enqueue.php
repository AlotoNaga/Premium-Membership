<?php
/**
 * Public Enqueue: loads JS and CSS only on pages containing HNC shortcodes.
 *
 * The public frontend is designed so that a visitor to a page without any
 * HNC shortcode does not pay for any of the plugin's JS or CSS. This
 * class inspects the current post content at wp_enqueue_scripts time,
 * determines which shortcodes are present, and loads only the matching
 * assets.
 *
 * Asset bundles:
 *
 *   public-common.css        Base styling, loaded if any shortcode present.
 *   public-common.js         Shared api helper + fingerprint + utilities.
 *   alcohol-form.js          Live GPS + live camera capture.
 *   drug-form.js             Drug submission + phone consent logic.
 *   public-map.js            Leaflet map. Also loads Leaflet from CDN.
 *   status-check.js          Code lookup.
 *   transparency.js          Snapshot list rendering.
 *
 * Leaflet and Leaflet.markercluster are SELF-HOSTED under /lib/leaflet/
 * and /lib/leaflet-markercluster/. Third-party CDNs (unpkg, cdnjs, etc.)
 * are NOT used for these dependencies — per the specification's no-third-
 * party-tracking rule and to remove a supply-chain risk on a page that
 * also asks for live GPS + live camera permissions. Site owners who want
 * to override the URL can still filter `hnc_public_leaflet_js_url` and
 * `hnc_public_leaflet_css_url`, but the defaults ship locally.
 *
 * @package HelpNagalandCore
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class HNC_Public_Enqueue
 */
final class HNC_Public_Enqueue {


	const HANDLE_BASE_CSS     = 'hnc-public-base';
	const HANDLE_COMMON_JS    = 'hnc-public-common';
	const HANDLE_ALCOHOL_FORM = 'hnc-public-alcohol-form';
	const HANDLE_DRUG_FORM    = 'hnc-public-drug-form';
	const HANDLE_MAP          = 'hnc-public-map';
	const HANDLE_STATUS       = 'hnc-public-status';
	const HANDLE_TRANSPARENCY = 'hnc-public-transparency';

	const HANDLE_LEAFLET_CSS         = 'hnc-leaflet-css';
	const HANDLE_LEAFLET_JS          = 'hnc-leaflet-js';
	const HANDLE_LEAFLET_CLUSTER_CSS = 'hnc-leaflet-cluster-css';
	const HANDLE_LEAFLET_CLUSTER_CSS_DEFAULT = 'hnc-leaflet-cluster-css-default';
	const HANDLE_LEAFLET_CLUSTER_JS  = 'hnc-leaflet-cluster-js';

	/** Leaflet version pinned in /lib/leaflet/. Bump when you update the vendored copy. */
	const LEAFLET_VERSION = '1.9.4';

	/** Leaflet.markercluster version pinned in /lib/leaflet-markercluster/. */
	const LEAFLET_CLUSTER_VERSION = '1.5.3';


	/**
	 * Register the hook.
	 *
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'maybe_enqueue' ) );
	}


	/**
	 * Inspect the current post and enqueue only the needed assets.
	 *
	 * @return void
	 */
	public static function maybe_enqueue() {
		$content = self::current_post_content();
		if ( '' === $content || ! class_exists( 'HNC_Public_Shortcodes' ) ) {
			return;
		}

		$sc = HNC_Public_Shortcodes::detect_shortcodes( $content );
		$any_present = false;
		foreach ( $sc as $v ) {
			if ( $v ) { $any_present = true; break; }
		}
		if ( ! $any_present ) {
			return;
		}

		/* ---- Base CSS always loaded when any shortcode is present ---- */

		wp_enqueue_style(
			self::HANDLE_BASE_CSS,
			HNC_URL . 'public/css/public.css',
			array(),
			HNC_VERSION
		);

		/* ---- Common JS: api helper, fingerprint, utilities ---- */

		wp_enqueue_script(
			self::HANDLE_COMMON_JS,
			HNC_URL . 'public/js/public-common.js',
			array(),
			HNC_VERSION,
			true
		);

		$killswitch = class_exists( 'HNC_Killswitch' ) ? (bool) HNC_Killswitch::is_active() : false;
		$ks_message = $killswitch && class_exists( 'HNC_Killswitch' ) ? (string) HNC_Killswitch::public_message() : '';

		wp_localize_script(
			self::HANDLE_COMMON_JS,
			'HNC_PUBLIC_CONFIG',
			array(
				'rest_url'         => esc_url_raw( rest_url( HNC_API_NAMESPACE . '/' ) ),
				'site_url'         => esc_url_raw( home_url( '/' ) ),
				'version'          => HNC_VERSION,
				'killswitch'       => $killswitch,
				'ks_message'       => $ks_message,
				'min_form_seconds' => (int) get_option( 'hnc_min_submit_seconds', 8 ),
				'bbox'             => self::nagaland_bbox(),
				'photo_max_age_sec' => (int) get_option( 'hnc_photo_max_age_seconds', 180 ),
				'max_upload_bytes'  => (int) get_option( 'hnc_upload_max_bytes', 15 * 1024 * 1024 ),
				'min_gps_accuracy_m' => (float) get_option( 'hnc_min_gps_accuracy_m', 60 ),
				'i18n'             => self::i18n_strings(),
			)
		);

		/* ---- Per-shortcode bundles ---- */

		if ( $sc['alcohol_form'] ) {
			wp_enqueue_script(
				self::HANDLE_ALCOHOL_FORM,
				HNC_URL . 'public/js/alcohol-form.js',
				array( self::HANDLE_COMMON_JS ),
				HNC_VERSION,
				true
			);
		}

		if ( $sc['drug_form'] ) {
			wp_enqueue_script(
				self::HANDLE_DRUG_FORM,
				HNC_URL . 'public/js/drug-form.js',
				array( self::HANDLE_COMMON_JS ),
				HNC_VERSION,
				true
			);
		}

		if ( $sc['alcohol_map'] ) {
			/*
			 * Self-hosted Leaflet 1.9.4 and Leaflet.markercluster 1.5.3,
			 * bundled under /lib/. Filters below remain for site owners
			 * who insist on a CDN; the defaults are local and SRI-safe.
			 */
			$leaflet_css = apply_filters(
				'hnc_public_leaflet_css_url',
				HNC_URL . 'lib/leaflet/leaflet.css'
			);
			$leaflet_js = apply_filters(
				'hnc_public_leaflet_js_url',
				HNC_URL . 'lib/leaflet/leaflet.js'
			);
			$cluster_css = apply_filters(
				'hnc_public_leaflet_cluster_css_url',
				HNC_URL . 'lib/leaflet-markercluster/MarkerCluster.css'
			);
			$cluster_css_default = apply_filters(
				'hnc_public_leaflet_cluster_css_default_url',
				HNC_URL . 'lib/leaflet-markercluster/MarkerCluster.Default.css'
			);
			$cluster_js = apply_filters(
				'hnc_public_leaflet_cluster_js_url',
				HNC_URL . 'lib/leaflet-markercluster/leaflet.markercluster.js'
			);

			wp_enqueue_style( self::HANDLE_LEAFLET_CSS, $leaflet_css, array(), self::LEAFLET_VERSION );
			wp_enqueue_style(
				self::HANDLE_LEAFLET_CLUSTER_CSS,
				$cluster_css,
				array( self::HANDLE_LEAFLET_CSS ),
				self::LEAFLET_CLUSTER_VERSION
			);
			wp_enqueue_style(
				self::HANDLE_LEAFLET_CLUSTER_CSS_DEFAULT,
				$cluster_css_default,
				array( self::HANDLE_LEAFLET_CLUSTER_CSS ),
				self::LEAFLET_CLUSTER_VERSION
			);

			wp_enqueue_script( self::HANDLE_LEAFLET_JS, $leaflet_js, array(), self::LEAFLET_VERSION, true );
			wp_enqueue_script(
				self::HANDLE_LEAFLET_CLUSTER_JS,
				$cluster_js,
				array( self::HANDLE_LEAFLET_JS ),
				self::LEAFLET_CLUSTER_VERSION,
				true
			);

			wp_enqueue_script(
				self::HANDLE_MAP,
				HNC_URL . 'public/js/public-map.js',
				array( self::HANDLE_COMMON_JS, self::HANDLE_LEAFLET_JS, self::HANDLE_LEAFLET_CLUSTER_JS ),
				HNC_VERSION,
				true
			);
		}

		if ( $sc['status_check'] ) {
			wp_enqueue_script(
				self::HANDLE_STATUS,
				HNC_URL . 'public/js/status-check.js',
				array( self::HANDLE_COMMON_JS ),
				HNC_VERSION,
				true
			);
		}

		if ( $sc['transparency'] ) {
			wp_enqueue_script(
				self::HANDLE_TRANSPARENCY,
				HNC_URL . 'public/js/transparency.js',
				array( self::HANDLE_COMMON_JS ),
				HNC_VERSION,
				true
			);
		}
	}


	/* ------------------------------------------------------------------
	 * HELPERS
	 * ------------------------------------------------------------------ */

	/**
	 * Return the current post content. Returns empty string if not on a
	 * singular post/page or if the post has no content.
	 *
	 * @return string
	 */
	private static function current_post_content() {
		if ( ! function_exists( 'is_singular' ) || ! is_singular() ) {
			return '';
		}
		$post = get_post();
		if ( ! $post ) {
			return '';
		}
		return (string) $post->post_content;
	}

	/**
	 * Nagaland bounding box coordinates. Used client-side to validate
	 * GPS captures before sending to the server. The server enforces
	 * the same check. Two-layer validation keeps the error message
	 * clear and saves a round-trip when the browser's GPS is way off.
	 *
	 * @return array{min_lat:float,max_lat:float,min_lng:float,max_lng:float}
	 */
	private static function nagaland_bbox() {
		$raw = get_option( 'hnc_nagaland_bbox', '' );
		if ( '' !== $raw ) {
			$decoded = json_decode( (string) $raw, true );
			if ( is_array( $decoded )
				&& isset( $decoded['min_lat'], $decoded['max_lat'], $decoded['min_lng'], $decoded['max_lng'] ) ) {
				return array(
					'min_lat' => (float) $decoded['min_lat'],
					'max_lat' => (float) $decoded['max_lat'],
					'min_lng' => (float) $decoded['min_lng'],
					'max_lng' => (float) $decoded['max_lng'],
				);
			}
		}
		return array(
			'min_lat' => 25.20,
			'max_lat' => 27.04,
			'min_lng' => 93.32,
			'max_lng' => 95.25,
		);
	}

	/**
	 * i18n strings available to JS as HNC_PUBLIC_CONFIG.i18n.
	 *
	 * @return array
	 */
	private static function i18n_strings() {
		return array(
			'gps_unavailable'     => __( 'Your browser did not return GPS. Please enable location and try again.', 'helpnagaland-core' ),
			'gps_out_of_bounds'   => __( 'Your GPS location is outside Nagaland. Submission must be from within Nagaland.', 'helpnagaland-core' ),
			'camera_unavailable'  => __( 'Could not access your camera. Make sure the site has camera permission.', 'helpnagaland-core' ),
			'camera_required'     => __( 'A live photo is required. Gallery uploads are not accepted.', 'helpnagaland-core' ),
			'submit_success'      => __( 'Report submitted successfully.', 'helpnagaland-core' ),
			'submit_failed'       => __( 'Could not submit your report. Please try again.', 'helpnagaland-core' ),
			'tracking_code_is'    => __( 'Your tracking code is:', 'helpnagaland-core' ),
			'save_this_code'      => __( 'Save this code. You can use it to check the status of your report later.', 'helpnagaland-core' ),
			'status_received'     => __( 'Received and in the moderation queue.', 'helpnagaland-core' ),
			'status_approved'     => __( 'Approved and published.', 'helpnagaland-core' ),
			'status_rejected'     => __( 'Rejected by moderators.', 'helpnagaland-core' ),
			'status_hold'         => __( 'On hold for additional review.', 'helpnagaland-core' ),
			'status_archived'     => __( 'Archived.', 'helpnagaland-core' ),
			'status_resolved'     => __( 'Case resolved.', 'helpnagaland-core' ),
			'status_acted_on'     => __( 'Acted on by moderators.', 'helpnagaland-core' ),
			'status_closed'       => __( 'Closed.', 'helpnagaland-core' ),
			'status_not_found'    => __( 'No report found for that code.', 'helpnagaland-core' ),
			'rate_limited'        => __( 'Too many submissions. Please wait a moment and try again.', 'helpnagaland-core' ),
			'rate_limited_wait'   => __( 'Too many submissions. Please wait %d seconds and try again.', 'helpnagaland-core' ),
			'wait_seconds'        => __( 'Wait %d s', 'helpnagaland-core' ),
			'platform_paused'     => __( 'Submissions are temporarily paused. Please try again later.', 'helpnagaland-core' ),
			'missing_field'       => __( 'Please complete all required fields.', 'helpnagaland-core' ),
			'photo_too_old'       => __( 'Your photo is too old. Please take a fresh one.', 'helpnagaland-core' ),
			'please_wait'         => __( 'Please take a moment to review your report before submitting.', 'helpnagaland-core' ),
			'submitting'          => __( 'Submitting...', 'helpnagaland-core' ),
			'loading'             => __( 'Loading...', 'helpnagaland-core' ),
			'no_results'          => __( 'No results found.', 'helpnagaland-core' ),
			'download_csv'        => __( 'Download CSV for this month', 'helpnagaland-core' ),
			'alcohol'             => __( 'Alcohol', 'helpnagaland-core' ),
			'drug'                => __( 'Drug', 'helpnagaland-core' ),
			'received'            => __( 'received', 'helpnagaland-core' ),
			'approved'            => __( 'approved', 'helpnagaland-core' ),
			'rejected'            => __( 'rejected', 'helpnagaland-core' ),
			'forwarded'           => __( 'forwarded', 'helpnagaland-core' ),
			'acted_police'        => __( 'acted on by police', 'helpnagaland-core' ),
			'reports_verified_by_operator' => __( 'Verified by operator site visit', 'helpnagaland-core' ),
			'reports_submitted_by_member'  => __( 'Submitted by Premium Member', 'helpnagaland-core' ),
			'total_reports'       => __( 'Total citizen reports:', 'helpnagaland-core' ),
			'invalid_code_format' => __( 'That code is not in the right format.', 'helpnagaland-core' ),
			'file_too_large'      => __( 'File is too large. Please choose a smaller photo or video.', 'helpnagaland-core' ),
			'gps_accuracy_low'    => __( 'GPS accuracy is too low. Move outside or near a window and try again.', 'helpnagaland-core' ),
			'flip_camera'         => __( 'Flip camera', 'helpnagaland-core' ),
		);
	}
}
